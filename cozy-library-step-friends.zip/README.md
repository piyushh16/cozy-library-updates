# Cozy Library

A cozy 3D virtual study library game.

## Steps done
- Step 1: walkable library world
- Step 2: bookshelf interaction (take a book, put it back)
- Step 3: librarian check-in (asks your name, saves a session record on the phone)
- Step 4: numbered desks, sit at a desk (saved in the session record), stand up
- Step 5: study timer (starts when you sit, shows hh:mm:ss, saved in the session record)
- Step 6: background study mode (timer stays correct, rendering pauses, quiet notification)
- Step 7: checkout with the librarian (session saved)
- Step 8: study history (today, week, month, overall, and every session)
- Step 9: bulletin board on the wall with today's study ranking
- Step 10: daily leaderboard, weekly standings, last week's champion on the board
- Step 11: weekly Library Champion badge above the character (last week's #1, visible all week)
- Step 12: consecutive champion weeks counter (🔥) next to the badge, board and panel
- Step 13: daily study streak (🔥 days in a row), shown under the timer and in history
- Step 14: private friends room with a code, friends' characters, names above heads, taken desks; board shows only the room (Today / This week / All time + Hall of Fame)
- Step 15: in-game room chat (💬 box at the top, unread badge, minimise)
- Step 16: break and social area (sofa, lounge chairs, window seats); breaks are kept separate from study time
- Step 17: friend interactions (wave, keep going, celebrate), friends' status in the room screen, auto celebration every full hour of study
- Step 18: cozy game feel (time of day, rain, stars, swaying plants and curtains, open books with turning pages, typing librarian)
- Windows you can open and close, a real outside world (trees, hills, houses, sun, moon, clouds) that follows the time of day and weather
- More reactions with written messages (10 in total)
- Home page (opens first), clean library screen with a menu button, leave through the gate (checks out), checkout summary
- Step 19: shelves with categories (Literature, Science, History, Language, Research), browse a shelf and pick a book by title
- Step 22: seasons and events (Exam Season, Monsoon Week, Winter Study Week, New Year Challenge) with decorations, weather, snow, fireworks and a challenge badge
- Step 20: game-style player profile (level, stats, shirt colour that friends see)
- Step 21: 17 achievements with progress bars and unlock messages
- Step 23: polish (sound effects, ambience and optional music made in the browser, camera that avoids walls and shelves, fades, dust and lamp glow, press feedback)
- Account: optional email and password (guest sign-in stays the default)
- Firebase: anonymous sign-in, sessions saved online, board ranks everyone (rules in firestore.rules)

## Code layout (src/)
- core.js: scene, camera, helpers, shared state
- world.js: library room, furniture, books, lights
- characters.js: player and librarian
- input.js: joystick, camera drag, keyboard
- interactions.js: bookshelf interaction (Step 2)
- checkin.js: librarian conversation and session record (Step 3)
- desks.js: desks, sitting and standing (Step 4)
- study.js: study timer and background mode (Steps 5 and 6)
- history.js: study history screen (Step 8)
- board.js: bulletin board (Step 9)
- firebase.js: online sync with Firebase
- account.js: optional email account screen
- champion.js: champion badge above the character (Step 11)
- streak.js: daily study streak (Step 13)
- rooms.js: create / join / leave a friends room
- friends.js: friends' characters and desk sharing (Step 14)
- chat.js: room chat (Step 15)
- lounge.js: break area (Step 16)
- emote.js, social.js: emotes and interactions (Step 17)
- environment.js, cozy.js: atmosphere (Step 18)
- outside.js, windows.js: the view outside and opening windows
- home.js, ui.js, gate.js, summary.js: Home dashboard, clean library UI, exit gate and checkout summary
- books.js: shelf categories and book titles (Step 19)
- events.js: seasons and special events (Step 22)
- profile.js, achievements.js, stats.js: profile, achievements and counters (Steps 20 and 21)
- audio.js: sounds and music (Step 23)
- main.js: loads everything and runs the game loop

Each new step gets its own new file.

## Friends, security and updates
- Tap a character in the library for their card; send a friend request; once both accept, private chat (src/buddies.js)
- Study time shared only inside your study room (src/lb.js); sessions are private to the owner; rules in firestore.rules
- Delete account erases all online data and this phone (src/erase.js)
- Updates: put `[release]` in the commit message; the workflow publishes the APK and version.json to the public repo piyushh16/cozy-library-updates (needs secret UPDATES_TOKEN)
- Soft music plays only on the Home page
