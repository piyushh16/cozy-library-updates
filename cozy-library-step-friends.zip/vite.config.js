export default { base: './', define: { __BUILD__: JSON.stringify(Number(process.env.BUILD_NUMBER) || 0) } };
