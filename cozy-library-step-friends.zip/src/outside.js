// OUTSIDE: the world beyond the windows (ground, hills, trees, houses, sun, moon, clouds), lit by the same sky as the room
import * as THREE from 'three';
import { scene } from './core.js';

const R = (a, b) => a + Math.random() * (b - a);
const inRoom = (x, z) => Math.abs(x) < 11 && Math.abs(z) < 13.5;
const std = (c, extra = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 1, ...extra });

// ground, a path from the front door, and far hills
const ground = new THREE.Mesh(new THREE.PlaneGeometry(260, 260), std(0x5f8a4a));
ground.rotation.x = -Math.PI / 2; ground.position.y = -0.06; scene.add(ground);
const path = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 70), std(0xc9b48a));
path.rotation.x = -Math.PI / 2; path.position.set(0, -0.04, 45.4); scene.add(path);
const hillMat = std(0x4f7d4c);
for (let i = 0; i < 14; i++) {
  const a = (i / 14) * Math.PI * 2 + R(-0.2, 0.2), r = R(75, 100), s = R(14, 26);
  const h = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), hillMat);
  h.scale.set(s * 1.6, s * 0.55, s * 1.3); h.position.set(Math.cos(a) * r, -s * 0.12, Math.sin(a) * r); scene.add(h);
}

// trees (two instanced meshes)
const treeData = [];
const TN = 90, d = new THREE.Object3D(), col = new THREE.Color();
const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.2, 0.28, 1.5, 6), std(0x6b4a2f), TN);
const crowns = new THREE.InstancedMesh(new THREE.ConeGeometry(1.3, 3.4, 7), std(0xffffff), TN);
for (let i = 0; i < TN; i++) {
  let x, z; do { x = R(-60, 60); z = R(-60, 60); } while (inRoom(x, z));
  const s = R(0.8, 1.7); treeData.push({ x, z, s });
  d.position.set(x, 0.75 * s, z); d.scale.setScalar(s); d.updateMatrix(); trunks.setMatrixAt(i, d.matrix);
  d.position.set(x, 2.8 * s, z); d.updateMatrix(); crowns.setMatrixAt(i, d.matrix);
  crowns.setColorAt(i, col.setHSL(R(0.25, 0.36), 0.45, R(0.28, 0.4)));
}
scene.add(trunks, crowns);
// winter: snow caps on the trees, snow on the ground and falling snow
const snowCaps = new THREE.InstancedMesh(new THREE.ConeGeometry(0.95, 1.5, 7), std(0xf4f8ff), TN);
treeData.forEach((t, i) => { d.position.set(t.x, 3.55 * t.s, t.z); d.scale.setScalar(t.s); d.updateMatrix(); snowCaps.setMatrixAt(i, d.matrix); });
snowCaps.visible = false; scene.add(snowCaps);
const SN = 450, snowPos = new Float32Array(SN * 3), snowData = [];
for (let i = 0; i < SN; i++) {
  let x, z; do { x = R(-40, 40); z = R(-45, 45); } while (Math.abs(x) < 8.3 && Math.abs(z) < 10.3);
  snowData.push({ x, z, y: R(0, 14), v: R(0.8, 1.8), ph: R(0, 6.28) });
}
const snowGeo = new THREE.BufferGeometry(); snowGeo.setAttribute('position', new THREE.BufferAttribute(snowPos, 3));
const snow = new THREE.Points(snowGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 3, sizeAttenuation: false, fog: false, transparent: true, opacity: 0.9 }));
snow.frustumCulled = false; snow.visible = false; scene.add(snow);
let winter = false;
const groundSummer = new THREE.Color(0x5f8a4a), groundSnow = new THREE.Color(0xe6edf5), hillSummer = new THREE.Color(0x4f7d4c), hillSnow = new THREE.Color(0xdfe6ee);
export function setWinter(on) { winter = on; snowCaps.visible = on; snow.visible = on; }

// small houses with windows that light up in the evening
const winMat = new THREE.MeshStandardMaterial({ color: 0xaecbe8, emissive: 0xffd27a, emissiveIntensity: 0, roughness: 0.4 });
const roofMat = std(0x8a4b3c);
const wallCols = [0xe8d5b5, 0xd9a58b, 0xc8d6c0, 0xe6c8a0, 0xb9c4d8];
const bodyGeo = new THREE.BoxGeometry(3.4, 2.4, 3), roofGeo = new THREE.ConeGeometry(3, 1.5, 4), winGeo = new THREE.PlaneGeometry(0.6, 0.6);
for (let i = 0; i < 9; i++) {
  let x, z; do { x = R(-55, 55); z = R(-55, 55); } while (inRoom(x, z) || Math.hypot(x, z) < 22);
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = R(0, Math.PI * 2);
  const body = new THREE.Mesh(bodyGeo, std(wallCols[i % wallCols.length])); body.position.y = 1.2; g.add(body);
  const roof = new THREE.Mesh(roofGeo, roofMat); roof.position.y = 3.15; roof.rotation.y = Math.PI / 4; g.add(roof);
  [-0.8, 0.8].forEach(wx => { const w = new THREE.Mesh(winGeo, winMat); w.position.set(wx, 1.4, 1.51); g.add(w); });
  scene.add(g);
}

// sun, moon and clouds
function glow(inner, outer) {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 4, 64, 64, 64);
  g.addColorStop(0, inner); g.addColorStop(0.35, inner); g.addColorStop(1, outer);
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
const sunSp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow('rgba(255,250,225,1)', 'rgba(255,210,140,0)'), transparent: true, depthWrite: false, fog: false, opacity: 0 }));
sunSp.scale.set(18, 18, 1); scene.add(sunSp);
const moonSp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glow('rgba(240,244,255,1)', 'rgba(170,190,255,0)'), transparent: true, depthWrite: false, fog: false, opacity: 0 }));
moonSp.scale.set(10, 10, 1); scene.add(moonSp);
const cc = document.createElement('canvas'); cc.width = 256; cc.height = 96;
{
  const x = cc.getContext('2d');
  [[70, 56, 44], [120, 44, 52], [170, 54, 44], [205, 60, 30], [40, 62, 28]].forEach(([cx, cy, r]) => {
    const g = x.createRadialGradient(cx, cy, 2, cx, cy, r); g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.fillRect(0, 0, 256, 96);
  });
}
const cloudTex = new THREE.CanvasTexture(cc); cloudTex.colorSpace = THREE.SRGBColorSpace;
const clouds = Array.from({ length: 10 }, (_, i) => {
  const m = new THREE.SpriteMaterial({ map: cloudTex, transparent: true, depthWrite: false, opacity: 0.8 });
  const s = new THREE.Sprite(m); const w = R(26, 44);
  s.scale.set(w, w * 0.36, 1);
  s.position.set(R(-70, 70), R(22, 34), (i % 2 ? 1 : -1) * R(32, 70));
  scene.add(s); return { s, v: R(0.4, 1.2) };
});

const MOOD = {
  morning: { sun: [-38, 15, -48], sunTint: 0xffe3b0, sunA: 1, moonA: 0, cloudA: 0.75, cloudTint: 0xfff0dd, win: 0 },
  afternoon: { sun: [12, 40, -44], sunTint: 0xffffff, sunA: 1, moonA: 0, cloudA: 0.9, cloudTint: 0xffffff, win: 0 },
  evening: { sun: [34, 7, -46], sunTint: 0xff9a4a, sunA: 1, moonA: 0, cloudA: 0.8, cloudTint: 0xffc08a, win: 0.5 },
  night: { moon: [-24, 30, -50], sunA: 0, moonA: 1, cloudA: 0.3, cloudTint: 0x4a5a8a, win: 1.6 },
  rainy: { sunA: 0, moonA: 0, cloudA: 0.95, cloudTint: 0x7d8794, win: 0.8 },
};
let tgt = MOOD.evening;
const cloudColor = new THREE.Color(0xffc08a);
export function setOutside(key) {
  tgt = MOOD[key];
  if (tgt.sun) { sunSp.position.set(...tgt.sun); sunSp.material.color.set(tgt.sunTint); }
  if (tgt.moon) moonSp.position.set(...tgt.moon);
}

// called every frame
export function updateOutside(dt) {
  const k = 1 - Math.exp(-dt * 1.6);
  ground.material.color.lerp(winter ? groundSnow : groundSummer, k); hillMat.color.lerp(winter ? hillSnow : hillSummer, k);
  if (winter) {
    const t = performance.now() / 1000;
    snowData.forEach((p, i) => { p.y -= p.v * dt; if (p.y < 0) p.y = 14; snowPos[i * 3] = p.x + Math.sin(t * 0.6 + p.ph) * 0.6; snowPos[i * 3 + 1] = p.y; snowPos[i * 3 + 2] = p.z; });
    snowGeo.attributes.position.needsUpdate = true;
  }
  sunSp.material.opacity += (tgt.sunA - sunSp.material.opacity) * k;
  moonSp.material.opacity += (tgt.moonA - moonSp.material.opacity) * k;
  winMat.emissiveIntensity += (tgt.win - winMat.emissiveIntensity) * k;
  cloudColor.lerp(col.set(tgt.cloudTint), k);
  clouds.forEach(c => {
    c.s.material.color.copy(cloudColor);
    c.s.material.opacity += (tgt.cloudA - c.s.material.opacity) * k;
    c.s.position.x += c.v * dt; if (c.s.position.x > 80) c.s.position.x = -80;
  });
}
