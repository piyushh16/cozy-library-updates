// EMOTE: Step 17 friend interactions (an action plus a short written reaction), shared by me and my friends' characters
import * as THREE from 'three';
import { player } from './characters.js';
import { sfx } from './audio.js';

export const EMOTES = {
  wave: { icon: '👋', text: 'Hi!', act: 'wave' },
  cheer: { icon: '💪', text: 'You can do it!', act: 'cheer' },
  party: { icon: '🎉', text: "Let's celebrate!", act: 'party' },
  clap: { icon: '👏', text: 'Nice work!', act: 'clap' },
  study: { icon: '📚', text: "Let's study!", act: 'pump' },
  fire: { icon: '🔥', text: "I'm on fire today!", act: 'pump' },
  tired: { icon: '😴', text: "I'm tired...", act: 'tired' },
  hard: { icon: '😵', text: 'This is so hard!', act: 'tired' },
  break: { icon: '☕', text: 'Break time?', act: 'stretch' },
  thanks: { icon: '🙏', text: 'Thank you!', act: 'bow' },
};
export const DUR = 3;
export const mine = { k: null, t0: 0, t: 0 };

// speech bubble (or a lone emoji) floating above a character's head
export function showEmoji(g, icon, text) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 144;
  const x = c.getContext('2d');
  x.textAlign = 'center'; x.textBaseline = 'middle';
  if (text) {
    const label = `${icon} ${text}`;
    x.fillStyle = '#fff7e8'; x.strokeStyle = '#4a2c17'; x.lineWidth = 8;
    if (x.roundRect) { x.beginPath(); x.roundRect(6, 6, 500, 100, 44); x.fill(); x.stroke(); } else { x.fillRect(6, 6, 500, 100); }
    x.beginPath(); x.moveTo(236, 104); x.lineTo(256, 138); x.lineTo(276, 104); x.closePath(); x.fill();
    x.fillStyle = '#2a1a10';
    let s = 52; x.font = `bold ${s}px Georgia`;
    while (x.measureText(label).width > 460 && s > 22) { s -= 2; x.font = `bold ${s}px Georgia`; }
    x.fillText(label, 256, 58);
  } else { x.font = '96px serif'; x.fillText(icon, 256, 72); }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  sp.scale.set(2.1, 0.59, 1); sp.position.y = 2.95; sp.renderOrder = 11; g.add(sp);
  setTimeout(() => { g.remove(sp); tex.dispose(); sp.material.dispose(); }, DUR * 1000 + 400);
}
export function triggerMine(k) {
  mine.k = k; mine.t0 = performance.now(); mine.t = Date.now();
  showEmoji(player, EMOTES[k].icon, EMOTES[k].text); sfx.pop();
}

// body movements, applied on top of the normal pose every frame (age < 0 means no emote)
export function applyEmote(g, kind, age) {
  const u = g.userData;
  g.position.y = 0;
  u.body.rotation.x = 0; u.body.rotation.z = 0; u.body.position.z = 0; u.head.rotation.x = 0;
  u.arms.forEach(a => { a.rotation.z = 0; a.userData.fore.rotation.z = 0; });
  if (!kind || age < 0 || age > DUR) return;
  const def = EMOTES[kind], act = def ? def.act : kind;
  const seated = u.legs[0].rotation.x < -1.2;
  const up = Math.min(1, Math.sin(Math.PI * (age / DUR)) * 1.6);
  const [L, R] = u.arms, Lf = L.userData.fore, Rf = R.userData.fore;
  const mix = (o, v) => { o.rotation.x += (v - o.rotation.x) * up; };
  if (act === 'wave') {
    R.rotation.z = 2.5 * up; Rf.rotation.z = Math.sin(age * 12) * 0.5 * up;
  } else if (act === 'cheer') {
    L.rotation.z = -1.5 * up; R.rotation.z = 1.5 * up;
    Lf.rotation.z = (-1.5 + Math.sin(age * 10) * 0.15) * up; Rf.rotation.z = (1.5 - Math.sin(age * 10) * 0.15) * up;
    if (!seated) g.position.y = Math.abs(Math.sin(age * 5)) * 0.05 * up;
  } else if (act === 'party') {
    L.rotation.z = -2.5 * up; R.rotation.z = 2.5 * up;
    if (!seated) {
      const hop = Math.abs(Math.sin(age * 6.5));
      g.position.y = hop * 0.35 * up;
      u.legs.forEach(l => { l.rotation.x += (-0.7 - l.rotation.x) * up * hop; });
    }
  } else if (act === 'pump') {
    R.rotation.z = (2.1 + Math.sin(age * 9) * 0.25) * up; Rf.rotation.z = 0.9 * up;
    if (!seated) g.position.y = Math.abs(Math.sin(age * 4.5)) * 0.1 * up;
  } else if (act === 'clap') {
    mix(L, -1.3); mix(R, -1.3); Lf.rotation.x += (-1.1 - Lf.rotation.x) * up; Rf.rotation.x += (-1.1 - Rf.rotation.x) * up;
    const c = (0.3 + 0.25 * Math.sin(age * 16)) * up;
    L.rotation.z = c; R.rotation.z = -c;
  } else if (act === 'tired') {
    u.head.rotation.x = 0.6 * up; u.body.rotation.x = 0.12 * up; u.body.rotation.z = Math.sin(age * 2) * 0.04 * up;
  } else if (act === 'stretch') {
    L.rotation.z = -3 * up; R.rotation.z = 3 * up; u.head.rotation.x = -0.25 * up; u.body.rotation.x = -0.08 * up;
  } else if (act === 'bow') {
    const a = 0.6 * up;
    u.body.rotation.x = a; u.body.position.y += 0.55 * (1 - Math.cos(a)); u.body.position.z = -0.55 * Math.sin(a);
    mix(L, -0.8); mix(R, -0.8); Lf.rotation.x += (-1.4 - Lf.rotation.x) * up; Rf.rotation.x += (-1.4 - Rf.rotation.x) * up;
    L.rotation.z = 0.2 * up; R.rotation.z = -0.2 * up;
  }
}

// small message at the top, e.g. "👋 Aman: Hi!"
const el = document.createElement('div');
el.style.cssText = 'position:fixed;left:50%;top:calc(130px + env(safe-area-inset-top,0px));transform:translateX(-50%);display:none;z-index:28;max-width:80%;text-align:center;padding:10px 16px;border-radius:16px;border:2px solid #ffe9c4;background:rgba(42,26,16,.95);color:#ffe9c4;font:17px Georgia,serif;pointer-events:none';
document.body.appendChild(el);
let timer = 0;
export function emoteToast(text) { el.textContent = text; el.style.display = 'block'; clearTimeout(timer); timer = setTimeout(() => { el.style.display = 'none'; }, 3000); }
