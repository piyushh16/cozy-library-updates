// COZY: Step 18 small living details: swaying plants and curtains, open books with turning pages at taken desks
import * as THREE from 'three';
import { scene, state } from './core.js';
import { desks, plantLeaves, windowSpots, lampMat } from './world.js';
import { sfx } from './audio.js';
import { windowAmount } from './windows.js';

const HZ = 10;
// curtains on both sides of every window
const curtains = [];
const curtainMat = new THREE.MeshStandardMaterial({ color: 0xb9774a, roughness: 0.95 });
windowSpots.forEach((w, wi) => {
  [-1, 1].forEach((side, si) => {
    const g = new THREE.Group();
    g.position.set(w.x + side * 1.4, 3.15, w.z + (w.rotY === 0 ? 0.1 : -0.1));
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.5, 2.5, 0.06), curtainMat);
    m.position.y = -1.25; m.castShadow = false; g.add(m); scene.add(g);
    curtains.push({ g, wi, ph: wi * 1.7 + si * 0.9 });
  });
});
void HZ;

// open books on desks, shown while someone is sitting there
const names = [...desks].sort((a, b) => a.z - b.z || a.x - b.x).map((d, i) => ({ ...d, name: 'Desk ' + String(i + 1).padStart(2, '0') }));
const pageMat = new THREE.MeshStandardMaterial({ color: 0xfff3d8, roughness: 0.9 });
const coverMat = new THREE.MeshStandardMaterial({ color: 0x7a3b2a, roughness: 0.8 });
const books = names.map(d => {
  const g = new THREE.Group(); g.position.set(d.x + 0.15, 0.81, d.z); g.visible = false;
  const add = (w, h, dd, x, y, mat) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, dd), mat); m.position.set(x, y, 0); g.add(m); return m; };
  add(0.44, 0.01, 0.29, 0, 0, coverMat);
  add(0.2, 0.016, 0.26, -0.105, 0.012, pageMat);
  add(0.2, 0.016, 0.26, 0.105, 0.012, pageMat);
  const flip = new THREE.Group(); flip.position.set(0, 0.022, 0); g.add(flip);
  const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.004, 0.26), pageMat); leaf.position.x = 0.1; flip.add(leaf);
  scene.add(g);
  return { d, g, flip, next: 1 + Math.random() * 5, t0: -1 };
});

// dust drifting in the light, and soft halos around the desk lamps (stronger at night)
const DN = 70, dustPos = new Float32Array(DN * 3), dust = [];
for (let i = 0; i < DN; i++) dust.push({ x: (Math.random() - 0.5) * 13, y: 0.6 + Math.random() * 2.8, z: (Math.random() - 0.5) * 18, ph: Math.random() * 6.28, sp: 0.1 + Math.random() * 0.2 });
const dustGeo = new THREE.BufferGeometry(); dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
const dustPts = new THREE.Points(dustGeo, new THREE.PointsMaterial({ color: 0xfff2d0, size: 2, sizeAttenuation: false, transparent: true, opacity: 0.35, depthWrite: false }));
dustPts.frustumCulled = false; scene.add(dustPts);
const gc = document.createElement('canvas'); gc.width = gc.height = 64;
{ const x = gc.getContext('2d'), gr = x.createRadialGradient(32, 32, 2, 32, 32, 32); gr.addColorStop(0, 'rgba(255,200,130,1)'); gr.addColorStop(1, 'rgba(255,200,130,0)'); x.fillStyle = gr; x.fillRect(0, 0, 64, 64); }
const glowTex = new THREE.CanvasTexture(gc);
const halos = names.map(d => {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0 }));
  s.scale.set(0.9, 0.9, 1); s.position.set(d.x + 0.5, 1.05, d.z - 0.2); scene.add(s); return s;
});

// called every frame
export function updateCozy() {
  const t = performance.now() / 1000;
  dust.forEach((p, i) => { dustPos[i * 3] = p.x + Math.sin(t * p.sp + p.ph) * 0.5; dustPos[i * 3 + 1] = p.y + Math.sin(t * 0.4 + p.ph) * 0.25; dustPos[i * 3 + 2] = p.z + Math.cos(t * p.sp + p.ph) * 0.5; });
  dustGeo.attributes.position.needsUpdate = true;
  const gl = Math.min(1, lampMat.emissiveIntensity / 2.2) * 0.8;
  halos.forEach(h => { h.material.opacity = gl; });
  plantLeaves.forEach((f, i) => { f.position.x = f.userData.bx + Math.sin(t * 0.9 + i) * 0.03; f.scale.y = 1 + Math.sin(t * 1.3 + i * 0.7) * 0.025; });
  curtains.forEach(c => { const a = 1 + 5 * (windowAmount[c.wi] || 0); c.g.rotation.z = Math.sin(t * 0.7 + c.ph) * 0.025 * a; c.g.scale.x = 1 + Math.sin(t * 0.9 + c.ph) * 0.04 * a; });
  books.forEach(b => {
    const used = state.deskName === b.d.name || !!state.occupied[b.d.name];
    b.g.visible = used;
    if (!used) return;
    if (b.t0 < 0 && t > b.next) { b.t0 = t; if (state.deskName === b.d.name) sfx.page(0.5); }
    if (b.t0 >= 0) {
      const k = (t - b.t0) / 0.7;
      if (k >= 1) { b.t0 = -1; b.next = t + 4 + Math.random() * 6; b.flip.rotation.z = 0; } else { const e = k * k * (3 - 2 * k); b.flip.rotation.z = Math.PI * e; }
    }
  });
}
