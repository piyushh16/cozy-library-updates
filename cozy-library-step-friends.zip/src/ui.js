// UI: keeps the library screen clean. One small menu button opens an organised list.
import { openHistory } from './history.js';
import { openRooms } from './rooms.js';
import { openAccount } from './account.js';
import { openChat } from './chat.js';
import { openReactions } from './social.js';
import { openBoard } from './board.js';
import { openProfile } from './profile.js';
import { openAchievements } from './achievements.js';
import { openBuddies, buddyBadge } from './buddies.js';
import { openSettings } from './settings.js';
import { MOOD_LIST, getMood, setMood } from './environment.js';
import { EVENT_MODES, getEventMode, setEventMode, currentEvent } from './events.js';

const css = document.createElement('style');
css.textContent = `
button{-webkit-tap-highlight-color:transparent;transition:transform .08s,filter .08s}
button:active{transform:scale(.96);filter:brightness(1.18)}
#vignette{position:fixed;inset:0;pointer-events:none;z-index:1;background:radial-gradient(ellipse at center,transparent 55%,rgba(20,10,5,.38) 100%)}
#chip,#streak{display:none !important}
#hist,#acct,#roomb,#chatb,#emoteb,#envb{display:none !important}
#chatbadge{left:calc(48px + env(safe-area-inset-left,0px)) !important;right:auto !important;top:calc(4px + env(safe-area-inset-top,0px)) !important}
#menub{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(10px + env(safe-area-inset-top,0px));width:48px;height:48px;border-radius:50%;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font-size:22px;touch-action:manipulation;box-shadow:0 3px 10px rgba(0,0,0,.4)}
#menuback{position:fixed;inset:0;display:none;z-index:22}
#menup{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(66px + env(safe-area-inset-top,0px));width:min(300px,calc(100vw - 28px));max-height:calc(100vh - 90px);overflow-y:auto;display:none;z-index:24;background:rgba(32,20,12,.97);border:2px solid #ffe9c4;border-radius:18px;padding:6px 8px 10px;color:#ffe9c4;font:16px Georgia,serif;box-shadow:0 8px 24px rgba(0,0,0,.5)}
#menup h4{margin:12px 6px 4px;font:700 12px Georgia,serif;letter-spacing:2px;color:#f0c48a}
#menup .it{display:flex;align-items:center;justify-content:space-between;width:100%;padding:12px 10px;margin:2px 0;border-radius:12px;border:0;background:rgba(255,243,196,.08);color:#ffe9c4;font:600 16px Georgia,serif;text-align:left;touch-action:manipulation}
#menup .it i{font-style:normal;background:#d23c3c;color:#fff;border-radius:10px;padding:0 8px;font-size:12px}
#menup .note{font-size:13px;opacity:.75;padding:0 6px 4px}
#menup .moods{display:flex;flex-wrap:wrap;gap:6px;padding:4px 2px}
#menup .moods button{flex:1 1 30%;padding:10px 4px;border-radius:12px;border:1px solid rgba(255,233,196,.4);background:transparent;color:#ffe9c4;font:600 13px Georgia,serif}
#menup .moods button.on{background:#8a5a34}`;
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'menub'; btn.textContent = '☰'; btn.setAttribute('aria-label', 'Menu');
const back = document.createElement('div'); back.id = 'menuback';
const panel = document.createElement('div'); panel.id = 'menup';
document.body.append(btn, back, panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

const close = () => { panel.style.display = 'none'; back.style.display = 'none'; };
function build() {
  panel.replaceChildren();
  const cb = document.getElementById('chatbadge');
  const unread = cb && cb.style.display !== 'none' ? cb.textContent : '';
  const item = (label, fn, tag) => {
    const b = mk('button', 'it'); b.append(mk('span', '', label));
    if (tag) b.append(mk('i', '', tag));
    b.onclick = () => { close(); fn(); };
    panel.append(b);
  };
  panel.append(mk('h4', '', 'STUDY'));
  item('📊 Study history', openHistory);
  item('🏆 Leaderboards', () => openBoard('today'));
  item('🏅 Achievements', openAchievements);
  item('👤 Profile', openProfile);
  panel.append(mk('h4', '', 'FRIENDS'));
  item('👥 Friends and messages', openBuddies, buddyBadge() ? String(buddyBadge()) : '');
  item('🏠 Study room', openRooms);
  item('💬 Chat', openChat, unread);
  item('🙌 Reactions', openReactions);
  panel.append(mk('h4', '', 'TIME AND WEATHER'));
  const moods = mk('div', 'moods');
  MOOD_LIST.forEach(m => {
    const b = mk('button', getMood() === m.key ? 'on' : '', `${m.icon} ${m.name}`);
    b.onclick = () => { setMood(m.key); build(); };
    moods.append(b);
  });
  panel.append(moods, mk('h4', '', 'SEASONS AND EVENTS'));
  const ev = currentEvent(), evs = mk('div', 'moods');
  panel.append(mk('div', 'note', ev ? `Now: ${ev.icon} ${ev.name}` : 'No event right now'));
  EVENT_MODES.forEach(m => {
    const b = mk('button', getEventMode() === m.key ? 'on' : '', `${m.icon} ${m.name}`);
    b.onclick = () => { setEventMode(m.key); build(); };
    evs.append(b);
  });
  panel.append(evs, mk('h4', '', 'MORE'));
  item('⚙️ Settings', openSettings);
}
btn.onclick = () => {
  if (panel.style.display === 'block') { close(); return; }
  build(); panel.style.display = 'block'; back.style.display = 'block';
};
back.onclick = close;
// the "how to move" hint fades away after a few seconds
const hint = document.getElementById('hint');
if (hint) setTimeout(() => { hint.style.transition = 'opacity 1.5s'; hint.style.opacity = '0'; }, 10000);

// soft edges for a cosy look, and a tip on the loading screen
document.body.appendChild(Object.assign(document.createElement('div'), { id: 'vignette' }));
const loading = document.getElementById('loading');
if (loading) {
  const TIPS = ['Tip: sit at a desk and the study timer starts.', 'Tip: open a window to hear the weather outside.', 'Tip: walk to the front door to leave and check out.', 'Tip: tap the menu to change the weather and time of day.', 'Tip: take a break on the sofa. Breaks do not count as study time.'];
  const tip = document.createElement('div'); tip.style.cssText = 'font-size:14px;opacity:.7;max-width:260px;text-align:center'; tip.textContent = TIPS[Math.floor(Math.random() * TIPS.length)];
  loading.appendChild(tip);
}
