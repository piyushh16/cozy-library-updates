// CHARACTERS: the player, the librarian, and player collision
import * as THREE from 'three';
import { scene, mat, solids } from './core.js';

// ---------- characters (original simple style + hands) ----------
const SKIN = 0xf2c9a0;

export function person(body, hair) {
  const g = new THREE.Group();
  const add = (geo, c, x, y, z, p = g) => {
    const m = new THREE.Mesh(geo, mat(c));
    m.position.set(x, y, z); m.castShadow = true; p.add(m);
    if (c === body) (g.userData.shirt = g.userData.shirt || []).push(m);
    return m;
  };
  const bodyG = new THREE.Group(); g.add(bodyG);
  add(new THREE.CapsuleGeometry(0.25, 0.35, 4, 10), body, 0, 0.95, 0, bodyG);
  const head = new THREE.Group(); head.position.y = 1.55; bodyG.add(head);
  add(new THREE.SphereGeometry(0.22, 16, 12), SKIN, 0, 0, 0, head);
  add(new THREE.SphereGeometry(0.235, 16, 12), hair, 0, 0.07, -0.03, head).scale.y = 0.75;
  [-0.08, 0.08].forEach(s => add(new THREE.SphereGeometry(0.03, 8, 8), 0x222222, s, 0, 0.2, head));

  // arms with hands
  const arms = [-1, 1].map(s => {
    const p = new THREE.Group(); p.position.set(s * 0.3, 1.2, 0); bodyG.add(p);
    add(new THREE.CapsuleGeometry(0.055, 0.2, 4, 8), body, 0, -0.15, 0, p);
    const f = new THREE.Group(); f.position.y = -0.3; f.rotation.x = -0.3; p.add(f);
    add(new THREE.CapsuleGeometry(0.05, 0.16, 4, 8), body, 0, -0.14, 0, f);
    add(new THREE.SphereGeometry(0.085, 12, 10), SKIN, 0, -0.31, 0, f);
    add(new THREE.SphereGeometry(0.035, 8, 8), SKIN, -s * 0.07, -0.29, 0.04, f);
    p.userData.fore = f;
    return p;
  });
  const legs = [-0.1, 0.1].map(s => {
    const lg = new THREE.Group(); lg.position.set(s, 0.55, 0); g.add(lg);
    add(new THREE.BoxGeometry(0.14, 0.5, 0.16), 0x2d2d3a, 0, -0.25, 0, lg);
    return lg;
  });
  Object.assign(g.userData, { body: bodyG, head, arms, legs });
  scene.add(g); return g;
}
export const librarian = person(0x8b5a9e, 0x3a2418);
librarian.position.set(-4, 0, 4.1);

// ---------- player ----------
export const player = person(0x3f7fbf, 0x2b1d12);
player.position.set(0, 0, 8); player.rotation.y = Math.PI;
const R = 0.32;
export function resolve(p) {
  for (let k = 0; k < 2; k++) for (const s of solids) {
    const cx = Math.min(Math.max(p.x, s.x0), s.x1), cz = Math.min(Math.max(p.z, s.z0), s.z1);
    const dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
    if (d2 < R * R && d2 > 1e-8) { const d = Math.sqrt(d2), f = (R - d) / d; p.x += dx * f; p.z += dz * f; }
  }
}


export function recolorPerson(g, hex) { (g.userData.shirt || []).forEach(m => { m.material = mat(hex); }); }
