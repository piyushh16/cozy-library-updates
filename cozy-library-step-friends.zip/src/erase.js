// ERASE: delete my account and every piece of my data (online and on this phone)
import { doc, getDoc, getDocs, deleteDoc, updateDoc, collection, query, where, arrayRemove, terminate, clearIndexedDbPersistence } from 'firebase/firestore';
import { EmailAuthProvider, reauthenticateWithCredential, deleteUser } from 'firebase/auth';
import { auth, db } from './firebase.js';
import { getRoomId } from './rooms.js';
import { stopBuddies, wipeChat } from './buddies.js';
import { state } from './core.js';

const gone = async refs => { await Promise.all(refs.map(r => deleteDoc(r).catch(() => {}))); };
const mine = (col, field, me) => getDocs(query(collection(db, col), where(field, '==', me))).then(s => s.docs.map(d => d.ref));

export async function eraseMyAccount(password, step = () => {}) {
  const user = auth.currentUser, me = user && user.uid;
  if (!me) throw Object.assign(new Error('offline'), { code: 'unavailable' });
  // email accounts must prove who they are first, and nothing is deleted if the password is wrong
  if (!user.isAnonymous && user.email) await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password || ''));
  state.erasing = true; stopBuddies();

  step('Leaving your study room...');
  const roomId = getRoomId();
  if (roomId) {
    try {
      const room = await getDoc(doc(db, 'rooms', roomId));
      if (room.exists()) {
        const isOwner = room.data().ownerUid === me;
        const msgs = await getDocs(isOwner ? collection(db, 'rooms', roomId, 'messages') : query(collection(db, 'rooms', roomId, 'messages'), where('uid', '==', me)));
        await gone(msgs.docs.map(d => d.ref));
        if (isOwner) await deleteDoc(doc(db, 'rooms', roomId)); else await updateDoc(doc(db, 'rooms', roomId), { memberUids: arrayRemove(me) });
      }
    } catch { /* room already gone */ }
  }
  step('Deleting friends and private messages...');
  const fr = await getDocs(query(collection(db, 'friends'), where('uids', 'array-contains', me)));
  for (const d of fr.docs) { await wipeChat(d.id).catch(() => {}); await deleteDoc(d.ref).catch(() => {}); }
  await gone([...await mine('friendRequests', 'from', me), ...await mine('friendRequests', 'to', me), ...await mine('blocks', 'by', me)]);
  step('Deleting your study sessions...');
  await gone(await mine('sessions', 'uid', me));
  step('Deleting your profile and study totals...');
  await gone([doc(db, 'lb', me), doc(db, 'profiles', me), doc(db, 'presence', me), doc(db, 'users', me)]);
  step('Closing your account...');
  await deleteUser(user);
  step('Clearing this phone...');
  try { localStorage.clear(); sessionStorage.clear(); } catch { /* ignore */ }
  try { await terminate(db); await clearIndexedDbPersistence(db); } catch { /* ignore */ }
  try { if (indexedDB.databases) for (const d of await indexedDB.databases()) indexedDB.deleteDatabase(d.name); } catch { /* ignore */ }
  location.reload();
}

// the red "delete account" part of the Account screen
export function addDangerZone(wrap, info, say, mk) {
  wrap.append(mk('p', '', '⚠️ Delete account'));
  const open = mk('button', 'b', '🗑 Delete my account and all my data');
  open.style.background = '#7a2a2a';
  wrap.append(open);
  open.onclick = () => {
    open.remove();
    const box = mk('div'); 
    box.append(mk('div', 'note', 'This permanently erases your study sessions, study totals, profile, friends, friend requests, private messages, study room data and login, from the internet and from this phone. It cannot be undone.'));
    let pw = null;
    if (info && !info.anonymous) { pw = mk('input'); pw.type = 'password'; pw.placeholder = 'Your password'; pw.autocomplete = 'current-password'; box.append(pw); }
    const word = mk('input'); word.placeholder = 'Type DELETE to confirm'; word.autocapitalize = 'characters'; box.append(word);
    const go = mk('button', 'b', 'Erase everything'); go.style.background = '#a02a2a'; box.append(go);
    go.onclick = async () => {
      if (word.value.trim() !== 'DELETE') { say('Type the word DELETE (capital letters) to confirm.'); return; }
      go.disabled = true;
      try { await eraseMyAccount(pw && pw.value, say); } catch (e) {
        state.erasing = false; go.disabled = false;
        const c = e && e.code;
        say(c === 'auth/invalid-credential' || c === 'auth/wrong-password' ? 'Wrong password. Nothing was deleted.' : c === 'auth/requires-recent-login' ? 'Please log out, log in again, and try once more.' : 'Could not finish (' + ((e && (e.code || e.message)) || 'unknown') + '). Check your internet and try again.');
      }
    };
    wrap.append(box);
  };
}
