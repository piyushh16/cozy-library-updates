// FIREBASE: online sync (anonymous sign-in by default, optional email account) + Firestore "sessions"
import { state } from './core.js';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, EmailAuthProvider, linkWithCredential, signInWithEmailAndPassword, signOut, sendPasswordResetEmail } from 'firebase/auth';
import { initializeFirestore, persistentLocalCache, doc, setDoc, getDocs, collection, query, where } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyBDOrVc-sGkXxjobKbXqM9wS-xoesCSg-k',
  authDomain: 'cozy-library-945df.firebaseapp.com',
  projectId: 'cozy-library-945df',
  storageBucket: 'cozy-library-945df.firebasestorage.app',
  messagingSenderId: '955062171177',
  appId: '1:955062171177:web:1715ec8b5f64d30585ce38',
};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = initializeFirestore(app, { localCache: persistentLocalCache(), experimentalAutoDetectLongPolling: true });

let uid = null, status = 'connecting...', getAll = () => [], timer = 0;
const pending = new Map();
export const syncStatus = () => status;
export const myUid = () => uid;
const readyCbs = [];
export const onReady = cb => { if (uid) cb(uid); else readyCbs.push(cb); };

const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
// weeks start on Monday
export function weekKeys() {
  const now = new Date();
  const ws = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7));
  const lw = new Date(ws.getFullYear(), ws.getMonth(), ws.getDate() - 7);
  return { today: dayKey(now), thisWeek: dayKey(ws), lastWeek: dayKey(lw) };
}

export const HISTORY_WEEKS = 12;
// Monday of the week k weeks ago (k = 0 is this week)
export function weekStartKey(k) {
  const now = new Date();
  return dayKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7) - 7 * k));
}

function flush() {
  if (!uid || state.erasing) return;
  for (const [id, rec] of pending) {
    pending.delete(id);
    setDoc(doc(db, 'sessions', id), { ...rec, uid }, { merge: true }).catch(e => { status = 'sync error (' + (e.code || e.message) + ')'; });
  }
}
// save (or update) one session online; it is queued if the phone is offline
export function pushSession(rec) {
  if (rec.test) return; // test history never goes online
  pending.set(rec.id, JSON.parse(JSON.stringify(rec)));
  flush();
}

async function connect() {
  if (uid) return;
  clearTimeout(timer);
  try {
    await auth.authStateReady();
    if (!auth.currentUser) await signInAnonymously(auth);
    uid = auth.currentUser.uid; status = 'online';
    getAll().forEach(pushSession);
    flush();
    readyCbs.splice(0).forEach(cb => cb(uid));
  } catch (e) {
    status = 'not connected (' + (e.code || e.message) + ')';
    timer = setTimeout(connect, 20000);
  }
}
addEventListener('online', connect);
export function initSync(getAllFn) { getAll = getAllFn; connect(); }

// ---- accounts (guest by default, email optional)
export const accountInfo = () => { const u = auth.currentUser; return u ? { email: u.email, anonymous: u.isAnonymous } : null; };
export const linkEmail = (email, pw) => {
  if (!auth.currentUser) throw Object.assign(new Error('not ready'), { code: 'auth/not-ready' });
  return linkWithCredential(auth.currentUser, EmailAuthProvider.credential(email, pw));
};
export const loginEmail = (email, pw) => signInWithEmailAndPassword(auth, email, pw);
export const logoutAccount = () => signOut(auth);
export const sendReset = email => sendPasswordResetEmail(auth, email);
export async function fetchMySessions() {
  const snap = await getDocs(query(collection(db, 'sessions'), where('uid', '==', auth.currentUser.uid)));
  return snap.docs.map(d => d.data());
}
