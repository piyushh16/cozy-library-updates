// GATE: the entrance is the exit. Walk there and tap "Leave Library" (this also checks you out).
import * as THREE from 'three';
import { scene, state } from './core.js';
import { player } from './characters.js';
import { activeSession, checkoutNow } from './checkin.js';
import { showSummary } from './summary.js';
import { goHome } from './home.js';
import { clearPresence } from './friends.js';
import { sfx } from './audio.js';

// sign above the door
{
  const c = document.createElement('canvas'); c.width = 512; c.height = 112;
  const x = c.getContext('2d');
  x.fillStyle = '#f3e3c3'; x.fillRect(0, 0, 512, 112); x.strokeStyle = '#4a2c17'; x.lineWidth = 8; x.strokeRect(4, 4, 504, 104);
  x.fillStyle = '#4a2c17'; x.font = 'bold 46px Georgia'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('EXIT · Leave Library', 256, 58);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.52), new THREE.MeshBasicMaterial({ map: t }));
  m.position.set(0, 3.75, 9.915); m.rotation.y = Math.PI; scene.add(m);
}

const css = document.createElement('style');
css.textContent = '#gate{position:fixed;right:calc(20px + env(safe-area-inset-right,0px));bottom:calc(110px + env(safe-area-inset-bottom,0px));display:none;padding:16px 26px;border-radius:32px;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font:600 19px Georgia,serif;touch-action:manipulation;box-shadow:0 4px 14px rgba(0,0,0,.4)}';
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'gate'; btn.textContent = '🚪 Leave Library'; document.body.appendChild(btn);
let shown = false;
btn.addEventListener('pointerdown', e => {
  e.stopPropagation();
  if (!shown || state.busy) return;
  sfx.door();
  const rec = activeSession() ? checkoutNow() : null;
  btn.style.display = 'none'; shown = false;
  if (rec) { clearPresence(); showSummary(rec); } else goHome();
});

// called every frame
export function updateGate() {
  const near = state.screen === 'library' && !state.busy && player.position.z > 9 && Math.abs(player.position.x) < 1.6;
  if (near !== shown) { shown = near; btn.style.display = near ? 'block' : 'none'; }
}
