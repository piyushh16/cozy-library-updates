// ACCOUNT: guest by default (no typing), optional email + password so history follows you to any phone
import { accountInfo, linkEmail, loginEmail, logoutAccount, fetchMySessions, sendReset } from './firebase.js';
import { allSessions, getName, replaceAllSessions, clearLocalData, addTestHistory, addTestStreak, addTestChallenge, removeTestHistory } from './checkin.js';
import { clearTestBadges } from './events.js';
import { clearTestAchievements } from './achievements.js';
import { addDangerZone } from './erase.js';
import { cyclePreview, previewLevel, setPreview } from './champion.js';

const css = document.createElement('style');
css.textContent = `
#acct{position:fixed;right:calc(72px + env(safe-area-inset-right,0px));top:calc(10px + env(safe-area-inset-top,0px));width:48px;height:48px;border-radius:50%;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font-size:22px;touch-action:manipulation;box-shadow:0 3px 10px rgba(0,0,0,.4)}
#acctp{position:fixed;inset:0;display:none;z-index:26;overflow-y:auto;background:rgba(32,20,12,.97);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#acctp .wrap{max-width:480px;margin:0 auto}
#acctp .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
#acctp h2{margin:0;font-size:22px}
#acctp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#acctp input{width:100%;box-sizing:border-box;margin-top:10px;padding:12px;font-size:18px;border-radius:10px;border:2px solid #c08a52;background:#fff7e8;color:#2a1a10}
#acctp .b{display:block;width:100%;margin-top:12px;padding:14px;border-radius:24px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 17px Georgia,serif}
#acctp .b:disabled{opacity:.5}
#acctp .note{font-size:14px;opacity:.75;margin-top:4px}
#acctp .msg{margin-top:14px;padding:10px;border-radius:10px;background:rgba(255,243,196,.14);display:none}`;
document.head.appendChild(css);

const btn = document.createElement('button'); btn.id = 'acct'; btn.textContent = '👤'; btn.setAttribute('aria-label', 'Account');
const panel = document.createElement('div'); panel.id = 'acctp';
document.body.append(btn, panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

function friendly(e) {
  switch (e && e.code) {
    case 'auth/email-already-in-use': case 'auth/credential-already-in-use': return 'That email already has an account. Tap "Log in" instead.';
    case 'auth/invalid-credential': case 'auth/wrong-password': case 'auth/user-not-found': case 'auth/invalid-login-credentials': return "Wrong email or password. If you have not created this account yet, tap 'Create account' on your first phone.";
    case 'auth/weak-password': return 'Password needs at least 6 characters.';
    case 'auth/invalid-email': return 'That email address does not look right.';
    case 'auth/operation-not-allowed': return 'Email/Password sign-in is not switched on in Firebase yet.';
    case 'auth/network-request-failed': return 'No internet connection. Try again when you are online.';
    case 'auth/too-many-requests': return 'Too many tries. Wait a little and try again.';
    default: return 'Something went wrong (' + ((e && (e.code || e.message)) || 'unknown') + ').';
  }
}

function render(message) {
  const info = accountInfo();
  const wrap = mk('div', 'wrap'), top = mk('div', 'top');
  const x = mk('button', 'x', '✕'); x.onclick = () => { panel.style.display = 'none'; };
  top.append(mk('h2', '', '👤 Account'), x); wrap.append(top);
  const msg = mk('div', 'msg'); const say = t => { msg.textContent = t; msg.style.display = 'block'; };
  let email, pw; const buttons = [];
  const run = async fn => {
    buttons.forEach(b => { b.disabled = true; });
    try { await fn(); } catch (e) { say(friendly(e) + (e && e.code ? ` (${e.code})` : '')); }
    buttons.forEach(b => { b.disabled = false; });
  };
  if (info && !info.anonymous) {
    wrap.append(mk('p', '', `Signed in as ${info.email}`), mk('div', 'note', 'Your sessions follow this account. Log in with the same email on another phone to see them there.'));
    const out = mk('button', 'b', 'Log out'); buttons.push(out);
    out.onclick = () => run(async () => { await logoutAccount(); clearLocalData(); location.reload(); });
    wrap.append(out, mk('div', 'note', 'After logging out this phone becomes a new guest. Your sessions stay safe online under your account.'));
  } else {
    wrap.append(mk('p', '', 'You are playing as a guest. Nothing to type, and your sessions are saved online for this phone.'));
    email = mk('input'); email.type = 'email'; email.placeholder = 'Email'; email.autocomplete = 'email';
    pw = mk('input'); pw.type = 'password'; pw.placeholder = 'Password (at least 6 characters)'; pw.autocomplete = 'current-password';
    const eye = mk('button', 'b', '👁 Show or hide password'); eye.onclick = () => { pw.type = pw.type === 'password' ? 'text' : 'password'; };
    const reset = mk('button', 'b', 'Forgot password? Email me a reset link');
    reset.onclick = () => run(async () => { await sendReset(email.value.trim()); say('If that email has an account, a reset link is on its way. Check your inbox and spam folder.'); });
    const create = mk('button', 'b', 'Create account (keeps my sessions)'), login = mk('button', 'b', 'Log in (switch to my account)');
    buttons.push(create, login, reset, eye);
    create.onclick = () => run(async () => {
      await linkEmail(email.value.trim(), pw.value);
      render('Account created. Your sessions are now saved under that email.');
    });
    login.onclick = () => run(async () => {
      await loginEmail(email.value.trim(), pw.value);
      say('Loading your sessions...');
      replaceAllSessions(await fetchMySessions());
      location.reload();
    });
    wrap.append(email, pw, eye, create, mk('div', 'note', 'Use this on your first phone. It turns this guest into an account without losing anything.'), login,
      mk('div', 'note', 'Use this on another phone. It replaces this phone\'s guest sessions with the ones saved under your account.'), reset);
  }
  const lv = previewLevel();
  const pv = mk('button', 'b', lv ? `Badge preview: 🔥${lv} (tap to change)` : 'Preview champion badge');
  pv.onclick = () => { cyclePreview(); render(message); };
  const addT = mk('button', 'b', 'Add 3 weeks of test champion history'), remT = mk('button', 'b', 'Remove all test data (and turn off the badge preview)');
  addT.onclick = () => { addTestHistory(); render('Test history added. Your real badge should show 🔥3 within a few seconds.'); };
  remT.onclick = () => { removeTestHistory(); clearTestBadges(); clearTestAchievements(); setPreview(0); render('All test data removed and the badge preview is off.'); };
  const addS = mk('button', 'b', 'Add 4 days of test study streak');
  addS.onclick = () => { addTestStreak(); render('Test streak added. Study at least a minute today to see 🔥5.'); };
  const addC = mk('button', 'b', 'Add test New Year challenge days');
  addC.onclick = () => { addTestChallenge(); render('Added 5 test days of 35 minutes. Open the menu, pick New Year under Seasons, and look at the Home page for the badge.'); };
  wrap.append(mk('p', '', '🧪 Testing'), pv, mk('div', 'note', 'Shows the 🏆 badge and the 🔥 number above your character. Preview only, nothing is saved or awarded.'), addT, addS, addC, remT,
    mk('div', 'note', 'These buttons only make practice data on this phone. It is never sent online. The preview button changes the badge look only, and you can cycle it with 🔥1, 🔥2, 🔥3 and then off.'));
  // Step 25: privacy and data
  wrap.append(mk('p', '', '🔐 Your data'));
  wrap.append(mk('div', 'note', 'Your study sessions are private: only you can read them. People in your study room see only your name and study totals. Friends see only what your profile allows. Private messages are only between you and one friend.'));
  const exp = mk('button', 'b', '📦 Copy a backup of my data');
  exp.onclick = async () => {
    const data = JSON.stringify({ name: getName(), exportedAt: new Date().toISOString(), sessions: allSessions().filter(r => !r.test) }, null, 2);
    try { await navigator.clipboard.writeText(data); say('Copied. Paste it into a note or message to keep a backup.'); } catch { say('Could not copy on this phone.'); }
  };
  wrap.append(exp);
  addDangerZone(wrap, info, say, mk);
  wrap.append(msg);
  if (message) say(message);
  panel.replaceChildren(wrap); panel.scrollTop = 0; panel.style.display = 'block';
}
export const openAccount = () => render();
btn.onclick = () => render();
