// WINDOWS: open and close the windows (the lower sash slides up) and enjoy the view and the weather outside
import { state } from './core.js';
import { player } from './characters.js';
import { windowSpots } from './world.js';
import { emoteToast } from './emote.js';
import { bump } from './stats.js';
import { sfx } from './audio.js';

const KEY = 'cozylib.windows';
let wanted = windowSpots.map(() => false);
try { const s = JSON.parse(localStorage.getItem(KEY)); if (Array.isArray(s)) wanted = windowSpots.map((_, i) => !!s[i]); } catch { /* ignore */ }
export const windowAmount = wanted.map(v => (v ? 1 : 0));
const place = (w, a) => { w.sash.position.y = -0.375 + 0.7 * a; w.sash.position.z = 0.03 + 0.04 * a; };
windowSpots.forEach((w, i) => place(w, windowAmount[i]));

const css = document.createElement('style');
css.textContent = '#windowb{position:fixed;right:calc(20px + env(safe-area-inset-right,0px));bottom:calc(335px + env(safe-area-inset-bottom,0px));display:none;padding:16px 26px;border-radius:32px;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font:600 19px Georgia,serif;touch-action:manipulation;box-shadow:0 4px 14px rgba(0,0,0,.4)}';
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'windowb'; document.body.appendChild(btn);
let near = -1, lastLabel = '';
btn.addEventListener('pointerdown', e => {
  e.stopPropagation();
  if (near < 0) return;
  wanted[near] = !wanted[near];
  if (wanted[near]) bump('windows');
  sfx.window();
  try { localStorage.setItem(KEY, JSON.stringify(wanted)); } catch { /* ignore */ }
  emoteToast(wanted[near] ? '🪟 Window open. Enjoy the fresh air!' : '🪟 Window closed');
});

// called every frame
export function updateWindows(dt) {
  const canUse = !state.busy || /^Window seat/.test(state.spotName || '');
  let best = -1, bd = 1e9;
  if (canUse) {
    windowSpots.forEach((w, i) => {
      const dx = Math.abs(player.position.x - w.x), dz = w.rotY === 0 ? player.position.z - w.z : w.z - player.position.z;
      if (dx < 1.4 && dz > 0 && dz < 2.4 && dx + dz < bd) { bd = dx + dz; best = i; }
    });
  }
  near = best;
  const label = best < 0 ? '' : wanted[best] ? '🪟 Close the window' : '🪟 Open the window';
  if (label !== lastLabel) { lastLabel = label; btn.textContent = label; btn.style.display = label ? 'block' : 'none'; }
  windowSpots.forEach((w, i) => {
    windowAmount[i] += ((wanted[i] ? 1 : 0) - windowAmount[i]) * (1 - Math.exp(-dt * 4));
    place(w, windowAmount[i]);
  });
  state.windowOpen = Math.max(...windowAmount);
}
