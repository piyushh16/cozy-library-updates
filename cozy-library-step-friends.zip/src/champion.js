// CHAMPION: Step 11 weekly Library Champion badge floating above the character
import * as THREE from 'three';
import { player } from './characters.js';
import { getChampion } from './board.js';
import { myUid, weekKeys } from './firebase.js';
import { getName } from './checkin.js';
import { triggerMine } from './emote.js';

let preview = 0, shownLabel = '', sprite = null, lastCheck = 0;
export const previewLevel = () => preview;
export function setPreview(n) { preview = n; lastCheck = 0; }
export function cyclePreview() { preview = (preview + 1) % 4; lastCheck = 0; return preview; }

function makeBadge(label) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = '#f0c48a'; g.strokeStyle = '#4a2c17'; g.lineWidth = 8;
  if (g.roundRect) { g.beginPath(); g.roundRect(6, 6, 500, 116, 40); g.fill(); g.stroke(); } else { g.fillRect(6, 6, 500, 116); g.strokeRect(6, 6, 500, 116); }
  g.fillStyle = '#2a1a10'; g.textAlign = 'center'; g.textBaseline = 'middle';
  let s = 60; g.font = `bold ${s}px Georgia`;
  while (g.measureText(label).width > 450 && s > 20) { s -= 2; g.font = `bold ${s}px Georgia`; }
  g.fillText(label, 256, 68);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  sp.scale.set(1.05, 0.26, 1); sp.position.set(0, 2.12, 0); sp.renderOrder = 10;
  return sp;
}

// one-time message when you become champion
const toastEl = document.createElement('div');
toastEl.style.cssText = 'position:fixed;left:50%;top:calc(110px + env(safe-area-inset-top,0px));transform:translateX(-50%);display:none;z-index:30;max-width:80%;text-align:center;padding:14px 18px;border-radius:16px;border:2px solid #f0c48a;background:rgba(42,26,16,.96);color:#ffe9c4;font:18px Georgia,serif';
document.body.appendChild(toastEl);
function toast(text) { toastEl.textContent = text; toastEl.style.display = 'block'; setTimeout(() => { toastEl.style.display = 'none'; }, 5000); }

// called every frame (checks every 2 seconds)
export function updateChampion() {
  const now = performance.now();
  if (now - lastCheck < 2000) return;
  lastCheck = now;
  const c = getChampion(), id = myUid();
  const mine = !!(c && id && c.key === id);
  const label = preview ? `🏆 ${getName() || 'You'}  🔥${preview} (preview)` : mine ? `🏆 ${c.name}  🔥${c.streak}` : '';
  if (label !== shownLabel) {
    if (sprite) { player.remove(sprite); sprite.material.map.dispose(); sprite.material.dispose(); sprite = null; }
    if (label) { sprite = makeBadge(label); player.add(sprite); }
    shownLabel = label;
  }
  if (mine) {
    try {
      const wk = weekKeys().thisWeek + ':' + c.streak;
      if (localStorage.getItem('cozylib.champSeen') !== wk) {
        localStorage.setItem('cozylib.champSeen', wk);
        triggerMine('party');
        toast(`🏆 You are last week's Library Champion! 🔥 ${c.streak} week${c.streak > 1 ? 's' : ''} in a row. Your badge stays above your head all week.`);
      }
    } catch { /* ignore */ }
  }
}
