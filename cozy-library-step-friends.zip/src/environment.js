// ENVIRONMENT: Step 18 time of day and weather. "Auto" follows the phone clock; the button picks a mood by hand.
import * as THREE from 'three';
import { scene, state } from './core.js';
import { hemi, sun, lampLights, lampMat, windowMats } from './world.js';
import { emoteToast } from './emote.js';
import { setOutside, updateOutside } from './outside.js';

const PRESETS = {
  morning: { name: 'Morning', icon: '☀️', sky: 0xf6e3c0, hemi: 0xfff1d6, ground: 0x7a5a3a, hemiI: 1.4, sun: 0xffe2b0, sunI: 2.2, lamp: 8, glow: 0.3, pane: 0xcfe9ff },
  afternoon: { name: 'Afternoon', icon: '🌤️', sky: 0xbcdcf5, hemi: 0xffffff, ground: 0x8a6a48, hemiI: 1.5, sun: 0xfff6e0, sunI: 2.4, lamp: 5, glow: 0.2, pane: 0xaed6ff },
  evening: { name: 'Evening', icon: '🌆', sky: 0xf0c48a, hemi: 0xffe6c0, ground: 0x6b4a2f, hemiI: 1.3, sun: 0xffd9a0, sunI: 2.0, lamp: 22, glow: 1.2, pane: 0xffc98a },
  night: { name: 'Night', icon: '🌙', sky: 0x141a33, hemi: 0x8aa0ff, ground: 0x2a2438, hemiI: 0.5, sun: 0x7f8fff, sunI: 0.35, lamp: 42, glow: 2.2, pane: 0x1c2447 },
  rainy: { name: 'Rainy', icon: '🌧️', sky: 0x9aa7b3, hemi: 0xdfe8f0, ground: 0x5c5648, hemiI: 1.0, sun: 0xc9d6e6, sunI: 0.9, lamp: 28, glow: 1.4, pane: 0x8f9db0 },
};
const ORDER = ['auto', 'morning', 'afternoon', 'evening', 'night', 'rainy'];
const KEY = 'cozylib.env';
let mode = 'auto';
try { const m = localStorage.getItem(KEY); if (ORDER.includes(m)) mode = m; } catch { /* ignore */ }
const hourKey = () => { const h = new Date().getHours(); return h >= 5 && h < 10 ? 'morning' : h >= 10 && h < 16 ? 'afternoon' : h >= 16 && h < 19 ? 'evening' : 'night'; };
export const envHooks = { forced: null };
const activeKey = () => (mode === 'auto' ? (envHooks.forced || hourKey()) : mode);
export const currentKey = () => activeKey();

// current look (blends smoothly towards the chosen preset)
const C = k => new THREE.Color(PRESETS[k]);
const cur = { sky: C('evening'), hemi: C('evening').set(PRESETS.evening.hemi), ground: new THREE.Color(PRESETS.evening.ground), sun: new THREE.Color(PRESETS.evening.sun), pane: new THREE.Color(PRESETS.evening.pane), hemiI: 1.3, sunI: 2, lamp: 22, glow: 1.2 };
cur.sky.set(PRESETS.evening.sky);
const tgt = { sky: new THREE.Color(), hemi: new THREE.Color(), ground: new THREE.Color(), sun: new THREE.Color(), pane: new THREE.Color() };
function setTarget(key, instant) {
  const p = PRESETS[key];
  state.moodKey = key;
  tgt.sky.set(p.sky); tgt.hemi.set(p.hemi); tgt.ground.set(p.ground); tgt.sun.set(p.sun); tgt.pane.set(p.pane);
  tgt.hemiI = p.hemiI; tgt.sunI = p.sunI; tgt.lamp = p.lamp; tgt.glow = p.glow;
  if (instant) { ['sky', 'hemi', 'ground', 'sun', 'pane'].forEach(n => cur[n].copy(tgt[n])); ['hemiI', 'sunI', 'lamp', 'glow'].forEach(n => { cur[n] = tgt[n]; }); }
  rain.visible = key === 'rainy'; stars.visible = key === 'night';
  windowMats.forEach(m => { m.map = rainTex; m.needsUpdate = true; });
  drawGlass(0, key === 'rainy');
  setOutside(key);
}

// rain outside the walls
const N = 320, rainPos = new Float32Array(N * 6), drops = [];
for (let i = 0; i < N; i++) {
  let x, z;
  do { x = (Math.random() - 0.5) * 34; z = (Math.random() - 0.5) * 40; } while (Math.abs(x) < 8.3 && Math.abs(z) < 10.3);
  drops.push({ x, z, y: Math.random() * 9, v: 11 + Math.random() * 5 });
}
const rainGeo = new THREE.BufferGeometry();
rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPos, 3));
const rain = new THREE.LineSegments(rainGeo, new THREE.LineBasicMaterial({ color: 0xcfdcea, transparent: true, opacity: 0.55, fog: false }));
rain.frustumCulled = false; rain.visible = false; scene.add(rain);

// stars at night
const sp = new Float32Array(180 * 3);
for (let i = 0; i < 180; i++) { const a = Math.random() * Math.PI * 2, r = 38 + Math.random() * 6; sp[i * 3] = Math.cos(a) * r; sp[i * 3 + 1] = 7 + Math.random() * 30; sp[i * 3 + 2] = Math.sin(a) * r; }
const starGeo = new THREE.BufferGeometry(); starGeo.setAttribute('position', new THREE.BufferAttribute(sp, 3));
const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 2.2, sizeAttenuation: false, fog: false }));
stars.visible = false; scene.add(stars);

// raindrops running down the window glass
const rc = document.createElement('canvas'); rc.width = 256; rc.height = 96;
const rg = rc.getContext('2d');
const rainTex = new THREE.CanvasTexture(rc); rainTex.colorSpace = THREE.SRGBColorSpace;
const streaks = Array.from({ length: 22 }, () => ({ x: Math.random() * 256, y: Math.random() * 96, v: 40 + Math.random() * 60 }));
let lastGlass = 0;
function drawGlass(dt, rainy) {
  rg.clearRect(0, 0, 256, 96);
  rg.fillStyle = 'rgba(200,225,255,0.10)'; rg.fillRect(0, 0, 256, 96);
  if (rainy) {
    rg.strokeStyle = 'rgba(190,210,235,0.75)'; rg.lineWidth = 2;
    streaks.forEach(s => { s.y += s.v * dt; if (s.y > 96) { s.y = -10; s.x = Math.random() * 256; } rg.beginPath(); rg.moveTo(s.x, s.y); rg.lineTo(s.x - 1, s.y + 9); rg.stroke(); });
  }
  rainTex.needsUpdate = true;
}

// button
const css = document.createElement('style');
css.textContent = '#envb{position:fixed;right:calc(14px + env(safe-area-inset-right,0px));top:calc(122px + env(safe-area-inset-top,0px));width:48px;height:48px;border-radius:50%;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font-size:22px;touch-action:manipulation;box-shadow:0 3px 10px rgba(0,0,0,.4)}';
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'envb'; btn.setAttribute('aria-label', 'Time of day and weather');
document.body.appendChild(btn);
const refreshButton = () => { btn.textContent = mode === 'auto' ? '🕒' : PRESETS[mode].icon; };
export const MOOD_LIST = ORDER.map(k => ({ key: k, icon: k === 'auto' ? '🕒' : PRESETS[k].icon, name: k === 'auto' ? 'Auto' : PRESETS[k].name }));
export const getMood = () => mode;
export const refreshMood = () => setTarget(activeKey(), false);
export function setMood(m) {
  mode = m;
  try { localStorage.setItem(KEY, mode); } catch { /* ignore */ }
  setTarget(activeKey(), false); refreshButton();
  emoteToast(mode === 'auto' ? `🕒 Auto: follows your clock (${PRESETS[hourKey()].name})` : `${PRESETS[mode].icon} ${PRESETS[mode].name}`);
}
btn.onclick = () => setMood(ORDER[(ORDER.indexOf(mode) + 1) % ORDER.length]);
refreshButton();
setTarget(activeKey(), true);

// called every frame
let lastAuto = 0, flash = 0, nextFlash = performance.now() + 8000;
export function updateEnvironment(dt) {
  const now = performance.now();
  if (mode === 'auto' && now - lastAuto > 30000) { lastAuto = now; setTarget(activeKey(), false); }
  const k = 1 - Math.exp(-dt * 1.6);
  ['sky', 'hemi', 'ground', 'sun', 'pane'].forEach(n => cur[n].lerp(tgt[n], k));
  ['hemiI', 'sunI', 'lamp', 'glow'].forEach(n => { cur[n] += (tgt[n] - cur[n]) * k; });
  if (rain.visible && now > nextFlash) { flash = 1; nextFlash = now + 12000 + Math.random() * 25000; } // lightning
  flash *= Math.exp(-dt * 9);
  scene.background.copy(cur.sky); scene.fog.color.copy(cur.sky);
  hemi.color.copy(cur.hemi); hemi.groundColor.copy(cur.ground); hemi.intensity = cur.hemiI + flash * 2.2;
  sun.color.copy(cur.sun); sun.intensity = cur.sunI;
  lampLights.forEach(l => { l.intensity = cur.lamp; });
  lampMat.emissiveIntensity = cur.glow;
  updateOutside(dt);
  if (rain.visible) {
    drops.forEach((d, i) => { d.y -= d.v * dt; if (d.y < 0) d.y = 9; const o = i * 6; rainPos[o] = d.x; rainPos[o + 1] = d.y; rainPos[o + 2] = d.z; rainPos[o + 3] = d.x; rainPos[o + 4] = d.y + 0.55; rainPos[o + 5] = d.z; });
    rainGeo.attributes.position.needsUpdate = true;
    if (now - lastGlass > 80) { drawGlass((now - lastGlass) / 1000, true); lastGlass = now; }
  }
}
