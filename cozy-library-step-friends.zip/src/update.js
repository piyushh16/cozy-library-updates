// UPDATE: tells the player when a new version is ready and opens the download. The files live in a separate public place, never in the code repository.
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Browser } from '@capacitor/browser';

export const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : 0;
const BASE = 'piyushh16/cozy-library-updates';
const VERSION_URL = `https://raw.githubusercontent.com/${BASE}/main/version.json`;
export const APK_URL = `https://github.com/${BASE}/releases/latest/download/cozy-library.apk`;

export let updateInfo = { checked: false, available: false, build: BUILD, notes: '', error: '' };
const cbs = [];
export const onUpdate = cb => cbs.push(cb);

async function notifyOnce(build) {
  try {
    if (localStorage.getItem('cozylib.updNotified') === String(build)) return;
    localStorage.setItem('cozylib.updNotified', String(build));
    if (!Capacitor.isNativePlatform()) return;
    let p = await LocalNotifications.checkPermissions();
    if (p.display === 'prompt' || p.display === 'prompt-with-rationale') p = await LocalNotifications.requestPermissions();
    if (p.display !== 'granted') return;
    await LocalNotifications.schedule({ notifications: [{ id: 9001, title: 'Cozy Library update', body: 'A new version is ready. Open the app and tap Update to get it.', schedule: { at: new Date(Date.now() + 1500) } }] });
  } catch { /* ignore */ }
}
export async function checkUpdate(force) {
  try {
    const r = await fetch(VERSION_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (r.status === 404) { updateInfo = { checked: true, available: false, build: BUILD, notes: '', error: '' }; cbs.forEach(cb => cb(updateInfo)); return updateInfo; }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json(), build = Number(j.build) || 0;
    updateInfo = { checked: true, available: build > BUILD, build, notes: String(j.notes || ''), error: '' };
    if (updateInfo.available) notifyOnce(build);
  } catch (e) {
    updateInfo = { ...updateInfo, checked: true, error: force ? 'Could not check. Check your internet and try again.' : '' };
  }
  cbs.forEach(cb => cb(updateInfo));
  return updateInfo;
}
// the phone downloads the new file and Android installs it over this app. Your sessions and settings stay, because it is the same app.
export async function downloadUpdate() {
  try { if (Capacitor.isNativePlatform()) await Browser.open({ url: APK_URL }); else window.open(APK_URL, '_blank'); } catch { window.open(APK_URL, '_blank'); }
}
setTimeout(() => checkUpdate(false), 4000);
setInterval(() => checkUpdate(false), 6 * 3600 * 1000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) checkUpdate(false); });
