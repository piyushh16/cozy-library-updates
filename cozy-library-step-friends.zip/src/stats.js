// STATS: small counters (books taken, chat messages, ...), levels and the shirt colour
const K = 'cozylib.counts';
const read = () => { try { return JSON.parse(localStorage.getItem(K)) || {}; } catch { return {}; } };
export const count = n => read()[n] || 0;
export function bump(n) {
  const c = read(); c[n] = (c[n] || 0) + 1;
  try { localStorage.setItem(K, JSON.stringify(c)); } catch { /* ignore */ }
}
export const SHIRTS = [0x3f7fbf, 0xc0504d, 0x4f8a4a, 0xe0a030, 0x7a4e9c, 0x2f8f9d, 0xd96a8a, 0x555b66];
export const getShirt = () => { try { return Number(localStorage.getItem('cozylib.shirt')) || 0; } catch { return 0; } };
export const setShirt = h => { try { localStorage.setItem('cozylib.shirt', String(h)); } catch { /* ignore */ } };

export const LEVELS = [[0, 'Newcomer'], [5, 'Reader'], [20, 'Bookworm'], [50, 'Scholar'], [100, 'Sage'], [250, 'Professor'], [500, 'Legend']];
export function levelInfo(ms) {
  const h = ms / 3600000;
  let i = 0; LEVELS.forEach(([t], k) => { if (h >= t) i = k; });
  const next = LEVELS[i + 1];
  return { level: i + 1, title: LEVELS[i][1], next: next ? next[1] : null, pct: next ? (h - LEVELS[i][0]) / (next[0] - LEVELS[i][0]) : 1, hoursToNext: next ? next[0] - h : 0 };
}

// what other people may see about me: 'all' (level, rank, achievements) or 'name' (only my name)
export const getPrivacy = () => { try { return localStorage.getItem('cozylib.privacy') || 'all'; } catch { return 'all'; } };
export const setPrivacy = v => { try { localStorage.setItem('cozylib.privacy', v); } catch { /* ignore */ } };
