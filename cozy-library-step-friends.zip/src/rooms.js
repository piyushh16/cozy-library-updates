// ROOMS: Step 14 private friends room (a short code; only people with the code can join)
import { doc, getDoc, setDoc, updateDoc, onSnapshot, arrayUnion, arrayRemove } from 'firebase/firestore';
import { db, myUid, onReady } from './firebase.js';
import { getName } from './checkin.js';

const RKEY = 'cozylib.room';
const readLocal = () => { try { return localStorage.getItem(RKEY) || ''; } catch { return ''; } };
let roomId = readLocal(), room = null, unsub = null, ready = false;
const cbs = [];
export const getRoomId = () => roomId;
export const getRoom = () => room;
let statusOf = () => '';
export const setStatusProvider = fn => { statusOf = fn; };
export function onRoomChange(cb) { cbs.push(cb); if (ready) cb(roomId, room); }

// ---- screen
const css = document.createElement('style');
css.textContent = `
#roomb{position:fixed;right:calc(130px + env(safe-area-inset-right,0px));top:calc(10px + env(safe-area-inset-top,0px));width:48px;height:48px;border-radius:50%;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font-size:22px;touch-action:manipulation;box-shadow:0 3px 10px rgba(0,0,0,.4)}
#roomp{position:fixed;inset:0;display:none;z-index:26;overflow-y:auto;background:rgba(32,20,12,.97);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#roomp .wrap{max-width:480px;margin:0 auto}
#roomp .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
#roomp h2{margin:0;font-size:22px}
#roomp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#roomp input{width:100%;box-sizing:border-box;margin-top:10px;padding:12px;font-size:20px;letter-spacing:4px;text-transform:uppercase;border-radius:10px;border:2px solid #c08a52;background:#fff7e8;color:#2a1a10}
#roomp .b{display:block;width:100%;margin-top:12px;padding:14px;border-radius:24px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 17px Georgia,serif}
#roomp .b:disabled{opacity:.5}
#roomp .note{font-size:14px;opacity:.75;margin-top:6px}
#roomp .code{font-size:40px;font-weight:700;letter-spacing:8px;text-align:center;margin:10px 0;color:#f0c48a}
#roomp .m{display:flex;justify-content:space-between;align-items:center;background:rgba(255,243,196,.12);border-radius:12px;padding:10px 12px;margin-top:8px}
#roomp .m button{padding:8px 14px;border-radius:16px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 14px Georgia,serif}
#roomp .msg{margin-top:14px;padding:10px;border-radius:10px;background:rgba(255,243,196,.14);display:none}`;
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'roomb'; btn.textContent = '🏠'; btn.setAttribute('aria-label', 'Study room');
const panel = document.createElement('div'); panel.id = 'roomp';
document.body.append(btn, panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

function friendly(e) {
  const c = e && e.code;
  if (c === 'not-found') return 'No room with that code. Check the letters and try again.';
  if (c === 'permission-denied') return 'Firebase will not allow this yet. The new rules need to be published in the Firebase console (Firestore > Rules).';
  if (c === 'unavailable') return 'No internet connection. Try again when you are online.';
  return 'Something went wrong (' + ((e && (e.code || e.message)) || 'unknown') + ').';
}
let lookup = () => '';
export const setNameLookup = fn => { lookup = fn; };
function nameOf(id) {
  if (id === myUid()) return getName() || 'You';
  return lookup(id) || 'Member';
}
function render(message) {
  const wrap = mk('div', 'wrap'), top = mk('div', 'top');
  const x = mk('button', 'x', '✕'); x.onclick = () => { panel.style.display = 'none'; };
  top.append(mk('h2', '', '🏠 Study room'), x); wrap.append(top);
  const msg = mk('div', 'msg'); const say = t => { msg.textContent = t; msg.style.display = 'block'; };
  const buttons = [];
  const run = async fn => {
    buttons.forEach(b => { b.disabled = true; });
    try { await fn(); } catch (e) { say(friendly(e)); }
    buttons.forEach(b => { b.disabled = false; });
  };
  if (!roomId) {
    wrap.append(mk('p', '', 'Study together with friends. You will see each other in the library, and the board only shows the people in your room.'));
    const create = mk('button', 'b', 'Create a room');
    create.onclick = () => run(async () => { const code = await createRoom(); render(`Room ${code} created. Share this code with your friends.`); });
    const input = mk('input'); input.placeholder = 'ROOM CODE'; input.maxLength = 6; input.autocomplete = 'off';
    const join = mk('button', 'b', 'Join this room');
    join.onclick = () => run(async () => { await joinRoom(input.value); render('You joined the room.'); });
    buttons.push(create, join);
    wrap.append(create, mk('div', 'note', 'or enter a code from a friend'), input, join);
  } else {
    const ids = room ? room.memberUids : [myUid()], owner = room && room.ownerUid;
    wrap.append(mk('div', 'note', 'Room code. Share it with your friends:'), mk('div', 'code', roomId));
    const copy = mk('button', 'b', 'Copy code');
    copy.onclick = async () => { try { await navigator.clipboard.writeText(roomId); say('Code copied.'); } catch { say('Could not copy. The code is ' + roomId); } };
    wrap.append(copy, mk('div', 'note', `Members (${ids.length})`));
    ids.forEach(id => {
      const row = mk('div', 'm'), left = mk('div');
      left.append(mk('div', '', `${id === owner ? '★ ' : ''}${nameOf(id)}${id === myUid() ? ' (you)' : ''}`), mk('div', 'note', statusOf(id)));
      row.append(left);
      if (owner === myUid() && id !== myUid()) {
        const rm = mk('button', '', 'Remove'); buttons.push(rm);
        rm.onclick = () => run(async () => { await removeMember(id); say('Removed from the room.'); });
        row.append(rm);
      }
      wrap.append(row);
    });
    if (owner !== myUid()) {
      const leave = mk('button', 'b', 'Leave room'); buttons.push(leave);
      leave.onclick = () => run(async () => { await leaveRoom(); render('You left the room.'); });
      wrap.append(leave);
    } else wrap.append(mk('div', 'note', 'You made this room, so you can remove people from it. Removed people disappear from your board and from the library.'));
  }
  wrap.append(msg);
  if (message) say(message);
  panel.replaceChildren(wrap); panel.scrollTop = 0; panel.style.display = 'block';
}
export const openRooms = () => render();
btn.onclick = () => render();

// ---- room data
function notify() { cbs.forEach(cb => cb(roomId, room)); if (panel.style.display === 'block') render(); }
function setLocal(id) { roomId = id; try { if (id) localStorage.setItem(RKEY, id); else localStorage.removeItem(RKEY); } catch { /* ignore */ } }
function saveUserRoom(id) { if (myUid()) setDoc(doc(db, 'users', myUid()), { roomId: id }, { merge: true }).catch(() => {}); }
function watch() {
  if (unsub) { unsub(); unsub = null; }
  room = null;
  if (!roomId) { notify(); return; }
  unsub = onSnapshot(doc(db, 'rooms', roomId), snap => {
    if (!snap.exists() || !snap.data().memberUids.includes(myUid())) {
      setLocal(''); saveUserRoom(''); room = null; notify();
      return;
    }
    room = snap.data(); notify();
  }, e => { if (e && e.code === 'permission-denied') { setLocal(''); saveUserRoom(''); room = null; notify(); } /* offline: keep what we have */ });
}
const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const makeCode = () => Array.from({ length: 6 }, () => CHARS[Math.floor(Math.random() * CHARS.length)]).join('');

export async function createRoom() {
  if (!myUid()) throw Object.assign(new Error('offline'), { code: 'unavailable' });
  const code = makeCode();
  const p = setDoc(doc(db, 'rooms', code), { code, ownerUid: myUid(), memberUids: [myUid()], createdAt: Date.now() });
  setLocal(code); saveUserRoom(code); watch();
  p.catch(e => { setLocal(''); saveUserRoom(''); watch(); if (panel.style.display === 'block') render(friendly(e)); });
  return code;
}
export async function joinRoom(raw) {
  const code = String(raw).trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) throw Object.assign(new Error('not found'), { code: 'not-found' });
  if (!myUid()) throw Object.assign(new Error('offline'), { code: 'unavailable' });
  try { await updateDoc(doc(db, 'rooms', code), { memberUids: arrayUnion(myUid()) }); } catch (e) {
    // rooms are private: a wrong code and a code you cannot join both look like "no such room"
    if (e && (e.code === 'permission-denied' || e.code === 'not-found')) {
      try { const r = await getDoc(doc(db, 'rooms', code)); if (!r.exists()) throw e; } catch (e2) { if (e2 && e2.code === 'permission-denied') throw Object.assign(new Error('not found'), { code: 'not-found' }); throw e2; }
    } else throw e;
  }
  setLocal(code); saveUserRoom(code); watch();
}
export async function leaveRoom() {
  const id = roomId; if (!id) return;
  await updateDoc(doc(db, 'rooms', id), { memberUids: arrayRemove(myUid()) });
  setLocal(''); saveUserRoom(''); watch();
}
export async function removeMember(id) { await updateDoc(doc(db, 'rooms', roomId), { memberUids: arrayRemove(id) }); }

onReady(async id => {
  try {
    const u = await getDoc(doc(db, 'users', id));
    if (u.exists() && u.data().roomId && !roomId) setLocal(u.data().roomId);
  } catch { /* ignore */ }
  ready = true; watch();
});
