// INTERACTIONS: Step 2 bookshelves (take a book, put it back)
import * as THREE from 'three';
import { scene, sm, state } from './core.js';
import { player } from './characters.js';
import { shelves, bookMats, bookIM } from './world.js';
import { titleFor, ICONS } from './books.js';
import { bump } from './stats.js';
import { sfx } from './audio.js';

// ---------- interactions (Step 2: bookshelves) ----------
let heldShelf = null, heldIdx = -1;
const taken = new Set();
export const tweens = [];
export const tween = (d, fn) => new Promise(r => tweens.push({ t: 0, d, fn, r }));
export const ease = k => k * k * (3 - 2 * k), lerp = (a, b, k) => a + (b - a) * k;
const ZERO = new THREE.Matrix4().makeScale(0, 0, 0);
const act = document.getElementById('act');
let nearShelf = null, lastLabel = '';

function shelfDist(s) {
  const dx = Math.max(s.bb.x0 - player.position.x, 0, player.position.x - s.bb.x1);
  const dz = Math.max(s.bb.z0 - player.position.z, 0, player.position.z - s.bb.z1);
  return Math.hypot(dx, dz);
}
export function updatePrompt() {
  let best = null, bd = 1.0;
  if (!state.busy) for (const s of shelves) { const d = shelfDist(s); if (d < bd) { bd = d; best = s; } }
  if (state.held && best !== heldShelf) best = null;
  nearShelf = best;
  const label = best ? (state.held ? '📖 Put book back' : '📚 Browse books') : '';
  if (label !== lastLabel) { lastLabel = label; act.textContent = label; act.style.display = label ? 'block' : 'none'; }
  const hold = state.held ? `📖 ${state.heldTitle}` : '';
  if (hold !== lastHold) { lastHold = hold; holdEl.textContent = hold; holdEl.style.display = hold ? 'block' : 'none'; }
}
act.addEventListener('pointerdown', e => {
  e.stopPropagation();
  if (!nearShelf || state.busy) return;
  state.held ? putBack(nearShelf) : openBrowse(nearShelf);
});
function pickBook(sh) {
  const c = [];
  for (let i = sh.start; i < sh.end; i++) { const y = bookMats[i].elements[13]; if (y > 1.0 && y < 1.75 && !taken.has(i)) c.push(i); }
  return c.length ? c[(Math.random() * c.length) | 0] : -1;
}
async function walkTo(sh, i) {
  const bp = new THREE.Vector3(), q = new THREE.Quaternion(), sc = new THREE.Vector3();
  bookMats[i].decompose(bp, q, sc);
  const f = sh.face, stand = new THREE.Vector3(bp.x + f.x * 0.85, 0, bp.z + f.z * 0.85);
  const p0 = player.position.clone(), r0 = player.rotation.y;
  let d = Math.atan2(-f.x, -f.z) - r0; d = Math.atan2(Math.sin(d), Math.cos(d));
  state.forceWalk = true;
  await tween(0.6, k => { const e = ease(k); player.position.lerpVectors(p0, stand, e); player.rotation.y = r0 + d * e; });
  state.forceWalk = false; state.faceT = player.rotation.y;
  return { bp, q, sc, f };
}
async function takeBook(sh, idx) {
  const i = idx === undefined ? pickBook(sh) : idx; if (i < 0) return;
  state.busy = true;
  const { bp, q, sc, f } = await walkTo(sh, i);
  const R = player.userData.arms[1], F = R.userData.fore;
  await tween(0.5, k => { const e = ease(k); R.rotation.x = lerp(0, -1.45, e); F.rotation.x = lerp(-0.3, -0.15, e); });
  const col = new THREE.Color(); bookIM.getColorAt(i, col);
  const hb = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), sm(col.getHex(), 0.7));
  hb.position.copy(bp); hb.quaternion.copy(q); hb.scale.copy(sc); hb.castShadow = true; scene.add(hb);
  bookIM.setMatrixAt(i, ZERO); bookIM.instanceMatrix.needsUpdate = true; taken.add(i);
  const out = bp.clone().addScaledVector(f, 0.35);
  sfx.page();
  await tween(0.4, k => hb.position.lerpVectors(bp, out, ease(k)));
  F.attach(hb);
  const qf = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, Math.PI / 2, 0));
  const p1 = hb.position.clone(), q1 = hb.quaternion.clone(), s1 = hb.scale.clone();
  const tp = new THREE.Vector3(0, -0.34, 0.05), ts = new THREE.Vector3(0.04, 0.3, 0.2);
  await tween(0.6, k => {
    const e = ease(k);
    R.rotation.x = lerp(-1.45, -0.7, e); F.rotation.x = lerp(-0.15, -0.9, e);
    hb.position.lerpVectors(p1, tp, e); hb.quaternion.slerpQuaternions(q1, qf, e); hb.scale.lerpVectors(s1, ts, e);
  });
  state.held = hb; heldShelf = sh; heldIdx = i; state.heldTitle = titleOf(sh, i); bump('books'); state.busy = false;
}
async function putBack(sh) {
  const hb = state.held, i = heldIdx; state.held = null; state.busy = true;
  const { bp, q, sc, f } = await walkTo(sh, i);
  const R = player.userData.arms[1], F = R.userData.fore;
  scene.attach(hb); sfx.page();
  const out = bp.clone().addScaledVector(f, 0.35);
  const p1 = hb.position.clone(), q1 = hb.quaternion.clone(), s1 = hb.scale.clone();
  await tween(0.6, k => {
    const e = ease(k);
    R.rotation.x = lerp(-0.7, -1.45, e); F.rotation.x = lerp(-0.9, -0.15, e);
    hb.position.lerpVectors(p1, out, e); hb.quaternion.slerpQuaternions(q1, q, e); hb.scale.lerpVectors(s1, sc, e);
  });
  await tween(0.35, k => hb.position.lerpVectors(out, bp, ease(k)));
  bookIM.setMatrixAt(i, bookMats[i]); bookIM.instanceMatrix.needsUpdate = true; taken.delete(i);
  scene.remove(hb);
  await tween(0.4, k => { const e = ease(k); R.rotation.x = lerp(-1.45, 0, e); F.rotation.x = lerp(-0.15, -0.3, e); });
  heldShelf = null; heldIdx = -1; state.heldTitle = ''; state.busy = false;
}


export function dropHeldBook() {
  if (!state.held) return;
  scene.remove(state.held);
  bookIM.setMatrixAt(heldIdx, bookMats[heldIdx]); bookIM.instanceMatrix.needsUpdate = true;
  taken.delete(heldIdx); state.held = null; state.heldTitle = ''; heldShelf = null; heldIdx = -1;
}

// ---- Step 19: browse a shelf by category and pick a book
let lastHold = '';
const bcss = document.createElement('style');
bcss.textContent = `
#browse{position:fixed;inset:0;display:none;z-index:25;overflow-y:auto;background:rgba(32,20,12,.97);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#browse .wrap{max-width:480px;margin:0 auto}
#browse .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
#browse h2{margin:0;font-size:22px}
#browse .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#browse .note{font-size:14px;opacity:.75;margin-bottom:12px}
#browse .bk{display:flex;align-items:center;gap:12px;width:100%;text-align:left;margin-bottom:8px;padding:12px;border-radius:12px;border:1px solid rgba(255,233,196,.35);background:rgba(255,243,196,.1);color:#ffe9c4;font:600 16px Georgia,serif}
#browse .sw{width:14px;height:34px;border-radius:3px;flex:none}
#holding{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(102px + env(safe-area-inset-top,0px));display:none;color:#ffe9c4;background:rgba(42,26,16,.75);padding:6px 12px;border-radius:14px;font:15px Georgia,serif;pointer-events:none;max-width:calc(100vw - 110px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}`;
document.head.appendChild(bcss);
const browse = document.createElement('div'); browse.id = 'browse';
const holdEl = document.createElement('div'); holdEl.id = 'holding';
document.body.append(browse, holdEl);

function allCands(sh) {
  if (!sh.cands) {
    sh.cands = [];
    for (let i = sh.start; i < sh.end; i++) { const y = bookMats[i].elements[13]; if (y > 1.0 && y < 1.75) sh.cands.push(i); }
  }
  return sh.cands;
}
function titleOf(sh, i) { const k = allCands(sh).indexOf(i); return titleFor(sh.cat, k < 0 ? 0 : k); }
function openBrowse(sh) {
  const mkEl = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
  const wrap = mkEl('div', 'wrap'), top = mkEl('div', 'top');
  const x = mkEl('button', 'x', '✕'); x.onclick = () => { browse.style.display = 'none'; };
  top.append(mkEl('h2', '', `${ICONS[sh.cat] || '📚'} ${sh.cat} shelf`), x);
  wrap.append(top, mkEl('div', 'note', 'Pick a book to take it off the shelf.'));
  const col = new THREE.Color();
  allCands(sh).slice(0, 14).forEach(i => {
    if (taken.has(i)) return;
    bookIM.getColorAt(i, col);
    const b = mkEl('button', 'bk'), sw = mkEl('span', 'sw');
    sw.style.background = '#' + col.getHexString();
    b.append(sw, mkEl('span', '', titleOf(sh, i)));
    b.onclick = () => { browse.style.display = 'none'; takeBook(sh, i); };
    wrap.append(b);
  });
  browse.replaceChildren(wrap); browse.scrollTop = 0; browse.style.display = 'block';
}
