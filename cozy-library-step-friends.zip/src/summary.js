// SUMMARY: the checkout summary shown when a visit ends
import { state } from './core.js';
import { hooks, allSessions, studiedMs, dur, fmt } from './checkin.js';
import { streakInfo } from './streak.js';
import { readStandings } from './board.js';
import { myUid } from './firebase.js';
import { goHome } from './home.js';

const css = document.createElement('style');
css.textContent = `
#summary{position:fixed;inset:0;display:none;z-index:21;overflow-y:auto;background:rgba(32,20,12,.98);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(20px + env(safe-area-inset-top,0px)) 16px calc(28px + env(safe-area-inset-bottom,0px))}
#summary .wrap{max-width:480px;margin:0 auto}
#summary h1{margin:0 0 4px;font-size:26px}
#summary h3{margin:18px 0 6px;font-size:17px;color:#f0c48a}
#summary .sub{opacity:.8;margin-bottom:6px}
#summary .r{display:flex;justify-content:space-between;gap:10px;background:rgba(255,243,196,.1);border-radius:12px;padding:10px 12px;margin-bottom:6px}
#summary .r b{text-align:right}
#summary .b{display:block;width:100%;margin-top:14px;padding:16px;border-radius:26px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:700 18px Georgia,serif}
#summary .b.alt{background:transparent;font-weight:600}`;
document.head.appendChild(css);
const root = document.createElement('div'); root.id = 'summary'; document.body.appendChild(root);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const row = (l, v) => { const r = mk('div', 'r'); r.append(mk('span', '', l), mk('b', '', v)); return r; };

export function showSummary(rec, opts = {}) {
  if (!opts.stay) state.screen = 'summary';
  const wrap = mk('div', 'wrap');
  wrap.append(mk('h1', '', '📚 Library checkout'), mk('div', 'sub', `Great work, ${rec.studentName}!`));
  wrap.append(mk('h3', '', "This visit"), row('⏱️ Study time', dur(rec.totalStudyMs || 0)));
  if (rec.breakMs) wrap.append(row('☕ Break time', dur(rec.breakMs)));
  wrap.append(row('🪑 Desk', rec.desk || 'None'), row('🕐 Check-in', fmt(rec.checkIn)),
    row('🕐 Study started', rec.studyStart ? fmt(rec.studyStart) : '-'), row('🕐 Study finished', rec.studyEnd ? fmt(rec.studyEnd) : '-'),
    row('🕐 Checkout', fmt(rec.checkOut)));
  const all = allSessions();
  let today = 0, total = 0;
  all.forEach(r => { const ms = studiedMs(r); total += ms; if (r.date === rec.date) today += ms; });
  const rows = readStandings().weekly, i = rows.findIndex(r => r.key === myUid());
  wrap.append(mk('h3', '', 'Your progress'), row('🔥 Study streak', `${streakInfo().current} day${streakInfo().current === 1 ? '' : 's'}`),
    row("📖 Today's total", dur(today)), row('📚 Total study time', dur(total)), row('🏆 Position this week', i >= 0 ? `#${i + 1} of ${rows.length}` : '-'));
  const home = mk('button', 'b', 'RETURN HOME'); home.onclick = () => { root.style.display = 'none'; goHome(); };
  wrap.append(home);
  if (opts.stay) { const stay = mk('button', 'b alt', 'Stay in the library'); stay.onclick = () => { root.style.display = 'none'; }; wrap.append(stay); }
  root.replaceChildren(wrap); root.scrollTop = 0; root.style.display = 'block';
}
hooks.onCheckout = showSummary;
