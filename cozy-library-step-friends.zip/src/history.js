// HISTORY: Step 8 study history (today / week / month / overall + every session)
import { allSessions, dur, fmt } from './checkin.js';
import { syncStatus } from './firebase.js';
import { streakInfo } from './streak.js';

const css = document.createElement('style');
css.textContent = `
#hist{position:fixed;right:calc(14px + env(safe-area-inset-right,0px));top:calc(10px + env(safe-area-inset-top,0px));width:48px;height:48px;border-radius:50%;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font-size:22px;touch-action:manipulation;box-shadow:0 3px 10px rgba(0,0,0,.4)}
#histp{position:fixed;inset:0;display:none;z-index:25;overflow-y:auto;-webkit-overflow-scrolling:touch;background:rgba(32,20,12,.97);color:#ffe9c4;font:16px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#histp .wrap{max-width:520px;margin:0 auto}
#histp .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
#histp h2{margin:0;font-size:22px}
#histp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#histp .cards{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px}
#histp .card{background:rgba(255,233,196,.1);border:1px solid rgba(255,233,196,.3);border-radius:14px;padding:12px}
#histp .card .l{font-size:13px;opacity:.75}
#histp .card .v{font-size:22px;font-weight:700;margin-top:2px}
#histp h3{margin:0 0 8px;font-size:17px;color:#f0c48a}
#histp .s{background:rgba(255,233,196,.08);border-radius:12px;padding:10px 12px;margin-bottom:8px}
#histp .s .a{display:flex;justify-content:space-between;font-weight:700}
#histp .s .b{font-size:14px;opacity:.9;margin-top:2px}
#histp .empty{opacity:.75;padding:12px 0}`;
document.head.appendChild(css);

const btn = document.createElement('button'); btn.id = 'hist'; btn.textContent = '📊'; btn.setAttribute('aria-label', 'Study history');
const panel = document.createElement('div'); panel.id = 'histp';
document.body.append(btn, panel);

const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const studied = r => (r.totalStudyMs || 0) + (r.runningSince ? Date.now() - new Date(r.runningSince).getTime() : 0);

function render() {
  const all = allSessions().slice().sort((a, b) => new Date(b.checkIn) - new Date(a.checkIn));
  const now = new Date();
  const todayKey = dayKey(now);
  const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7));
  const monthKey = todayKey.slice(0, 7);
  let today = 0, week = 0, month = 0, overall = 0;
  for (const r of all) {
    const ms = studied(r), d = new Date(r.checkIn);
    overall += ms;
    if (r.date === todayKey) today += ms;
    if (d >= weekStart) week += ms;
    if (String(r.date).slice(0, 7) === monthKey) month += ms;
  }
  const wrap = mk('div', 'wrap');
  const top = mk('div', 'top'); top.append(mk('h2', '', '📚 Study history'));
  const x = mk('button', 'x', '✕'); x.onclick = () => { panel.style.display = 'none'; }; top.append(x);
  const cards = mk('div', 'cards');
  [['Today', today], ['This week', week], ['This month', month], ['Overall', overall]].forEach(([l, v]) => {
    const c = mk('div', 'card'); c.append(mk('div', 'l', l), mk('div', 'v', dur(v))); cards.append(c);
  });
  const st = streakInfo(), sc = mk('div', 'card');
  sc.style.gridColumn = '1 / -1';
  sc.append(mk('div', 'l', 'Study streak (days in a row)'), mk('div', 'v', `🔥 ${st.current}  ·  best ${st.best}`));
  cards.append(sc);
  wrap.append(top, mk('div', 'empty', `☁ Online sync: ${syncStatus()}`), cards, mk('h3', '', `Sessions (${all.length})`));
  if (!all.length) wrap.append(mk('div', 'empty', 'No sessions yet. Check in with the librarian to start.'));
  for (const r of all) {
    const s = mk('div', 's'), a = mk('div', 'a'), b = mk('div', 'b');
    a.append(mk('span', '', new Date(r.checkIn).toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' })), mk('span', '', (r.test ? '🧪 ' : '') + (r.desk || 'No desk')));
    b.textContent = `Check-in ${fmt(r.checkIn)} · Study ${dur(studied(r))}${r.breakMs ? ' · Break ' + dur(r.breakMs) : ''} · ${r.checkOut ? 'Checkout ' + fmt(r.checkOut) : r.runningSince ? 'Studying now' : 'Not checked out'}`;
    s.append(a, b); wrap.append(s);
  }
  panel.replaceChildren(wrap); panel.scrollTop = 0;
}
export function openHistory() { render(); panel.style.display = 'block'; }
btn.onclick = openHistory;
