// MAIN: loads every module and runs the game loop
import * as THREE from 'three';
import { renderer, scene, cam, state, solids } from './core.js';
import { sun } from './world.js';
import { player, librarian, resolve } from './characters.js';
import { input } from './input.js';
import { tweens, updatePrompt } from './interactions.js';
import { updateTalk } from './checkin.js';
import { updateSit } from './desks.js';
import { updateStudyHud } from './study.js';
import './history.js';
import './account.js';
import { updateBoard } from './board.js';
import { updateChampion } from './champion.js';
import { updateStreak } from './streak.js';
import './rooms.js';
import './lb.js';
import './buddies.js';
import './update.js';
import './settings.js';
import './chat.js';
import { updateFriends } from './friends.js';
import { updateLounge } from './lounge.js';
import { updateEnvironment } from './environment.js';
import { updateCozy } from './cozy.js';
import { updateWindows } from './windows.js';
import { updateEvents } from './events.js';
import { updateAchievements } from './achievements.js';
import { updateAudio, sfx } from './audio.js';
import './ui.js';
import './home.js';
import './summary.js';
import { updateGate } from './gate.js';
import './social.js';
import { applyEmote, mine } from './emote.js';

// ---------- loop ----------
const clock = new THREE.Clock();
let lastRender = 0, walkT = 0, amp = 0, started = false, fpsAcc = 0, fpsN = 0, perfLevel = 0, lastPh = 0;
const camPos = new THREE.Vector3(0, 3, 13);
// the camera sits behind the player but moves closer when a wall or a tall shelf is in the way
function cameraGoal() {
  const px = player.position.x, pz = player.position.z, d = 5;
  let cx = Math.min(Math.max(px + Math.sin(input.yaw) * d, -7.1), 7.1), cz = Math.min(Math.max(pz + Math.cos(input.yaw) * d, -9.6), 9.8), cy = 3;
  const dx = cx - px, dz = cz - pz, m = 0.3;
  let tHit = 1;
  for (const s of solids) {
    let t0 = 0, t1 = 1, hit = true;
    for (const [p, dd, lo, hi] of [[px, dx, s.x0 - m, s.x1 + m], [pz, dz, s.z0 - m, s.z1 + m]]) {
      if (Math.abs(dd) < 1e-6) { if (p < lo || p > hi) { hit = false; break; } } else {
        let a = (lo - p) / dd, b = (hi - p) / dd; if (a > b) { const x = a; a = b; b = x; }
        t0 = Math.max(t0, a); t1 = Math.min(t1, b); if (t0 > t1) { hit = false; break; }
      }
    }
    if (!hit || t0 <= 0.001) continue;
    if (1.3 + 1.7 * t0 < (s.h === undefined ? 4 : s.h) && t0 < tHit) tHit = t0;
  }
  if (tHit < 1) { const f = Math.max(0.28, tHit - 0.06); cx = px + dx * f; cz = pz + dz * f; cy = 1.3 + 1.7 * f; }
  return new THREE.Vector3(cx, cy, cz);
}

function frame() {
  requestAnimationFrame(frame);
  // while you sit and study the picture barely changes, so draw 30 times a second to save battery
  if (state.seated && !state.busy && performance.now() - lastRender < 32) return;
  lastRender = performance.now();
  if (document.hidden) { clock.getDelta(); return; }
  if (state.screen !== 'library' && started) { clock.getDelta(); return; }
  const rawDt = clock.getDelta(), dt = Math.min(rawDt, 0.05);
  // if the phone is struggling, lower the picture sharpness a little, then switch the sun shadows off
  if (rawDt < 0.25 && ++fpsN >= 100) {
    fpsAcc += rawDt;
    if (fpsAcc / fpsN > 1 / 26 && perfLevel < 3) {
      perfLevel++;
      if (perfLevel <= 2) { renderer.setPixelRatio(Math.max(1, renderer.getPixelRatio() * 0.8)); renderer.setSize(innerWidth, innerHeight); } else sun.castShadow = false;
    }
    fpsAcc = 0; fpsN = 0;
  } else if (rawDt < 0.25) fpsAcc += rawDt;
  for (let i = tweens.length - 1; i >= 0; i--) { const w = tweens[i]; w.t += dt; const k = Math.min(1, w.t / w.d); w.fn(k); if (k >= 1) { tweens.splice(i, 1); w.r(); } }
  const ix = input.jx + (input.keys.d ? 1 : 0) - (input.keys.a ? 1 : 0), iy = input.jy + (input.keys.w ? 1 : 0) - (input.keys.s ? 1 : 0);
  const mag = Math.min(1, Math.hypot(ix, iy));
  let moving = mag > 0.12 && !state.busy;
  if (moving) {
    const fx = -Math.sin(input.yaw), fz = -Math.cos(input.yaw), rx = Math.cos(input.yaw), rz = -Math.sin(input.yaw);
    let mx = rx * ix + fx * iy, mz = rz * ix + fz * iy; const l = Math.hypot(mx, mz); mx /= l; mz /= l;
    const sp = 3.2 * mag;
    player.position.x += mx * sp * dt; player.position.z += mz * sp * dt;
    resolve(player.position);
    state.faceT = Math.atan2(mx, mz); walkT += dt * sp * 3.2;
  }
  if (!state.busy) { let df = state.faceT - player.rotation.y; df = Math.atan2(Math.sin(df), Math.cos(df)); player.rotation.y += df * (1 - Math.exp(-dt * 12)); }
  if (state.forceWalk) walkT += dt * 8;
  { const ph = Math.floor(walkT / Math.PI); if (ph !== lastPh) { lastPh = ph; if (moving || state.forceWalk) sfx.step(); } }
  amp += ((moving || state.forceWalk ? 1 : 0) - amp) * (1 - Math.exp(-dt * 10));
  const u = player.userData, sw = Math.sin(walkT) * 0.7 * amp;
  u.legs[0].rotation.x = sw + (-1.5 - sw) * state.sitK; u.legs[1].rotation.x = -sw + (-1.5 + sw) * state.sitK;
  u.arms[0].rotation.x = -sw * 0.8 + (-0.5 + sw * 0.8) * state.sitK;
  u.arms[0].userData.fore.rotation.x = -0.3 - 0.6 * state.sitK;
  const R1 = u.arms[1], F1 = R1.userData.fore;
  if (state.held) { R1.rotation.x = -0.7; F1.rotation.x = -0.9; }
  else if (!state.busy || state.sitK > 0) { R1.rotation.x = sw * 0.8 + (-0.5 - sw * 0.8) * state.sitK; F1.rotation.x = -0.3 - 0.6 * state.sitK; }
  u.body.position.y = Math.abs(Math.sin(walkT)) * 0.05 * amp;
  applyEmote(player, mine.k, mine.k ? (performance.now() - mine.t0) / 1000 : -1);
  const t = clock.elapsedTime;
  const lu = librarian.userData;
  lu.head.rotation.z = Math.sin(t * 0.8) * 0.05;
  // the librarian types at the counter and glances around
  if (!lu.waving) lu.arms[1].rotation.x = -0.75 + Math.sin(t * 5) * 0.07;
  lu.arms[0].rotation.x = -0.75 + Math.sin(t * 4.3 + 1) * 0.07;
  lu.arms[0].userData.fore.rotation.x = -0.9 + Math.sin(t * 5.1) * 0.08;
  lu.arms[1].userData.fore.rotation.x = -0.9 + Math.sin(t * 4.7) * 0.08;
  lu.head.rotation.y = Math.sin(t * 0.35) * 0.4;
  lu.body.position.y = Math.sin(t * 1.6) * 0.01;
  const want = cameraGoal();
  camPos.lerp(want, 1 - Math.exp(-dt * 6));
  cam.position.copy(camPos); cam.lookAt(player.position.x, 1.3, player.position.z);
  updatePrompt();
  updateTalk();
  updateSit();
  updateStudyHud();
  updateBoard();
  updateChampion();
  updateStreak();
  updateFriends(dt);
  updateLounge();
  updateEnvironment(dt);
  updateCozy();
  updateWindows(dt);
  updateEvents(dt);
  updateAchievements();
  updateAudio();
  updateGate();
  renderer.render(scene, cam);
  if (!started) { started = true; setTimeout(() => document.getElementById('loading').classList.add('done'), 600); }
}
frame();
