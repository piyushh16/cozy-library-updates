// PROFILE: Step 20 game-style player profile (level, stats, achievements preview, shirt colour)
import { player, recolorPerson } from './characters.js';
import { getName, dur } from './checkin.js';
import { getMetrics, achievementList, openAchievements } from './achievements.js';
import { publishProfile } from './buddies.js';
import { levelInfo, SHIRTS, getShirt, setShirt, getPrivacy, setPrivacy } from './stats.js';

const saved = getShirt();
if (saved) recolorPerson(player, saved);

const css = document.createElement('style');
css.textContent = `
#profp{position:fixed;inset:0;display:none;z-index:25;overflow-y:auto;-webkit-overflow-scrolling:touch;background:linear-gradient(#2a1a10,#4a2c17);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#profp .wrap{max-width:480px;margin:0 auto}
#profp .top{display:flex;justify-content:flex-end}
#profp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#profp .hero{text-align:center;margin:-10px 0 14px}
#profp .crown{height:28px;font-size:24px}
#profp .av{width:92px;height:92px;border-radius:50%;margin:0 auto;border:4px solid #f0c48a;display:flex;align-items:center;justify-content:center;font:700 44px Georgia,serif;color:#fff;text-shadow:0 2px 4px rgba(0,0,0,.4)}
#profp h1{margin:8px 0 0;font-size:28px;letter-spacing:1px}
#profp .lv{opacity:.85}
#profp .xp{height:10px;border-radius:5px;background:rgba(255,255,255,.15);overflow:hidden;margin:10px 20px 4px}
#profp .xp i{display:block;height:100%;background:linear-gradient(90deg,#f0c48a,#ffe9a0)}
#profp .xpt{font-size:13px;opacity:.7}
#profp .grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:16px 0}
#profp .card{background:rgba(255,233,196,.1);border:1px solid rgba(255,233,196,.3);border-radius:14px;padding:12px}
#profp .card .l{font-size:13px;opacity:.75}
#profp .card .v{font-size:20px;font-weight:700;margin-top:2px}
#profp h3{margin:14px 0 8px;font-size:17px;color:#f0c48a}
#profp .row{display:flex;flex-wrap:wrap;gap:8px}
#profp .sw{width:38px;height:38px;border-radius:50%;border:3px solid transparent;padding:0}
#profp .sw.on{border-color:#ffe9c4}
#profp .ach{display:flex;gap:6px;flex-wrap:wrap;font-size:28px}
#profp .ach span.lock{filter:grayscale(1);opacity:.35}
#profp .b{display:block;width:100%;margin-top:12px;padding:14px;border-radius:24px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 17px Georgia,serif}`;
document.head.appendChild(css);
const panel = document.createElement('div'); panel.id = 'profp'; document.body.appendChild(panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const hex = n => '#' + n.toString(16).padStart(6, '0');

export function openProfile() {
  const m = getMetrics(), lv = levelInfo(m.total), name = getName() || 'Guest', list = achievementList();
  const shirt = getShirt() || SHIRTS[0];
  const wrap = mk('div', 'wrap'), top = mk('div', 'top');
  const x = mk('button', 'x', '✕'); x.onclick = () => { panel.style.display = 'none'; }; top.append(x);
  const hero = mk('div', 'hero'), av = mk('div', 'av', name.charAt(0).toUpperCase()); av.style.background = hex(shirt);
  const xp = mk('div', 'xp'), fill = mk('i'); fill.style.width = `${Math.round(lv.pct * 100)}%`; xp.append(fill);
  hero.append(mk('div', 'crown', m.champStreak ? '👑' : ''), av, mk('h1', '', name.toUpperCase()), mk('div', 'lv', `Level ${lv.level} · ${lv.title}`), xp,
    mk('div', 'xpt', lv.next ? `${lv.hoursToNext.toFixed(1)} h to ${lv.next}` : 'Top level reached'));
  const grid = mk('div', 'grid');
  [['📚 Total study time', dur(m.total)], ['🔥 Study streak', `${m.curStreak} · best ${m.bestStreak}`], ['📖 Sessions', String(m.sessions)], ['⏱️ Longest session', dur(m.longest)],
    ['🏆 Champion weeks', `${m.champWeeks}${m.champStreak ? ` · 🔥${m.champStreak} in a row` : ''}`], ['🏅 Achievements', `${list.filter(a => a.unlocked).length} / ${list.length}`],
    ['🪑 Favourite desk', m.favDesk || '-'], ['📅 Member since', m.first ? new Date(m.first).toLocaleDateString([], { month: 'short', year: 'numeric' }) : '-']].forEach(([l, v]) => {
    const c = mk('div', 'card'); c.append(mk('div', 'l', l), mk('div', 'v', v)); grid.append(c);
  });
  const sw = mk('div', 'row');
  SHIRTS.forEach(c => {
    const b = mk('button', c === shirt ? 'sw on' : 'sw'); b.style.background = hex(c);
    b.onclick = () => { setShirt(c); recolorPerson(player, c); openProfile(); };
    sw.append(b);
  });
  const ach = mk('div', 'ach'); list.forEach(a => ach.append(mk('span', a.unlocked ? '' : 'lock', a.icon)));
  const all = mk('button', 'b', 'See all achievements'); all.onclick = openAchievements;
  const pv = mk('button', 'b', getPrivacy() === 'all' ? '👁 Others see: my level and achievements (tap to hide)' : '🔒 Others see: only my name (tap to share)');
  pv.onclick = () => { setPrivacy(getPrivacy() === 'all' ? 'name' : 'all'); publishProfile(true); openProfile(); };
  wrap.append(top, hero, grid, mk('h3', '', 'Shirt colour (friends see it too)'), sw, mk('h3', '', 'Achievements'), ach, all, pv, mk('div', 'note', 'Study time, sessions and history are never shown to others except the board totals in your study room.'));
  panel.replaceChildren(wrap); panel.scrollTop = 0; panel.style.display = 'block';
}
