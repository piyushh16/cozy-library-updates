// AUDIO: Step 23 soft sound effects, room ambience and optional music, all made with WebAudio (no sound files)
import { state } from './core.js';

const KEY = 'cozylib.audio2';
const cfg = { sfx: true, music: true, vol: 0.7 };
try { Object.assign(cfg, JSON.parse(localStorage.getItem(KEY)) || {}); } catch { /* ignore */ }
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch { /* ignore */ } };
const R = (a, b) => a + Math.random() * (b - a);

let ctx = null, master, sfxBus, ambBus, musicBus, noiseBuf, amb = null, wantScene = false;

function loopNoise(type, f, q) {
  const src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
  const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q;
  const g = ctx.createGain(); g.gain.value = 0;
  src.connect(fl); fl.connect(g); g.connect(ambBus); src.start(0, Math.random());
  return g;
}
function ensure() {
  if (ctx) return ctx;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  ctx = new AC();
  master = ctx.createGain(); master.gain.value = cfg.vol; master.connect(ctx.destination);
  sfxBus = ctx.createGain(); ambBus = ctx.createGain(); musicBus = ctx.createGain();
  [sfxBus, ambBus, musicBus].forEach(b => b.connect(master));
  sfxBus.gain.value = cfg.sfx ? 1 : 0; ambBus.gain.value = 0; musicBus.gain.value = 0;
  const len = ctx.sampleRate * 2; noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = noiseBuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  amb = { room: loopNoise('lowpass', 260, 0.7), rain: loopNoise('bandpass', 2800, 0.35), wind: loopNoise('lowpass', 520, 0.6) };
  return ctx;
}
const applyAmb = () => { if (ctx) ambBus.gain.setTargetAtTime(wantScene && cfg.sfx ? 1 : 0, ctx.currentTime, 0.5); };

// ---- building blocks
function noise({ type = 'bandpass', f = 1000, q = 1, dur = 0.1, gain = 0.3, attack = 0.004, bus = sfxBus, vary = 0.15 }) {
  const t = ctx.currentTime, src = ctx.createBufferSource(); src.buffer = noiseBuf;
  const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.value = f * (1 + (Math.random() - 0.5) * vary * 2); fl.Q.value = q;
  const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(gain, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + attack + dur);
  src.connect(fl); fl.connect(g); g.connect(bus); src.start(t, Math.random() * 1.5, dur + attack + 0.05);
}
function tone({ f = 440, f2 = f, dur = 0.2, gain = 0.2, type = 'sine', attack = 0.005, delay = 0, bus = sfxBus }) {
  const t = ctx.currentTime + delay, o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t);
  if (f2 !== f) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
  const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(gain, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(bus); o.start(t); o.stop(t + dur + 0.05);
}
const ok = () => ctx && cfg.sfx && ctx.state === 'running';
const g = fn => (...a) => { if (ok()) fn(...a); };

export const sfx = {
  step: g(() => { noise({ f: 260, q: 1.2, dur: 0.07, gain: 0.2 }); tone({ f: 110, f2: 70, dur: 0.06, gain: 0.1 }); }),
  page: g((s = 1) => noise({ f: 3200, q: 0.7, dur: 0.2, gain: 0.15 * s, attack: 0.04 })),
  chair: g(() => { noise({ f: 320, q: 1, dur: 0.22, gain: 0.18, attack: 0.03 }); tone({ f: 130, f2: 80, dur: 0.18, gain: 0.1 }); }),
  door: g(() => { tone({ f: 95, f2: 55, dur: 0.18, gain: 0.3 }); noise({ type: 'lowpass', f: 400, dur: 0.15, gain: 0.22 }); tone({ f: 2093, dur: 0.6, gain: 0.06, delay: 0.12 }); tone({ f: 2637, dur: 0.7, gain: 0.05, delay: 0.2 }); }),
  bell: g(() => { tone({ f: 1568, dur: 1.1, gain: 0.13 }); tone({ f: 2349, dur: 0.9, gain: 0.07 }); }),
  chime: g(() => [523.25, 659.25, 783.99].forEach((f, i) => tone({ f, dur: 0.7, gain: 0.1, delay: i * 0.12 }))),
  pen: g(() => { for (let i = 0; i < 3; i++) setTimeout(() => { if (ok()) noise({ f: 4200, q: 2, dur: 0.05, gain: 0.06, attack: 0.01 }); }, i * 90); }),
  click: g(() => tone({ f: 880, f2: 700, dur: 0.04, gain: 0.06 })),
  unlock: g(() => [659.25, 783.99, 987.77, 1318.5].forEach((f, i) => tone({ f, dur: 0.5, gain: 0.09, delay: i * 0.1 }))),
  pop: g(() => tone({ f: 500, f2: 900, dur: 0.12, gain: 0.09 })),
  ding: g(() => { tone({ f: 1200, dur: 0.35, gain: 0.08 }); tone({ f: 1800, dur: 0.3, gain: 0.05, delay: 0.05 }); }),
  window: g(() => noise({ f: 500, q: 0.8, dur: 0.5, gain: 0.16, attack: 0.1 })),
};
const chirp = () => { for (let i = 0; i < 3; i++) tone({ f: R(2400, 3200), f2: R(3200, 4200), dur: 0.09, gain: 0.025, delay: i * 0.13, bus: ambBus }); };
const crickets = () => { for (let i = 0; i < 6; i++) tone({ f: 4300, dur: 0.04, gain: 0.02, delay: i * 0.07, bus: ambBus }); };

// ---- optional music: slow chords with a few soft notes and an echo
const CHORDS = [[57, 60, 64, 67], [53, 57, 60, 64], [48, 52, 55, 59], [55, 59, 62, 65]];
const PENT = [69, 72, 74, 76, 79, 81];
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
const MT = { timer: 0, next: 0, bar: 0, delay: null };
function voice(type, f, t0, attack, hold, rel, gain) {
  const o = ctx.createOscillator(); o.type = type; o.frequency.value = f;
  const gn = ctx.createGain(); gn.gain.setValueAtTime(0.0001, t0); gn.gain.exponentialRampToValueAtTime(gain, t0 + attack);
  gn.gain.setValueAtTime(gain, t0 + attack + hold); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + attack + hold + rel);
  const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1100;
  o.connect(lp); lp.connect(gn); gn.connect(musicBus); gn.connect(MT.delay); o.start(t0); o.stop(t0 + attack + hold + rel + 0.1);
}
function musicTick() {
  if (!ctx) return;
  while (MT.next < ctx.currentTime + 3) {
    const t0 = MT.next;
    CHORDS[MT.bar % CHORDS.length].forEach(m => voice('triangle', mtof(m), t0, 1.4, 2, 1.6, 0.035));
    for (let i = 0, n = 3 + ((Math.random() * 2) | 0); i < n; i++) voice('sine', mtof(PENT[(Math.random() * PENT.length) | 0]), t0 + R(0.3, 3.5), 0.02, 0.05, 1.6, 0.07);
    MT.next += 4; MT.bar++;
  }
}
function startMusic() {
  if (!ctx || MT.timer) return;
  MT.next = ctx.currentTime + 0.2; MT.bar = 0;
  if (!MT.delay) {
    const d = ctx.createDelay(1); d.delayTime.value = 0.42;
    const fb = ctx.createGain(); fb.gain.value = 0.38;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400;
    d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(musicBus); MT.delay = d;
  }
  MT.timer = setInterval(musicTick, 800); musicTick();
}
const stopMusic = () => { clearInterval(MT.timer); MT.timer = 0; };
// soft music plays only on the Home page. In the library you hear the room, the weather and the pens instead.
function applyMusic() {
  if (!ctx) return;
  const want = cfg.music && !wantScene;
  musicBus.gain.setTargetAtTime(want ? 0.5 : 0, ctx.currentTime, want ? 0.8 : 0.4);
  if (want) startMusic(); else setTimeout(() => { if (!(cfg.music && !wantScene)) stopMusic(); }, 1500);
}

// ---- settings
export const audioConfig = () => ({ ...cfg });
export function setSfx(on) { cfg.sfx = on; save(); if (ctx) { sfxBus.gain.setTargetAtTime(on ? 1 : 0, ctx.currentTime, 0.05); applyAmb(); } }
export function setMusic(on) {
  cfg.music = on; save(); ensure();
  if (!ctx) return;
  if (ctx.state !== 'running') ctx.resume();
  applyMusic();
}
export function setVolume(v) { cfg.vol = v; save(); if (ctx) master.gain.setTargetAtTime(v, ctx.currentTime, 0.05); }
export function setScene(on) { wantScene = on; applyAmb(); applyMusic(); }

// the browser only allows sound after a tap, so everything starts on the first touch
addEventListener('pointerdown', () => {
  if (!ensure()) return;
  if (ctx.state !== 'running') ctx.resume();
  if (state.screen === 'library') wantScene = true;
  applyAmb(); applyMusic();
}, { passive: true });
// try to start the Home music straight away (it starts on the first touch if the phone does not allow it yet)
setTimeout(() => { if (ensure()) { ctx.resume().catch(() => {}); applyMusic(); } }, 400);
document.addEventListener('pointerdown', e => { const b = e.target && e.target.closest ? e.target.closest('button') : null; if (b) sfx.click(); }, true);
document.addEventListener('visibilitychange', () => { if (!ctx) return; if (document.hidden) ctx.suspend(); else ctx.resume(); });

// called every frame in the library: rain, wind, birds, crickets and pen scratches follow what is happening
let nextBird = 0, nextPen = 0;
export function updateAudio() {
  if (!ctx || ctx.state !== 'running' || !wantScene) return;
  const now = ctx.currentTime, t = performance.now(), open = state.windowOpen || 0, key = state.moodKey;
  amb.room.gain.setTargetAtTime(0.045, now, 0.5);
  amb.rain.gain.setTargetAtTime(key === 'rainy' ? 0.04 + 0.1 * open : 0, now, 0.7);
  amb.wind.gain.setTargetAtTime(open * (0.03 + 0.02 * Math.sin(t / 2500)), now, 0.6);
  if (open > 0.5 && t > nextBird) {
    nextBird = t + R(2500, 6500);
    if (key === 'morning' || key === 'afternoon') chirp(); else if (key === 'night') crickets();
  }
  if (state.seated && state.deskName && t > nextPen) { nextPen = t + R(3500, 9000); sfx.pen(); }
}
