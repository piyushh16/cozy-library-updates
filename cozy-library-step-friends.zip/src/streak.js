// STREAK: Step 13 daily study streak (separate from the weekly champion counter)
import { allSessions, studiedMs } from './checkin.js';

// a day counts when you studied at least this long (1 minute for now so it is easy to test; raise it later)
const MIN_DAY_MS = 60 * 1000;
const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const daysAgo = n => { const d = new Date(); return dayKey(new Date(d.getFullYear(), d.getMonth(), d.getDate() - n)); };
const dayNum = key => { const [y, m, d] = key.split('-').map(Number); return Math.round(Date.UTC(y, m - 1, d) / 86400000); };

export function streakInfo() {
  const byDay = new Map();
  for (const r of allSessions()) byDay.set(r.date, (byDay.get(r.date) || 0) + studiedMs(r));
  const ok = k => (byDay.get(k) || 0) >= MIN_DAY_MS;
  const studiedToday = ok(daysAgo(0));
  // the streak stays alive until the end of today, so start from yesterday if today has no study yet
  const start = studiedToday ? 0 : ok(daysAgo(1)) ? 1 : -1;
  let current = 0;
  if (start >= 0) while (ok(daysAgo(start + current))) current++;
  const days = [...byDay.keys()].filter(ok).map(dayNum).sort((a, b) => a - b);
  let best = 0, run = 0;
  days.forEach((n, i) => { run = i && n === days[i - 1] + 1 ? run + 1 : 1; best = Math.max(best, run); });
  return { current, best, studiedToday };
}

const css = document.createElement('style');
css.textContent = '#streak{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(138px + env(safe-area-inset-top,0px));display:none;color:#ffe9c4;background:rgba(42,26,16,.75);padding:6px 12px;border-radius:14px;font:15px Georgia,serif;pointer-events:none;max-width:calc(100vw - 110px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}';
document.head.appendChild(css);
const hud = document.createElement('div'); hud.id = 'streak'; document.body.appendChild(hud);

// called every frame (checks every 2 seconds)
let last = '', lastCheck = 0;
export function updateStreak() {
  const now = performance.now();
  if (now - lastCheck < 2000) return;
  lastCheck = now;
  const s = streakInfo();
  const label = s.current ? `🔥 ${s.current}-day streak${s.studiedToday ? '' : ' · study today to keep it'}` : '';
  if (label === last) return;
  last = label; hud.textContent = label; hud.style.display = label ? 'block' : 'none';
}
