// CHECK-IN: Step 3 librarian conversation and study-session record
import { state } from './core.js';
import { player, librarian } from './characters.js';
import { tween, ease } from './interactions.js';
import { pushSession, initSync, weekStartKey, myUid } from './firebase.js';
import { sfx } from './audio.js';

const KEY = 'cozylib.sessions', NAME = 'cozylib.name';
let rawCache = null, parsed = [];
const load = () => {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw !== rawCache) { rawCache = raw; parsed = JSON.parse(raw) || []; }
    return parsed;
  } catch { return []; }
};
const save = a => { try { localStorage.setItem(KEY, JSON.stringify(a)); } catch { /* storage unavailable */ } };
export const getName = () => { try { return localStorage.getItem(NAME) || ''; } catch { return ''; } };
export const allSessions = load;
// testing only: fake champion history for the past 3 weeks, kept on this phone and never sent online
export function addTestHistory() {
  const all = load().filter(r => !String(r.id).startsWith('T-test')), name = getName() || 'Tester';
  for (let k = 1; k <= 3; k++) {
    const [y, m, d] = weekStartKey(k).split('-').map(Number);
    const t0 = new Date(y, m - 1, d + 2, 18, 0), t1 = new Date(t0.getTime() + 2 * 3600 * 1000);
    all.push({ id: 'T-test' + k, test: true, uid: myUid(), studentName: name, date: dayKey(t0), checkIn: t0.toISOString(), desk: 'Desk 01', studyStart: t0.toISOString(), studyEnd: t1.toISOString(), totalStudyMs: 2 * 3600 * 1000, runningSince: null, checkOut: t1.toISOString() });
  }
  save(all);
}
export function addTestStreak() {
  const all = load().filter(r => !String(r.id).startsWith('T-streak'));
  for (let k = 1; k <= 4; k++) {
    const t0 = new Date(); t0.setDate(t0.getDate() - k); t0.setHours(18, 0, 0, 0);
    const t1 = new Date(t0.getTime() + 30 * 60 * 1000);
    all.push({ id: 'T-streak' + k, test: true, uid: myUid(), studentName: getName() || 'Tester', date: dayKey(t0), checkIn: t0.toISOString(), desk: 'Desk 01', studyStart: t0.toISOString(), studyEnd: t1.toISOString(), totalStudyMs: 30 * 60 * 1000, runningSince: null, checkOut: t1.toISOString() });
  }
  save(all);
}
export function addTestChallenge() {
  const all = load().filter(r => !String(r.id).startsWith('T-chal'));
  for (let k = 0; k < 5; k++) {
    const t0 = new Date(); t0.setDate(t0.getDate() - k); t0.setHours(19, 0, 0, 0);
    const t1 = new Date(t0.getTime() + 35 * 60 * 1000);
    all.push({ id: 'T-chal' + k, test: true, uid: myUid(), studentName: getName() || 'Tester', date: dayKey(t0), checkIn: t0.toISOString(), desk: 'Desk 01', studyStart: t0.toISOString(), studyEnd: t1.toISOString(), totalStudyMs: 35 * 60 * 1000, runningSince: null, checkOut: t1.toISOString() });
  }
  save(all);
}
export function removeTestHistory() { save(load().filter(r => !r.test)); }
export function replaceAllSessions(arr) {
  save(arr);
  try { localStorage.removeItem('cozylib.room'); } catch { /* ignore */ }
  try {
    const last = [...arr].sort((a, b) => String(b.checkIn).localeCompare(String(a.checkIn)))[0];
    if (last) localStorage.setItem(NAME, last.studentName);
  } catch { /* ignore */ }
}
export function clearLocalData() { try { localStorage.removeItem(KEY); localStorage.removeItem(NAME); localStorage.removeItem('cozylib.room'); } catch { /* ignore */ } }
export const studiedMs = r => (r.totalStudyMs || 0) + (r.runningSince ? Date.now() - new Date(r.runningSince).getTime() : 0);
export const activeSession = () => load().find(s => !s.checkOut) || null;
export const fmt = iso => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
const pad = n => String(n).padStart(2, '0');
export const dur = ms => { const t = Math.floor(ms / 1000), h = Math.floor(t / 3600), m = Math.floor(t / 60) % 60, sec = t % 60; return h ? `${h}h ${m}m` : m ? `${m}m ${sec}s` : `${sec}s`; };
const dayKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// ---- UI
const css = document.createElement('style');
css.textContent = `
#talk{position:fixed;right:calc(20px + env(safe-area-inset-right,0px));bottom:calc(110px + env(safe-area-inset-bottom,0px));display:none;padding:16px 26px;border-radius:32px;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font:600 19px Georgia,serif;touch-action:manipulation;box-shadow:0 4px 14px rgba(0,0,0,.4)}
#chip{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(66px + env(safe-area-inset-top,0px));display:none;color:#ffe9c4;background:rgba(42,26,16,.75);padding:6px 12px;border-radius:14px;font:14px Georgia,serif;pointer-events:none;max-width:calc(100vw - 110px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#dlg{position:fixed;left:12px;right:12px;top:calc(60px + env(safe-area-inset-top,0px));display:none;z-index:20;background:rgba(42,26,16,.96);border:2px solid #ffe9c4;border-radius:18px;padding:16px;color:#ffe9c4;font:18px/1.4 Georgia,serif;max-width:480px;margin:0 auto;touch-action:manipulation}
#dlg .msg{white-space:pre-line}
#dlg .who{font-weight:700;margin-bottom:6px;color:#f0c48a}
#dlg input{width:100%;box-sizing:border-box;margin-top:12px;padding:12px;font-size:18px;border-radius:10px;border:2px solid #c08a52;background:#fff7e8;color:#2a1a10}
#dlg .btns{display:flex;gap:10px;margin-top:12px;justify-content:flex-end}
#dlg button{padding:12px 20px;border-radius:24px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 17px Georgia,serif}`;
document.head.appendChild(css);
const el = (tag, id) => { const e = document.createElement(tag); e.id = id; document.body.appendChild(e); return e; };
const talkBtn = el('button', 'talk'); talkBtn.textContent = '💬 Talk to librarian';
const chip = el('div', 'chip');
const dlg = el('div', 'dlg');
dlg.innerHTML = '<div class="who">Librarian</div><div class="msg"></div><input maxlength="20" autocomplete="off" placeholder="Your name"><div class="btns"></div>';
const msg = dlg.querySelector('.msg'), inp = dlg.querySelector('input'), btns = dlg.querySelector('.btns');

function say(text, { input = false, value = '', buttons }) {
  msg.textContent = text; inp.style.display = input ? 'block' : 'none'; inp.value = value;
  btns.replaceChildren(...buttons.map(([label, fn]) => { const b = document.createElement('button'); b.textContent = label; b.onclick = fn; return b; }));
  dlg.style.display = 'block';
  if (input) setTimeout(() => inp.focus(), 50);
}
const close = () => { dlg.style.display = 'none'; state.busy = false; };
function refreshChip() {
  const s = activeSession();
  chip.style.display = s ? 'block' : 'none';
  if (s) chip.textContent = `✔ ${s.studentName} · ${fmt(s.checkIn)}${s.desk ? ' · ' + s.desk : ''}`;
}
refreshChip();

// ---- remember the chosen desk in the session record (Step 4)
export function setSessionDesk(name) {
  const all = load(), s = all.find(r => !r.checkOut);
  if (!s) return false;
  s.desk = name; save(all); pushSession(s); refreshChip();
  return true;
}

export function updateSession(fn) {
  const all = load(), s = all.find(r => !r.checkOut);
  if (!s) return null;
  fn(s); save(all); pushSession(s);
  return s;
}

// ---- librarian waves hello
async function wave() {
  const lu = librarian.userData, A = lu.arms[1], F = A.userData.fore;
  lu.waving = true;
  await tween(1.3, k => {
    const up = Math.min(1, k / 0.2) * (k > 0.8 ? (1 - k) / 0.2 : 1);
    A.rotation.x = -2.7 * up; F.rotation.z = Math.sin(k * 30) * 0.5 * up;
  });
  F.rotation.z = 0; lu.waving = false;
}

// ---- conversation
async function talk() {
  sfx.bell();
  state.busy = true; talkBtn.style.display = 'none';
  const dx = librarian.position.x - player.position.x, dz = librarian.position.z - player.position.z;
  const r0 = player.rotation.y; let d = Math.atan2(dx, dz) - r0; d = Math.atan2(Math.sin(d), Math.cos(d));
  await tween(0.4, k => { player.rotation.y = r0 + d * ease(k); });
  state.faceT = player.rotation.y;
  wave();
  const s = activeSession();
  if (s) return say(`Welcome back, ${s.studentName}.\nYour study time this session: ${dur(s.totalStudyMs || 0)}.\nReady to check out?\nWalking out through the gate checks you out too.`, { buttons: [['Not yet', close], ['Check out', checkOut]] });
  const saved = getName();
  say(saved ? `Welcome back, ${saved}. Shall I check you in?` : "Welcome to the library! What's your name?",
    { input: true, value: saved, buttons: [['Not now', close], ['Check in', checkIn]] });
}
function checkIn() {
  const name = inp.value.trim().slice(0, 20);
  if (!name) return say('Please tell me your name so I can write it down.', { input: true, buttons: [['Not now', close], ['Check in', checkIn]] });
  const now = new Date();
  const rec = {
    id: 'S-' + now.getTime().toString(36) + Math.random().toString(36).slice(2, 5),
    studentName: name, date: dayKey(now), checkIn: now.toISOString(),
    desk: null, studyStart: null, studyEnd: null, totalStudyMs: 0, runningSince: null, checkOut: null,
  };
  save([...load(), rec]); pushSession(rec);
  try { localStorage.setItem(NAME, name); } catch { /* ignore */ }
  refreshChip(); sfx.chime();
  say(`Nice to meet you, ${name}. You're checked in at ${fmt(rec.checkIn)}. Enjoy the library!`, { buttons: [['OK', close]] });
}

export const hooks = { onCheckout: null };
// ends the current visit: stops a running study stretch and records the checkout time
export function checkoutNow() {
  const now = new Date(); let done = null;
  updateSession(s => {
    if (s.runningSince) { s.totalStudyMs = (s.totalStudyMs || 0) + (now - new Date(s.runningSince)); s.studyEnd = now.toISOString(); s.runningSince = null; }
    s.checkOut = now.toISOString(); done = { ...s };
  });
  refreshChip();
  return done;
}
function checkOut() {
  const done = checkoutNow(); sfx.bell();
  close();
  if (done && hooks.onCheckout) hooks.onCheckout(done, { stay: true });
}

// ---- prompt near the counter (called every frame)
let shown = false;
export function updateTalk() {
  const near = !state.busy && player.position.z > 5 && Math.hypot(player.position.x + 4, player.position.z - 5) < 2.2;
  if (near !== shown) { shown = near; talkBtn.style.display = near ? 'block' : 'none'; }
}
talkBtn.addEventListener('pointerdown', e => { e.stopPropagation(); if (shown && !state.busy) talk(); });

// a visit left open (and not studying) for 6 hours is closed automatically at the last activity time
function autoCloseStale() {
  const all = load(), s = all.find(r => !r.checkOut);
  if (!s || s.runningSince) return;
  const last = s.studyEnd || s.checkIn;
  if (Date.now() - new Date(last).getTime() < 6 * 3600 * 1000) return;
  s.checkOut = last; s.autoClosed = true; save(all); pushSession(s); refreshChip();
}
autoCloseStale();
initSync(load);
