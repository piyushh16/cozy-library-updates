// DESKS: Step 4 numbered desks, "Sit here", walking into the chair, standing up
import * as THREE from 'three';
import { scene, state } from './core.js';
import { desks } from './world.js';
import { player } from './characters.js';
import { tween, ease } from './interactions.js';
import { setSessionDesk, activeSession } from './checkin.js';
import { startStudy, stopStudy } from './study.js';
import { sfx } from './audio.js';

const list = [...desks].sort((a, b) => a.z - b.z || a.x - b.x).map((d, i) => ({ ...d, name: 'Desk ' + String(i + 1).padStart(2, '0') }));
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

// nameplate on every desk
list.forEach(d => {
  const c = document.createElement('canvas'); c.width = 160; c.height = 60;
  const g = c.getContext('2d');
  g.fillStyle = '#f3e3c3'; g.fillRect(0, 0, 160, 60);
  g.strokeStyle = '#4a2c17'; g.lineWidth = 4; g.strokeRect(2, 2, 156, 56);
  g.fillStyle = '#4a2c17'; g.font = 'bold 30px Georgia'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(d.name, 80, 31);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.15), new THREE.MeshBasicMaterial({ map: t }));
  m.rotation.x = -Math.PI / 2; m.position.set(d.x, 0.806, d.z + 0.28); scene.add(m);
});

// UI
const css = document.createElement('style');
css.textContent = `
#sit{position:fixed;right:calc(20px + env(safe-area-inset-right,0px));bottom:calc(185px + env(safe-area-inset-bottom,0px));display:none;padding:16px 26px;border-radius:32px;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font:600 19px Georgia,serif;touch-action:manipulation;box-shadow:0 4px 14px rgba(0,0,0,.4)}
#toast{position:fixed;left:50%;top:calc(70px + env(safe-area-inset-top,0px));transform:translateX(-50%);display:none;z-index:30;max-width:80%;text-align:center;padding:12px 18px;border-radius:16px;border:2px solid #ffe9c4;background:rgba(42,26,16,.95);color:#ffe9c4;font:17px Georgia,serif}`;
document.head.appendChild(css);
const sitBtn = document.createElement('button'); sitBtn.id = 'sit'; document.body.appendChild(sitBtn);
const toastEl = document.createElement('div'); toastEl.id = 'toast'; document.body.appendChild(toastEl);
let toastTimer = 0;
function toast(text) {
  toastEl.textContent = text; toastEl.style.display = 'block';
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.style.display = 'none'; }, 2600);
}

// sit / stand
let near = null, transit = false, sideP = null, lastLabel = '';
async function sit(d) {
  if (!setSessionDesk(d.name)) { toast('Please check in with the librarian first.'); return; }
  transit = true; state.busy = true;
  const side = player.position.x < d.x ? -1 : 1;
  sideP = new THREE.Vector3(d.x + side * 0.65, 0, d.z + 0.9);
  const seatP = new THREE.Vector3(d.x, 0, d.z + 0.95);
  const p0 = player.position.clone(), r0 = player.rotation.y, a1 = -side * Math.PI / 2;
  state.forceWalk = true;
  await tween(0.5, k => { const e = ease(k); player.position.lerpVectors(p0, sideP, e); player.rotation.y = r0 + wrap(a1 - r0) * e; });
  state.forceWalk = false;
  const r1 = player.rotation.y;
  sfx.chair();
  await tween(0.6, k => { const e = ease(k); player.position.lerpVectors(sideP, seatP, e); player.rotation.y = r1 + wrap(Math.PI - r1) * e; state.sitK = e; });
  state.seated = true; state.deskName = d.name; state.faceT = player.rotation.y; transit = false;
  startStudy();
  toast(`Study session started at ${d.name}`);
}
async function stand() {
  stopStudy(); sfx.chair();
  state.deskName = null;
  transit = true;
  const seatP = player.position.clone();
  await tween(0.6, k => { const e = ease(k); player.position.lerpVectors(seatP, sideP, e); state.sitK = 1 - e; });
  state.seated = false; state.busy = false; transit = false;
}
sitBtn.addEventListener('pointerdown', e => {
  e.stopPropagation();
  if (transit) return;
  if (state.seated) stand(); else if (near && !state.busy) { const who = state.occupied[near.name]; if (who) toast(`${near.name} is taken by ${who}.`); else sit(near); }
});

// called every frame
export function updateSit() {
  let best = null, bd = 1.4;
  if (!state.seated && !state.busy) {
    for (const d of list) {
      if (player.position.z < d.z + 0.5) continue;
      const dd = Math.hypot(player.position.x - d.x, player.position.z - (d.z + 0.9));
      if (dd < bd) { bd = dd; best = d; }
    }
  }
  near = best;
  const label = transit ? '' : state.seated ? (state.spotName ? '' : '⏹ Stop studying') : best ? (state.occupied[best.name] ? `🔒 ${best.name} is taken by ${state.occupied[best.name]}` : `🪑 Sit at ${best.name}`) : '';
  if (label !== lastLabel) { lastLabel = label; sitBtn.textContent = label; sitBtn.style.display = label ? 'block' : 'none'; }
}

// if the app was closed while studying, sit back down at the same desk
{
  const s = activeSession();
  const d = s && s.runningSince && list.find(x => x.name === s.desk);
  if (d) {
    sideP = new THREE.Vector3(d.x + 0.65, 0, d.z + 0.9);
    player.position.set(d.x, 0, d.z + 0.95); player.rotation.y = Math.PI;
    state.faceT = Math.PI; state.sitK = 1; state.seated = true; state.deskName = d.name; state.busy = true;
  }
}
