// SETTINGS: one tidy page with cards (account, sound, privacy, updates, data, delete account)
import { accountInfo } from './firebase.js';
import { getName, allSessions } from './checkin.js';
import { audioConfig, setSfx, setMusic, setVolume } from './audio.js';
import { getPrivacy, setPrivacy } from './stats.js';
import { publishProfile, openBuddies } from './buddies.js';
import { openAccount } from './account.js';
import { openRooms } from './rooms.js';
import { addDangerZone } from './erase.js';
import { BUILD, updateInfo, checkUpdate, downloadUpdate, onUpdate } from './update.js';

const css = document.createElement('style');
css.textContent = `
#setp{position:fixed;inset:0;display:none;z-index:26;overflow-y:auto;-webkit-overflow-scrolling:touch;background:linear-gradient(#2a1a10,#3a2314);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(18px + env(safe-area-inset-top,0px)) 16px calc(30px + env(safe-area-inset-bottom,0px))}
#setp .wrap{max-width:480px;margin:0 auto}
#setp .top{display:flex;align-items:center;gap:10px;margin-bottom:16px}
#setp h1{margin:0;font-size:38px;line-height:1.1;flex:1}
#setp h2{margin:0;font-size:26px;flex:1}
#setp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px;flex:none}
#setp .card{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;margin:0 0 12px;padding:16px 18px;border-radius:24px;border:1px solid rgba(255,233,196,.28);background:rgba(255,233,196,.1);color:#ffe9c4;text-align:left;font-family:inherit}
#setp .card .t{flex:1;min-width:0}
#setp .card b{display:block;font-size:21px}
#setp .card small{display:block;font-size:15px;opacity:.75;margin-top:2px;font-weight:400}
#setp .card .ch{font-size:26px;color:#f0c48a}
#setp .card.danger{border-color:rgba(230,110,110,.6)}
#setp .card.danger b{color:#ff9d9d}
#setp .note{font-size:14px;opacity:.75;margin:8px 2px}
#setp .chips{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 14px}
#setp .chips button{flex:1 1 40%;padding:13px 8px;border-radius:18px;border:1px solid rgba(255,233,196,.45);background:transparent;color:#ffe9c4;font:600 15px Georgia,serif}
#setp .chips button.on{background:#8a5a34}
#setp .b{display:block;width:100%;margin-top:12px;padding:14px;border-radius:24px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 17px Georgia,serif}
#setp .b:disabled{opacity:.5}
#setp input{width:100%;box-sizing:border-box;margin-top:10px;padding:12px;font-size:18px;border-radius:10px;border:2px solid #c08a52;background:#fff7e8;color:#2a1a10}
#setp .msg{margin-top:14px;padding:12px;border-radius:12px;background:rgba(255,243,196,.14);display:none}
#setp .stat{padding:14px 16px;border-radius:18px;background:rgba(255,233,196,.1);margin-bottom:10px}`;
document.head.appendChild(css);
const panel = document.createElement('div'); panel.id = 'setp'; document.body.appendChild(panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

let page = 'list', busy = false;
const close = () => { panel.style.display = 'none'; page = 'list'; };
const go = p => { page = p; render(); };

function card(wrap, title, sub, fn, cls = '') {
  const c = mk('button', 'card ' + cls), t = mk('div', 't');
  t.append(mk('b', '', title)); if (sub) t.append(mk('small', '', sub));
  c.append(t, mk('span', 'ch', '›')); c.onclick = fn; wrap.append(c);
}
function head(title, back) {
  const top = mk('div', 'top'), x = mk('button', 'x', back ? '←' : '✕'); x.onclick = back ? () => go('list') : close;
  top.append(x, mk(back ? 'h2' : 'h1', '', title)); if (back) top.append(mk('span')); return top;
}
function updateLine() {
  if (updateInfo.available) return `New version ${updateInfo.build} is ready`;
  if (updateInfo.error) return updateInfo.error;
  return updateInfo.checked ? 'You are up to date' : 'Tap to check';
}

function render() {
  const wrap = mk('div', 'wrap'), info = accountInfo(), ac = audioConfig();
  if (page === 'list') {
    wrap.append(head('Settings'));
    card(wrap, getName() || 'Guest', info && !info.anonymous ? info.email : 'Guest. Tap to save your progress with an email', () => { close(); openAccount(); });
    card(wrap, 'Friends and study room', 'Friend requests, messages, room code', () => { close(); openBuddies(); });
    card(wrap, 'Sound', `Music ${ac.music ? 'on' : 'off'}, effects ${ac.sfx ? 'on' : 'off'}`, () => go('sound'));
    card(wrap, 'Privacy', getPrivacy() === 'all' ? 'Others see your level and achievements' : 'Others see only your name', () => go('privacy'));
    card(wrap, 'Updates', `Version ${BUILD} · ${updateLine()}`, () => go('update'));
    card(wrap, 'Your data', 'What is stored and who can see it', () => go('data'));
    card(wrap, 'Delete account', 'Erase everything, online and on this phone', () => go('delete'), 'danger');
  } else if (page === 'sound') {
    wrap.append(head('Sound', true));
    wrap.append(mk('div', 'note', 'Soft music plays only on the Home page. In the library you hear the room, the weather and pens.'));
    const row = (label, on, fn) => { const b = mk('button', on ? 'on' : '', label); b.onclick = () => { fn(); render(); }; return b; };
    const chips = mk('div', 'chips');
    chips.append(row(`🎵 Home music: ${ac.music ? 'On' : 'Off'}`, ac.music, () => setMusic(!ac.music)), row(`🔊 Effects: ${ac.sfx ? 'On' : 'Off'}`, ac.sfx, () => setSfx(!ac.sfx)));
    [['Low', 0.35], ['Medium', 0.7], ['High', 1]].forEach(([n, v]) => chips.append(row(`Volume: ${n}`, Math.abs(ac.vol - v) < 0.1, () => setVolume(v))));
    wrap.append(chips);
  } else if (page === 'privacy') {
    wrap.append(head('Privacy', true));
    wrap.append(mk('div', 'note', 'This controls what other players see when they tap your character. Your study sessions are never shown to anyone.'));
    const chips = mk('div', 'chips');
    [['all', 'Show my level and achievements'], ['name', 'Show only my name']].forEach(([k, l]) => {
      const b = mk('button', getPrivacy() === k ? 'on' : '', l); b.onclick = () => { setPrivacy(k); publishProfile(true); render(); }; chips.append(b);
    });
    wrap.append(chips);
  } else if (page === 'update') {
    wrap.append(head('Updates', true));
    wrap.append(mk('div', 'stat', `Installed version: ${BUILD}`), mk('div', 'stat', updateLine()));
    if (updateInfo.available && updateInfo.notes) wrap.append(mk('div', 'note', updateInfo.notes));
    const b = mk('button', 'b', busy ? 'Checking...' : updateInfo.available ? '⬇ Download and install update' : '🔄 Check for updates'); b.disabled = busy;
    b.onclick = async () => { if (updateInfo.available) { downloadUpdate(); return; } busy = true; render(); await checkUpdate(true); busy = false; render(); };
    wrap.append(b, mk('div', 'note', 'When you download an update, Android installs it over this app. Your sessions, friends and settings stay.'));
  } else if (page === 'data') {
    wrap.append(head('Your data', true));
    wrap.append(mk('div', 'note', 'Your study sessions are private and only you can read them. People in your study room see only your name and study totals. Friends see only what Privacy allows. Private messages are only between you and one friend.'));
    const msg = mk('div', 'msg'), say = t => { msg.textContent = t; msg.style.display = 'block'; };
    const b = mk('button', 'b', '📦 Copy a backup of my data');
    b.onclick = async () => {
      const data = JSON.stringify({ name: getName(), exportedAt: new Date().toISOString(), sessions: allSessions().filter(r => !r.test) }, null, 2);
      try { await navigator.clipboard.writeText(data); say('Copied. Paste it into a note to keep a backup.'); } catch { say('Could not copy on this phone.'); }
    };
    wrap.append(b, msg);
  } else if (page === 'delete') {
    wrap.append(head('Delete account', true));
    const msg = mk('div', 'msg'), say = t => { msg.textContent = t; msg.style.display = 'block'; };
    addDangerZone(wrap, info, say, mk);
    wrap.append(msg);
  }
  panel.replaceChildren(wrap); panel.scrollTop = 0; panel.style.display = 'block';
}
onUpdate(() => { if (panel.style.display === 'block' && (page === 'list' || page === 'update') && !busy) render(); });
export const openSettings = () => { page = 'list'; render(); };
