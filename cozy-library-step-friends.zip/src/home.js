// HOME: the dashboard that opens first (stats and menu). The 3D library is a separate scene you enter from here.
import { state } from './core.js';
import { player } from './characters.js';
import { allSessions, activeSession, dur, getName, studiedMs } from './checkin.js';
import { streakInfo } from './streak.js';
import { readStandings, openBoard } from './board.js';
import { myUid, syncStatus, weekKeys } from './firebase.js';
import { openHistory } from './history.js';
import { openRooms } from './rooms.js';
import { openSettings } from './settings.js';
import { dropHeldBook } from './interactions.js';
import { clearPresence } from './friends.js';
import { eventBanner, getBadges } from './events.js';
import { levelInfo, getShirt } from './stats.js';
import { openProfile } from './profile.js';
import { openAchievements, achievementSummary, checkAchievements } from './achievements.js';
import { sfx, setScene } from './audio.js';
import { openBuddies, buddyBadge } from './buddies.js';
import { updateInfo, downloadUpdate, onUpdate, BUILD } from './update.js';

const css = document.createElement('style');
css.textContent = `
#home{position:fixed;inset:0;display:none;z-index:20;overflow-y:auto;-webkit-overflow-scrolling:touch;background:linear-gradient(#2a1a10,#4a2c17 70%,#6b4226);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(22px + env(safe-area-inset-top,0px)) 16px calc(28px + env(safe-area-inset-bottom,0px))}
#home .wrap{max-width:480px;margin:0 auto}
#home h1{margin:0 0 2px;font-size:28px}
#home .sub{opacity:.8;margin-bottom:16px}
#home h3{margin:20px 0 8px;font-size:17px;color:#f0c48a}
#home .cards{display:grid;grid-template-columns:1fr 1fr;gap:10px}
#home .card{background:rgba(255,233,196,.1);border:1px solid rgba(255,233,196,.3);border-radius:14px;padding:12px}
#home .card .l{font-size:13px;opacity:.75}
#home .card .v{font-size:22px;font-weight:700;margin-top:2px}
#home .week{background:rgba(255,233,196,.08);border-radius:14px;padding:6px 12px}
#home .week .r{display:flex;justify-content:space-between;padding:6px 0}
#home .enter{display:block;width:100%;margin:22px 0 14px;padding:20px;border-radius:30px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:700 22px Georgia,serif;box-shadow:0 6px 18px rgba(0,0,0,.4)}
#home .menu{display:grid;grid-template-columns:1fr 1fr;gap:10px}
#home .menu button{padding:14px 8px;border-radius:16px;border:1px solid #ffe9c4;background:rgba(138,90,52,.55);color:#ffe9c4;font:600 15px Georgia,serif}
#home .menu button.wide{grid-column:1 / -1}
#home .menu button:disabled{opacity:.45}
#home .pcard{display:flex;align-items:center;gap:14px;width:100%;margin-bottom:14px;padding:12px;border-radius:16px;border:1px solid rgba(255,233,196,.4);background:rgba(255,233,196,.1);color:#ffe9c4;text-align:left;font:600 16px Georgia,serif}
#home .pcard .av{width:56px;height:56px;border-radius:50%;border:3px solid #f0c48a;display:flex;align-items:center;justify-content:center;font:700 26px Georgia,serif;color:#fff;flex:none}
#home .pcard .pb{flex:1}
#home .pcard .xp{height:8px;border-radius:4px;background:rgba(255,255,255,.15);overflow:hidden;margin:6px 0 2px}
#home .pcard .xp i{display:block;height:100%;background:linear-gradient(90deg,#f0c48a,#ffe9a0)}
#home .pcard small{font-weight:400;opacity:.7}
#home .foot{margin-top:18px;font-size:13px;opacity:.65;text-align:center}`;
document.head.appendChild(css);
const root = document.createElement('div'); root.id = 'home'; document.body.appendChild(root);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

function stats() {
  const keys = weekKeys();
  let total = 0, week = 0, weekN = 0;
  const all = allSessions();
  all.forEach(r => { const ms = studiedMs(r); total += ms; if (r.date >= keys.thisWeek) { week += ms; weekN++; } });
  return { total, week, weekN, n: all.length };
}
function render() {
  const s = stats(), st = streakInfo(), name = getName(), checked = !!activeSession();
  const champs = readStandings().hall.filter(h => h.key && h.key === myUid()).length;
  const wrap = mk('div', 'wrap');
  wrap.append(mk('h1', '', name ? `Welcome back, ${name} 📚` : 'Welcome to the library 📚'),
    mk('div', 'sub', name ? 'Ready for another good study session?' : 'Walk in and check in with the librarian to start.'));
  const lv = levelInfo(s.total), pc = mk('button', 'pcard'), av = mk('div', 'av', (name || '?').charAt(0).toUpperCase()), pb = mk('div', 'pb'), xp = mk('div', 'xp'), xf = mk('i');
  av.style.background = '#' + (getShirt() || 0x3f7fbf).toString(16).padStart(6, '0'); xf.style.width = `${Math.round(lv.pct * 100)}%`; xp.append(xf);
  pb.append(mk('div', '', `Level ${lv.level} · ${lv.title}`), xp, mk('small', '', 'Tap to open your profile'));
  pc.append(av, pb); pc.onclick = openProfile; wrap.append(pc);
  const cards = mk('div', 'cards');
  [['🔥 Study streak', `${st.current} day${st.current === 1 ? '' : 's'}`], ['📖 Total study', dur(s.total)], ['📚 Sessions', String(s.n)], ['🏆 Library champion', `${champs}×`]].forEach(([l, v]) => {
    const c = mk('div', 'card'); c.append(mk('div', 'l', l), mk('div', 'v', v)); cards.append(c);
  });
  wrap.append(cards);
  const eb = eventBanner();
  if (eb) {
    const ec = mk('div', 'card'); ec.style.marginTop = '12px';
    ec.append(mk('div', 'v', eb.title)); eb.lines.forEach(l => ec.append(mk('div', 'l', l))); wrap.append(ec);
  }
  getBadges().forEach(b => { const bc = mk('div', 'card'); bc.style.marginTop = '8px'; bc.append(mk('div', 'l', 'Event badge'), mk('div', 'v', `🏅 ${b.name}`)); wrap.append(bc); });
  wrap.append(mk('h3', '', 'This week'));
  const week = mk('div', 'week');
  [['Study time', dur(s.week)], ['Sessions', String(s.weekN)], ['Average session', s.weekN ? dur(s.week / s.weekN) : '-']].forEach(([l, v]) => {
    const r = mk('div', 'r'); r.append(mk('span', '', l), mk('b', '', v)); week.append(r);
  });
  const enter = mk('button', 'enter', checked ? '🏛️ BACK TO THE LIBRARY' : '🏛️ ENTER LIBRARY'); enter.onclick = enterLibrary;
  const menu = mk('div', 'menu'), nb = buddyBadge();
  [['📊 Study history', openHistory], ['🏅 Champion history', () => openBoard('all')], [nb ? `👥 Friends (${nb})` : '👥 Friends', openBuddies], ['🏠 Study room', openRooms]].forEach(([l, fn]) => {
    const b = mk('button', '', l); b.onclick = fn; menu.append(b);
  });
  const as = achievementSummary(), ach = mk('button', 'wide', `🏆 Achievements ${as.unlocked}/${as.total}`); ach.onclick = openAchievements; menu.append(ach);
  const sb = mk('button', 'wide', '⚙️ Settings'); sb.onclick = openSettings; menu.append(sb);
  if (updateInfo.available) {
    const uc = mk('div', 'card'); uc.style.margin = '12px 0 0';
    const ub = mk('button', 'b', '⬇ Update now'); ub.style.cssText = 'margin-top:8px;padding:10px 16px;border-radius:18px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 15px Georgia,serif';
    ub.onclick = downloadUpdate;
    uc.append(mk('div', 'v', '🎁 New version ready'), mk('div', 'l', updateInfo.notes || 'Download it and Android will update the app. Your data stays.'), ub); wrap.append(uc);
  }
  wrap.append(week, enter, menu, mk('div', 'foot', `☁ Online sync: ${syncStatus()} · version ${BUILD}`));
  root.replaceChildren(wrap);
}
onUpdate(() => { if (root.style.display === 'block') render(); });
let timer = 0;
function show() { checkAchievements(); render(); root.style.display = 'block'; root.scrollTop = 0; clearInterval(timer); timer = setInterval(() => { if (root.style.display === 'block') render(); }, 15000); }

function doEnter() {
  root.style.display = 'none'; clearInterval(timer);
  if (state.screen !== 'library') {
    player.position.set(0, 0, 8); player.rotation.y = Math.PI;
    Object.assign(state, { faceT: Math.PI, sitK: 0, seated: false, busy: false, deskName: null, spotName: null, forceWalk: false, screen: 'library' });
  }
}
function doHome() {
  dropHeldBook();
  ['chatp', 'emotes', 'boardp', 'menup', 'menuback'].forEach(id => { const e = document.getElementById(id); if (e) e.style.display = 'none'; });
  state.screen = 'home'; clearPresence();
  show();
}

// a short fade makes the change between Home and the library feel smooth
const fadeEl = document.createElement('div');
fadeEl.style.cssText = 'position:fixed;inset:0;background:#1a0f08;opacity:0;pointer-events:none;transition:opacity .35s;z-index:50';
document.body.appendChild(fadeEl);
function transition(fn) {
  fadeEl.style.opacity = '1'; fadeEl.style.pointerEvents = 'auto';
  setTimeout(() => { fn(); setTimeout(() => { fadeEl.style.opacity = '0'; fadeEl.style.pointerEvents = 'none'; }, 80); }, 350);
}
export function enterLibrary() { transition(() => { doEnter(); sfx.door(); setScene(true); }); }
export function goHome() { transition(() => { doHome(); setScene(false); }); }

// opens on the dashboard, unless a study session is still running (then go straight back to the desk)
const running = (activeSession() || {}).runningSince;
if (running) state.screen = 'library'; else { state.screen = 'home'; show(); }
