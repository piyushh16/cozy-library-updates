// INPUT: joystick, camera drag and keyboard
import { renderer } from './core.js';

// ---------- input ----------
const joy = document.getElementById('joy'), knob = document.getElementById('knob');
let jx = 0, jy = 0, joyId = null; const JR = 55;
function updJoy(e) {
  const r = joy.getBoundingClientRect();
  let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
  const d = Math.hypot(dx, dy); if (d > JR) { dx *= JR / d; dy *= JR / d; }
  knob.style.transform = `translate(${dx}px,${dy}px)`; jx = dx / JR; jy = -dy / JR;
}
joy.addEventListener('pointerdown', e => { joyId = e.pointerId; joy.setPointerCapture(e.pointerId); updJoy(e); });
joy.addEventListener('pointermove', e => { if (e.pointerId === joyId) updJoy(e); });
const endJoy = e => { if (e.pointerId === joyId) { joyId = null; jx = jy = 0; knob.style.transform = 'translate(0,0)'; } };
joy.addEventListener('pointerup', endJoy); joy.addEventListener('pointercancel', endJoy);

let yaw = 0, lookId = null, lx = 0;
const cv = renderer.domElement;
cv.addEventListener('pointerdown', e => { lookId = e.pointerId; lx = e.clientX; cv.setPointerCapture(e.pointerId); });
cv.addEventListener('pointermove', e => { if (e.pointerId === lookId) { yaw -= (e.clientX - lx) * 0.006; lx = e.clientX; } });
['pointerup', 'pointercancel'].forEach(t => cv.addEventListener(t, e => { if (e.pointerId === lookId) lookId = null; }));
const keys = {};
addEventListener('keydown', e => keys[e.key.toLowerCase()] = true);
addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);


export const input = { get jx() { return jx; }, get jy() { return jy; }, get yaw() { return yaw; }, keys };
