// ACHIEVEMENTS: Step 21 badges for study milestones (worked out from your own data)
import { allSessions, studiedMs } from './checkin.js';
import { streakInfo } from './streak.js';
import { peekStandings } from './board.js';
import { myUid } from './firebase.js';
import { getRoomId } from './rooms.js';
import { getBadges } from './events.js';
import { count } from './stats.js';
import { state } from './core.js';
import { emoteToast, triggerMine } from './emote.js';
import { sfx } from './audio.js';

const H = 3600000;
function metrics() {
  let total = 0, longest = 0, done = 0, early = 0, owl = 0, first = '';
  const all = allSessions(), fav = new Map();
  for (const r of all) {
    const ms = studiedMs(r); total += ms; longest = Math.max(longest, ms);
    if (ms >= 60000) done++;
    if (r.studyStart && ms >= 600000) { const h = new Date(r.studyStart).getHours(); if (h < 7) early++; if (h >= 23 || h < 4) owl++; }
    if (r.desk) fav.set(r.desk, (fav.get(r.desk) || 0) + 1);
    if (!first || r.checkIn < first) first = r.checkIn;
  }
  let favDesk = '', fb = 0; fav.forEach((n, d) => { if (n > fb) { fb = n; favDesk = d; } });
  const st = streakInfo(), ss = peekStandings(), me = myUid();
  return {
    total, longest, done, early, owl, first, favDesk, sessions: all.length, bestStreak: st.best, curStreak: st.current,
    champWeeks: ss.hall.filter(h => h.key === me).length, champStreak: ss.champion && ss.champion.key === me ? ss.champion.streak : 0,
    books: count('books'), chat: count('chat'), emotes: count('emotes'), breaks: count('breaks'), windows: count('windows'),
    room: getRoomId() ? 1 : 0, ny: getBadges().length ? 1 : 0,
  };
}
export const getMetrics = metrics;

export const DEFS = [
  { id: 'first', icon: '📖', name: 'First Session', desc: 'Finish your first study session', get: m => [m.done, 1] },
  { id: 'streak7', icon: '🔥', name: '7-Day Scholar', desc: 'Study 7 days in a row', get: m => [m.bestStreak, 7] },
  { id: 'streak30', icon: '🌋', name: '30-Day Scholar', desc: 'Study 30 days in a row', get: m => [m.bestStreak, 30] },
  { id: 'h10', icon: '⏱️', name: '10 Hours', desc: 'Study 10 hours in total', get: m => [m.total / H, 10] },
  { id: 'h100', icon: '💯', name: '100 Hours', desc: 'Study 100 hours in total', get: m => [m.total / H, 100] },
  { id: 'champ', icon: '🏆', name: 'Library Champion', desc: 'Win a weekly championship', get: m => [m.champWeeks, 1] },
  { id: 'champ3', icon: '👑', name: 'Three-Time Champion', desc: 'Win 3 weekly championships', get: m => [m.champWeeks, 3] },
  { id: 'book', icon: '📚', name: 'Bookworm', desc: 'Take 20 books off the shelves', get: m => [m.books, 20] },
  { id: 'marathon', icon: '🏃', name: 'Marathon Session', desc: 'Study 3 hours in one session', get: m => [m.longest / H, 3] },
  { id: 'early', icon: '🌅', name: 'Early Bird', desc: 'Start a study session before 7 AM', get: m => [m.early, 1] },
  { id: 'owl', icon: '🦉', name: 'Night Owl', desc: 'Study after 11 PM', get: m => [m.owl, 1] },
  { id: 'buddy', icon: '👥', name: 'Study Buddy', desc: 'Join a friends room', get: m => [m.room, 1] },
  { id: 'chat', icon: '💬', name: 'Chatterbox', desc: 'Send 10 chat messages', get: m => [m.chat, 10] },
  { id: 'cheer', icon: '🙌', name: 'Cheerleader', desc: 'Use 10 reactions', get: m => [m.emotes, 10] },
  { id: 'rest', icon: '☕', name: 'Good Break', desc: 'Take 5 breaks in the lounge', get: m => [m.breaks, 5] },
  { id: 'air', icon: '🪟', name: 'Fresh Air', desc: 'Open a window', get: m => [m.windows, 1] },
  { id: 'ny', icon: '🎆', name: 'New Year Scholar', desc: 'Finish the New Year Challenge', get: m => [m.ny, 1] },
];

const AKEY = 'cozylib.ach';
const readRec = () => { try { return JSON.parse(localStorage.getItem(AKEY)) || {}; } catch { return {}; } };
const writeRec = r => { try { localStorage.setItem(AKEY, JSON.stringify(r)); } catch { /* ignore */ } };
export function achievementList(m = metrics()) {
  const rec = readRec();
  return DEFS.map(d => { const [v, t] = d.get(m); return { ...d, value: Math.min(v, t), target: t, unlocked: v >= t, date: rec[d.id] && rec[d.id].date }; });
}
export function achievementSummary() { const l = achievementList(); return { unlocked: l.filter(a => a.unlocked).length, total: l.length }; }
export function clearTestAchievements() {
  const rec = readRec(); Object.keys(rec).forEach(k => { if (rec[k].test) delete rec[k]; }); writeRec(rec);
}

// new unlocks get a message (the very first run only records what you already have)
const queue = []; let qTimer = 0;
function pump() {
  if (qTimer || !queue.length) return;
  const a = queue.shift();
  emoteToast(`🏅 Achievement unlocked: ${a.icon} ${a.name}`);
  sfx.unlock();
  if (state.screen === 'library') triggerMine('party');
  qTimer = setTimeout(() => { qTimer = 0; pump(); }, 3600);
}
export function checkAchievements() {
  let first = false; try { first = localStorage.getItem(AKEY) === null; } catch { /* ignore */ }
  const rec = readRec(), hasTest = allSessions().some(r => r.test); let changed = false;
  achievementList().forEach(a => {
    if (a.unlocked && !rec[a.id]) { rec[a.id] = { date: new Date().toISOString(), test: hasTest }; changed = true; if (!first) queue.push(a); }
  });
  if (changed || first) writeRec(rec);
  pump();
}
let lastCheck = 0;
export function updateAchievements() {
  const now = performance.now();
  if (now - lastCheck < 5000) return;
  lastCheck = now; checkAchievements();
}

// ---- screen
const css = document.createElement('style');
css.textContent = `
#achp{position:fixed;inset:0;display:none;z-index:26;overflow-y:auto;-webkit-overflow-scrolling:touch;background:rgba(32,20,12,.98);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#achp .wrap{max-width:480px;margin:0 auto}
#achp .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
#achp h2{margin:0;font-size:22px}
#achp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#achp .a{display:flex;gap:12px;align-items:center;background:rgba(255,243,196,.12);border:1px solid rgba(240,196,138,.6);border-radius:14px;padding:10px 12px;margin-bottom:8px}
#achp .a.lock{background:rgba(255,243,196,.05);border-color:rgba(255,233,196,.15)}
#achp .a.lock .ic{filter:grayscale(1);opacity:.4}
#achp .ic{font-size:32px;width:46px;text-align:center}
#achp .nm{font-weight:700}
#achp .ds{font-size:13px;opacity:.8}
#achp .bar{height:6px;background:rgba(255,255,255,.15);border-radius:3px;overflow:hidden;margin-top:6px}
#achp .bar i{display:block;height:100%;background:#f0c48a}
#achp .pt{font-size:12px;opacity:.75;margin-top:2px}`;
document.head.appendChild(css);
const panel = document.createElement('div'); panel.id = 'achp'; document.body.appendChild(panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const num = (a, v) => (['h10', 'h100', 'marathon'].includes(a.id) ? v.toFixed(1) : String(Math.floor(v)));

export function openAchievements() {
  checkAchievements();
  const list = achievementList(), got = list.filter(a => a.unlocked).length;
  const wrap = mk('div', 'wrap'), top = mk('div', 'top');
  const x = mk('button', 'x', '✕'); x.onclick = () => { panel.style.display = 'none'; };
  top.append(mk('h2', '', `🏅 Achievements ${got}/${list.length}`), x); wrap.append(top);
  [...list.filter(a => a.unlocked), ...list.filter(a => !a.unlocked)].forEach(a => {
    const row = mk('div', a.unlocked ? 'a' : 'a lock'), body = mk('div');
    body.style.flex = '1';
    body.append(mk('div', 'nm', a.name), mk('div', 'ds', a.desc));
    if (a.unlocked) body.append(mk('div', 'pt', a.date ? `Unlocked ${new Date(a.date).toLocaleDateString([], { day: 'numeric', month: 'short' })}` : 'Unlocked'));
    else {
      const bar = mk('div', 'bar'), fill = mk('i'); fill.style.width = `${Math.round((a.value / a.target) * 100)}%`; bar.append(fill);
      body.append(bar, mk('div', 'pt', `${num(a, a.value)} / ${a.target}`));
    }
    row.append(mk('div', 'ic', a.icon), body); wrap.append(row);
  });
  panel.replaceChildren(wrap); panel.scrollTop = 0; panel.style.display = 'block';
}
