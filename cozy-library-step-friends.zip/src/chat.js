// CHAT: Step 15 in-game room chat (a small box at the top that does not cover the library)
import { collection, query, orderBy, limit, onSnapshot, addDoc } from 'firebase/firestore';
import { db, myUid } from './firebase.js';
import { onRoomChange } from './rooms.js';
import { getName } from './checkin.js';
import { bump } from './stats.js';
import { sfx } from './audio.js';

const css = document.createElement('style');
css.textContent = `
#chatb{position:fixed;right:calc(188px + env(safe-area-inset-right,0px));top:calc(10px + env(safe-area-inset-top,0px));width:48px;height:48px;border-radius:50%;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font-size:22px;touch-action:manipulation;box-shadow:0 3px 10px rgba(0,0,0,.4)}
#chatbadge{position:fixed;right:calc(184px + env(safe-area-inset-right,0px));top:calc(4px + env(safe-area-inset-top,0px));min-width:20px;height:20px;padding:0 5px;box-sizing:border-box;border-radius:10px;background:#d23c3c;color:#fff;font:700 12px/20px Georgia,serif;text-align:center;display:none;pointer-events:none;z-index:2}
#chatp{position:fixed;left:50%;transform:translateX(-50%);top:calc(130px + env(safe-area-inset-top,0px));width:calc(100% - 20px);max-width:480px;display:none;z-index:24;background:rgba(32,20,12,.88);border:2px solid #ffe9c4;border-radius:16px;color:#ffe9c4;font:15px/1.35 Georgia,serif;overflow:hidden}
#chatp .head{display:flex;justify-content:space-between;align-items:center;padding:6px 8px 6px 12px;font-weight:700}
#chatp .head button{width:36px;height:36px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:16px}
#chatp .list{height:120px;overflow-y:auto;padding:0 12px;-webkit-overflow-scrolling:touch}
#chatp .m{margin:3px 0;word-wrap:break-word}
#chatp .m b{color:#f0c48a}
#chatp .m.me b{color:#9fd3ff}
#chatp .m i{opacity:.55;font-size:12px;margin-left:6px;font-style:normal}
#chatp .empty{opacity:.7;padding:6px 0}
#chatp .row{display:flex;gap:8px;padding:8px}
#chatp input{flex:1;min-width:0;padding:9px 12px;font-size:16px;border-radius:18px;border:2px solid #c08a52;background:#fff7e8;color:#2a1a10}
#chatp .send{padding:0 16px;border-radius:18px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 15px Georgia,serif}
#chatp .note{font-size:13px;opacity:.8;padding:0 12px 6px}`;
document.head.appendChild(css);

const btn = document.createElement('button'); btn.id = 'chatb'; btn.textContent = '💬'; btn.setAttribute('aria-label', 'Chat');
const badge = document.createElement('div'); badge.id = 'chatbadge';
const panel = document.createElement('div'); panel.id = 'chatp';
panel.innerHTML = '<div class="head"><span>💬 Room chat</span><button aria-label="Minimise">▾</button></div><div class="list"></div><div class="note"></div><div class="row"><input maxlength="300" placeholder="Message your friends" autocomplete="off"><button class="send">Send</button></div>';
document.body.append(btn, badge, panel);
const list = panel.querySelector('.list'), input = panel.querySelector('input'), note = panel.querySelector('.note');
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

let roomId = '', unsub = null, msgs = [], lastSend = 0, firstSnap = true, heard = 0;
const open = () => panel.style.display === 'block';
const readKey = 'cozylib.chatRead';
const getRead = () => { try { return Number(localStorage.getItem(readKey)) || 0; } catch { return 0; } };
const markRead = () => { try { localStorage.setItem(readKey, String(Date.now())); } catch { /* ignore */ } };
const setNote = t => { note.textContent = t || ''; };

function render() {
  const stick = list.scrollTop + list.clientHeight >= list.scrollHeight - 30;
  list.replaceChildren();
  if (!roomId) list.append(mk('div', 'empty', 'Join or create a room (🏠) to chat with your friends.'));
  else if (!msgs.length) list.append(mk('div', 'empty', 'No messages yet. Say hello!'));
  msgs.forEach(m => {
    const row = mk('div', m.uid === myUid() ? 'm me' : 'm');
    row.append(mk('b', '', m.name + ': '), mk('span', '', m.text), mk('i', '', new Date(m.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })));
    list.append(row);
  });
  if (stick || !list.dataset.seen) { list.scrollTop = list.scrollHeight; list.dataset.seen = '1'; }
  const unread = open() ? 0 : msgs.filter(m => m.createdAt > getRead() && m.uid !== myUid()).length;
  if (open()) markRead();
  badge.style.display = unread ? 'block' : 'none'; badge.textContent = unread > 9 ? '9+' : String(unread);
}

export function openChat() { if (!open()) { panel.style.display = 'block'; markRead(); render(); list.scrollTop = list.scrollHeight; } }
btn.onclick = () => {
  if (open()) { panel.style.display = 'none'; render(); return; }
  panel.style.display = 'block'; markRead(); render(); list.scrollTop = list.scrollHeight;
};
panel.querySelector('.head button').onclick = () => { panel.style.display = 'none'; render(); };

function send() {
  const text = input.value.trim().slice(0, 300);
  if (!text || !roomId || Date.now() - lastSend < 800) return;
  lastSend = Date.now(); input.value = ''; setNote(''); bump('chat');
  addDoc(collection(db, 'rooms', roomId, 'messages'), { uid: myUid(), name: (getName() || 'Guest').slice(0, 40), text, createdAt: Date.now() })
    .catch(e => setNote(e && e.code === 'permission-denied' ? 'Could not send. The new Firebase rules need to be published.' : 'Could not send. Check your internet.'));
}
panel.querySelector('.send').onclick = send;
input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); send(); } });

onRoomChange(id => {
  if (id === roomId) return;
  roomId = id; msgs = []; firstSnap = true; heard = 0;
  if (unsub) { unsub(); unsub = null; }
  render();
  if (id) {
    unsub = onSnapshot(query(collection(db, 'rooms', id, 'messages'), orderBy('createdAt', 'desc'), limit(50)),
      snap => {
        msgs = snap.docs.map(d => d.data()).reverse(); setNote('');
        const nw = msgs[msgs.length - 1];
        if (nw && !firstSnap && nw.createdAt > heard && nw.uid !== myUid()) sfx.ding();
        if (nw) heard = Math.max(heard, nw.createdAt);
        firstSnap = false; render();
      },
      e => setNote(e && e.code === 'permission-denied' ? 'Cannot read messages. The new Firebase rules need to be published.' : 'Cannot load messages right now.'));
  }
});
render();
