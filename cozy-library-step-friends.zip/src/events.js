// EVENTS: Step 22 seasons and special events (Exam Season, Monsoon Week, Winter Study Week, New Year Challenge)
import * as THREE from 'three';
import { scene, state } from './core.js';
import { desks } from './world.js';
import { allSessions, studiedMs } from './checkin.js';
import { envHooks, refreshMood, currentKey } from './environment.js';
import { setWinter } from './outside.js';
import { emoteToast, triggerMine } from './emote.js';

// when each event runs (month, day). Change the dates here any time.
export const EVENT_LIST = [
  { key: 'exam', name: 'Exam Season', icon: '📚', ranges: [[[11, 20], [12, 14]], [[4, 20], [5, 20]]] },
  { key: 'monsoon', name: 'Monsoon Week', icon: '☔', ranges: [[[7, 13], [7, 19]]] },
  { key: 'winter', name: 'Winter Study Week', icon: '❄️', ranges: [[[12, 15], [12, 21]]] },
  { key: 'newyear', name: 'New Year Challenge', icon: '🎆', ranges: [[[12, 28], [1, 7]]] },
];
export const EVENT_MODES = [{ key: 'auto', icon: '📅', name: 'Auto (by date)' }, ...EVENT_LIST.map(e => ({ key: e.key, icon: e.icon, name: e.name })), { key: 'none', icon: '🚫', name: 'No event' }];
const CHALLENGE_DAYS = 5, CHALLENGE_MS = 30 * 60 * 1000;

const KEY = 'cozylib.event';
let mode = 'auto';
try { const m = localStorage.getItem(KEY); if (EVENT_MODES.some(e => e.key === m)) mode = m; } catch { /* ignore */ }
export const getEventMode = () => mode;

const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const R = (a, b) => a + Math.random() * (b - a);
function matchedRange(ev) {
  const now = new Date(), x = (now.getMonth() + 1) * 100 + now.getDate();
  return ev.ranges.find(([[m1, d1], [m2, d2]]) => { const a = m1 * 100 + d1, b = m2 * 100 + d2; return a <= b ? x >= a && x <= b : x >= a || x <= b; }) || null;
}
export function currentEvent() {
  if (mode === 'none') return null;
  if (mode !== 'auto') return EVENT_LIST.find(e => e.key === mode) || null;
  return EVENT_LIST.find(e => matchedRange(e)) || null;
}
function endsInDays(ev) {
  const r = matchedRange(ev);
  if (!r) return null;
  const now = new Date(), [[m1], [m2, d2]] = r, wraps = m1 > m2;
  const y = wraps && now.getMonth() + 1 >= m1 ? now.getFullYear() + 1 : now.getFullYear();
  return Math.max(0, Math.ceil((new Date(y, m2 - 1, d2, 23, 59) - now) / 86400000));
}

// ---- New Year Challenge: study 30 minutes on 5 different days
function challengeWindow() {
  const now = new Date(), ev = EVENT_LIST.find(e => e.key === 'newyear');
  if (mode === 'auto' && matchedRange(ev)) {
    const y = now.getMonth() === 11 ? now.getFullYear() : now.getFullYear() - 1;
    return { start: `${y}-12-28`, end: `${y + 1}-01-07`, year: y + 1 };
  }
  const s = new Date(now); s.setDate(s.getDate() - 6); // preview: the last 7 days
  return { start: dayKey(s), end: dayKey(now), year: now.getMonth() >= 6 ? now.getFullYear() + 1 : now.getFullYear() };
}
export function challengeInfo() {
  const w = challengeWindow(), by = new Map(); let test = false;
  for (const r of allSessions()) {
    if (r.date < w.start || r.date > w.end) continue;
    by.set(r.date, (by.get(r.date) || 0) + studiedMs(r));
    if (r.test) test = true;
  }
  const days = [...by.values()].filter(ms => ms >= CHALLENGE_MS).length;
  return { days, target: CHALLENGE_DAYS, year: w.year, done: days >= CHALLENGE_DAYS, test };
}
const BKEY = 'cozylib.badges';
export function getBadges() { try { return JSON.parse(localStorage.getItem(BKEY)) || []; } catch { return []; } }
const saveBadges = a => { try { localStorage.setItem(BKEY, JSON.stringify(a)); } catch { /* ignore */ } };
export function clearTestBadges() { saveBadges(getBadges().filter(b => !b.test)); }
function checkBadge() {
  const ev = currentEvent();
  if (!ev || ev.key !== 'newyear') return;
  const c = challengeInfo(), id = `newyear-${c.year}`;
  if (!c.done || getBadges().some(b => b.id === id)) return;
  saveBadges([...getBadges(), { id, name: `New Year Scholar ${c.year}`, icon: '🎆', date: dayKey(new Date()), test: c.test }]);
  emoteToast(`🏅 New badge: New Year Scholar ${c.year}!`); triggerMine('party');
}

// text for the Home page and the poster
export function eventBanner() {
  const ev = currentEvent();
  if (!ev) return null;
  const left = endsInDays(ev), end = left === null ? 'Preview mode' : `Ends in ${left} day${left === 1 ? '' : 's'}`;
  const lines = {
    exam: [end, 'Short breaks keep you sharp. You have got this!'],
    monsoon: [end, 'Rain outside, warm lamps inside. Perfect for a good book.'],
    winter: [end, 'Snow outside, cosy inside. Keep studying warm.'],
    newyear: (() => { const c = challengeInfo(); return [`Study 30 minutes on ${c.target} days: ${Math.min(c.days, c.target)} / ${c.target}`, c.done ? 'Badge earned: New Year Scholar!' : end]; })(),
  }[ev.key];
  return { key: ev.key, title: `${ev.icon} ${ev.name}`, lines };
}

// ---- decorations
const flagCols = [0xe05a4f, 0xf0b840, 0x4fa3d9, 0x6cc070, 0xb06ad9];
const std = (c, extra = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.9, ...extra });
const groups = { exam: new THREE.Group(), monsoon: new THREE.Group(), winter: new THREE.Group(), newyear: new THREE.Group() };
Object.values(groups).forEach(g => { g.visible = false; scene.add(g); });

function garland(g, x0, x1, z, y, cols) {
  const n = Math.round(Math.abs(x1 - x0) / 0.5), pts = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n, x = x0 + (x1 - x0) * t, py = y - 0.35 * Math.sin(Math.PI * t);
    pts.push(new THREE.Vector3(x, py, z));
    const f = new THREE.Mesh(new THREE.CircleGeometry(0.14, 3), new THREE.MeshStandardMaterial({ color: cols[i % cols.length], roughness: 0.9, side: THREE.DoubleSide }));
    f.position.set(x, py - 0.12, z); f.rotation.z = -Math.PI / 2; g.add(f);
  }
  g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x6b4a2a })));
}
// exam season: pennants, a stack of books and a mug on every desk
garland(groups.exam, -7.4, 7.4, -9.85, 3.8, flagCols);
garland(groups.exam, -7.4, -1.9, 9.85, 3.8, flagCols);
garland(groups.exam, 1.9, 7.4, 9.85, 3.8, flagCols);
desks.forEach(d => {
  [[0.26, 0.04, 0.2, 0xb23a48, 0], [0.24, 0.04, 0.18, 0x2f6f8f, 0.02], [0.22, 0.035, 0.17, 0xd9a441, -0.01]].forEach(([w, h, dd, c, off], i) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, dd), std(c));
    b.position.set(d.x - 0.5 + off, 0.82 + i * 0.04, d.z + 0.15); groups.exam.add(b);
  });
  const mug = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.045, 0.1, 12), std(0xf4efe6));
  mug.position.set(d.x + 0.4, 0.85, d.z + 0.2); groups.exam.add(mug);
});

// monsoon week: umbrellas by the door and puddles on the floor
{
  const g = groups.monsoon;
  const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.2, 0.5, 14), std(0x3b5f6b)); stand.position.set(2.7, 0.25, 9.3); g.add(stand);
  [[0xd9534f, -0.12, 0.25], [0xf0b840, 0.0, -0.2], [0x4a90d9, 0.12, 0.3]].forEach(([c, dx, tilt]) => {
    const u = new THREE.Group(); u.position.set(2.7 + dx, 0.45, 9.3); u.rotation.z = tilt;
    const h = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.9, 6), std(0x2a2a2a)); h.position.y = 0.45; u.add(h);
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.4, 0.22, 12, 1, true), new THREE.MeshStandardMaterial({ color: c, roughness: 0.8, side: THREE.DoubleSide })); cap.position.y = 0.95; u.add(cap);
    g.add(u);
  });
  [[0, 9.1, 0.55], [-0.7, 8.4, 0.35], [0.8, 8.6, 0.3]].forEach(([x, z, r]) => {
    const p = new THREE.Mesh(new THREE.CircleGeometry(r, 24), new THREE.MeshStandardMaterial({ color: 0x2d3a4a, roughness: 0.1, transparent: true, opacity: 0.55 }));
    p.rotation.x = -Math.PI / 2; p.position.set(x, 0.015, z); g.add(p);
  });
}
// winter study week: fairy lights, a blanket on the sofa
const fairyMat = new THREE.MeshStandardMaterial({ color: 0xfff2c0, emissive: 0xffc860, emissiveIntensity: 1.5 });
{
  const g = groups.winter, spans = [[-7.4, 7.4, -9.85], [-7.4, -1.9, 9.85], [1.9, 7.4, 9.85]], pos = [];
  spans.forEach(([x0, x1, z]) => { const n = Math.round((x1 - x0) / 0.45); for (let i = 0; i <= n; i++) { const t = i / n; pos.push([x0 + (x1 - x0) * t, 3.7 - 0.3 * Math.sin(Math.PI * t), z]); } });
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(0.05, 8, 6), fairyMat, pos.length), d = new THREE.Object3D();
  pos.forEach((p, i) => { d.position.set(...p); d.updateMatrix(); im.setMatrixAt(i, d.matrix); });
  g.add(im);
  const blanket = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.05, 2.1), std(0xb04a4a)); blanket.position.set(6.7, 0.475, 7); g.add(blanket);
}
// new year challenge: balloons by the door and a banner (fireworks are below)
const balloons = [];
{
  const g = groups.newyear, cols = [0xe05a4f, 0xf0b840, 0x4fa3d9, 0x6cc070, 0xb06ad9, 0xf07ab0];
  [-2.4, 2.4].forEach((bx, side) => {
    for (let i = 0; i < 5; i++) {
      const b = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10), std(cols[(i + side * 2) % cols.length], { roughness: 0.4 }));
      b.scale.y = 1.25; b.position.set(bx + R(-0.3, 0.3), 2.0 + R(0, 0.8), 9.3 + R(-0.2, 0.2)); g.add(b); balloons.push({ b, base: b.position.y, ph: R(0, 6) });
    }
  });
  const c = document.createElement('canvas'); c.width = 1024; c.height = 128;
  const x = c.getContext('2d');
  x.fillStyle = '#2a2342'; x.fillRect(0, 0, 1024, 128); x.strokeStyle = '#f0c48a'; x.lineWidth = 8; x.strokeRect(4, 4, 1016, 120);
  x.fillStyle = '#f7d77a'; x.font = 'bold 60px Georgia'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(`🎆 HAPPY NEW YEAR ${challengeWindow().year} 🎆`, 512, 68);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const banner = new THREE.Mesh(new THREE.PlaneGeometry(6, 0.75), new THREE.MeshBasicMaterial({ map: t })); banner.position.set(0, 3.4, -9.95); g.add(banner);
}
// fireworks in the sky outside (evening and night only)
const FW = 240, fwPos = new Float32Array(FW * 3), fwCol = new Float32Array(FW * 3), fwVel = new Float32Array(FW * 3), fwLife = new Float32Array(FW), fwBase = new Float32Array(FW * 3);
fwPos.fill(-999);
const fwGeo = new THREE.BufferGeometry();
fwGeo.setAttribute('position', new THREE.BufferAttribute(fwPos, 3)); fwGeo.setAttribute('color', new THREE.BufferAttribute(fwCol, 3));
const fw = new THREE.Points(fwGeo, new THREE.PointsMaterial({ size: 4, sizeAttenuation: false, vertexColors: true, fog: false, depthWrite: false, blending: THREE.AdditiveBlending, transparent: true }));
fw.frustumCulled = false; fw.visible = false; scene.add(fw);
let slot = 0, nextBurst = 0;
function burst() {
  const cx = R(-30, 30), cy = R(20, 34), cz = -R(50, 70), c = new THREE.Color().setHSL(Math.random(), 1, 0.6), base = (slot++ % 4) * 60;
  for (let i = 0; i < 60; i++) {
    const j = base + i, a = Math.random() * Math.PI * 2, b = Math.acos(2 * Math.random() - 1), sp = R(6, 12);
    fwPos[j * 3] = cx; fwPos[j * 3 + 1] = cy; fwPos[j * 3 + 2] = cz;
    fwVel[j * 3] = sp * Math.sin(b) * Math.cos(a); fwVel[j * 3 + 1] = sp * Math.cos(b); fwVel[j * 3 + 2] = sp * Math.sin(b) * Math.sin(a);
    fwBase[j * 3] = c.r; fwBase[j * 3 + 1] = c.g; fwBase[j * 3 + 2] = c.b; fwLife[j] = 1.8;
  }
}

// ---- the event poster on the north wall
const pc = document.createElement('canvas'); pc.width = 330; pc.height = 450;
const pg = pc.getContext('2d');
const pTex = new THREE.CanvasTexture(pc); pTex.colorSpace = THREE.SRGBColorSpace;
const poster = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.5), new THREE.MeshBasicMaterial({ map: pTex }));
poster.position.set(2.25, 2.1, -9.955); poster.visible = false; scene.add(poster);
const THEME = { exam: ['#f3e3c3', '#4a2c17'], monsoon: ['#cfe0ea', '#1f3a4d'], winter: ['#e3eefc', '#1f3a6b'], newyear: ['#2a2342', '#f7d77a'] };
function fit(text, x, y, size, maxW) {
  let s = size; pg.font = `bold ${s}px Georgia`;
  while (pg.measureText(text).width > maxW && s > 14) { s -= 1; pg.font = `bold ${s}px Georgia`; }
  pg.fillText(text, x, y);
}
function wrap(text, x, y, maxW, lh) {
  let line = '';
  text.split(' ').forEach(w => { const t = line ? `${line} ${w}` : w; if (pg.measureText(t).width > maxW && line) { pg.fillText(line, x, y); y += lh; line = w; } else line = t; });
  pg.fillText(line, x, y);
}
function drawPoster() {
  const b = eventBanner();
  poster.visible = !!b;
  if (!b) return;
  const [bg, fg] = THEME[b.key];
  pg.fillStyle = bg; pg.fillRect(0, 0, 330, 450); pg.strokeStyle = fg; pg.lineWidth = 8; pg.strokeRect(6, 6, 318, 438);
  pg.fillStyle = fg; pg.textAlign = 'center'; pg.textBaseline = 'alphabetic';
  fit(b.title.split(' ')[0], 165, 120, 90, 280);
  fit(b.title.split(' ').slice(1).join(' '), 165, 190, 38, 290);
  pg.font = '24px Georgia'; b.lines.forEach((l, i) => wrap(l, 165, 250 + i * 80, 280, 28));
  pTex.needsUpdate = true;
}

// ---- apply the current event
let applied = '#', pending = '', lastCheck = 0, lastPoster = 0;
const MSG = {
  exam: "📚 Exam Season is on. You've got this!", monsoon: '☔ Monsoon Week: cosy up with a good book.',
  winter: '❄️ Winter Study Week: snow outside, warm lamps inside.', newyear: '🎆 New Year Challenge: study 30 minutes on 5 days to earn the badge.',
};
function apply() {
  const ev = currentEvent(), key = ev ? ev.key : '';
  if (key === applied) return;
  applied = key;
  Object.entries(groups).forEach(([k, g]) => { g.visible = k === key; });
  setWinter(key === 'winter');
  envHooks.forced = key === 'monsoon' ? 'rainy' : null; refreshMood();
  drawPoster();
  if (key) {
    const seen = `${key}:${dayKey(new Date())}`;
    try { if (localStorage.getItem('cozylib.evSeen') !== seen) { localStorage.setItem('cozylib.evSeen', seen); pending = MSG[key]; } } catch { pending = MSG[key]; }
  }
}
export function setEventMode(m) {
  mode = m;
  try { localStorage.setItem(KEY, m); } catch { /* ignore */ }
  apply(); const ev = currentEvent(); pending = ev ? MSG[ev.key] : '🚫 No special event';
}
apply();

// called every frame
export function updateEvents(dt) {
  const now = performance.now(), t = now / 1000;
  if (now - lastCheck > 5000) { lastCheck = now; apply(); checkBadge(); }
  if (now - lastPoster > 30000) { lastPoster = now; drawPoster(); }
  if (pending && state.screen === 'library') { emoteToast(pending); pending = ''; }
  if (groups.winter.visible) fairyMat.emissiveIntensity = 1.3 + 0.5 * Math.sin(t * 2);
  if (groups.newyear.visible) {
    balloons.forEach(o => { o.b.position.y = o.base + Math.sin(t * 1.2 + o.ph) * 0.06; });
    const key = currentKey(), show = key === 'night' || key === 'evening';
    fw.visible = show;
    if (show) {
      if (now > nextBurst) { burst(); nextBurst = now + R(1800, 4200); }
      for (let j = 0; j < FW; j++) {
        if (fwLife[j] > 0) {
          fwVel[j * 3 + 1] -= 4 * dt;
          for (let k = 0; k < 3; k++) fwPos[j * 3 + k] += fwVel[j * 3 + k] * dt;
          fwLife[j] -= dt; const f = Math.max(0, Math.min(1, fwLife[j]));
          for (let k = 0; k < 3; k++) fwCol[j * 3 + k] = fwBase[j * 3 + k] * f;
        } else { fwPos[j * 3 + 1] = -999; }
      }
      fwGeo.attributes.position.needsUpdate = true; fwGeo.attributes.color.needsUpdate = true;
    }
  } else fw.visible = false;
}
