// STUDY: Step 5 study timer + Step 6 background study mode
// The timer is based on real clock time, so the elapsed time is correct after the app was in the background.
import { LocalNotifications } from '@capacitor/local-notifications';
import { updateSession, activeSession } from './checkin.js';
import { state } from './core.js';
import { triggerMine } from './emote.js';

let base = 0, since = null, last = '', lastSec = 0, notifOk = false, asked = false;
function sync() {
  const s = activeSession();
  base = s ? s.totalStudyMs || 0 : 0;
  since = s && s.runningSince ? new Date(s.runningSince).getTime() : null;
}
sync();

// ---- quiet notification while the app is in the background
async function setupNotifications() {
  try {
    const p = await LocalNotifications.requestPermissions();
    notifOk = p.display === 'granted';
    if (notifOk) await LocalNotifications.createChannel({ id: 'study', name: 'Study session', description: 'Shown while you study with the app in the background', importance: 2, visibility: 1 });
  } catch { notifOk = false; }
}
async function showNote() {
  if (!notifOk || since === null) return;
  const t = new Date(since).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  try {
    await LocalNotifications.schedule({ notifications: [{ id: 1, channelId: 'study', title: '📖 Study session active', body: `Studying since ${t}. Tap to return to the library.`, ongoing: true, autoCancel: false }] });
  } catch { /* ignore */ }
}
async function hideNote() { try { await LocalNotifications.cancel({ notifications: [{ id: 1 }] }); } catch { /* ignore */ } }
document.addEventListener('visibilitychange', () => { if (document.hidden) showNote(); else hideNote(); });
hideNote();
if (since !== null) setupNotifications();

export function startStudy() {
  updateSession(s => {
    if (s.runningSince) return;
    s.runningSince = new Date().toISOString();
    if (!s.studyStart) s.studyStart = s.runningSince;
  });
  sync();
  if (!asked) { asked = true; setupNotifications(); }
}
export function stopStudy() {
  let hourUp = false;
  updateSession(s => {
    if (!s.runningSince) return;
    const now = new Date();
    const before = s.totalStudyMs || 0;
    s.totalStudyMs = before + (now - new Date(s.runningSince));
    hourUp = Math.floor(s.totalStudyMs / 3600000) > Math.floor(before / 3600000);
    s.studyEnd = now.toISOString(); s.runningSince = null;
  });
  sync(); hideNote();
  if (hourUp) triggerMine('party');
}

const css = document.createElement('style');
css.textContent = '#study{position:fixed;left:calc(14px + env(safe-area-inset-left,0px));top:calc(66px + env(safe-area-inset-top,0px));display:none;color:#ffe9c4;background:rgba(42,26,16,.75);padding:6px 12px;border-radius:14px;font:15px Georgia,serif;font-variant-numeric:tabular-nums;pointer-events:none;max-width:calc(100vw - 110px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}';
document.head.appendChild(css);
const hud = document.createElement('div'); hud.id = 'study'; document.body.appendChild(hud);
const pad = n => String(n).padStart(2, '0');
const fmt = ms => { const t = Math.floor(ms / 1000); return `${pad(Math.floor(t / 3600))}:${pad(Math.floor(t / 60) % 60)}:${pad(t % 60)}`; };

// called every frame
export function updateStudyHud() {
  const sec = Math.floor(Date.now() / 1000);
  if (sec !== lastSec) { lastSec = sec; sync(); }
  const total = base + (since ? Date.now() - since : 0);
  const label = state.spotName ? `☕ On a break · study time ${fmt(total)}` : since ? `📖 Studying  ${fmt(total)}` : base > 0 ? `⏸ Study time  ${fmt(total)}` : '';
  if (label === last) return;
  last = label; hud.textContent = label; hud.style.display = label ? 'block' : 'none';
}
