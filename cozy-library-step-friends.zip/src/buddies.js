// BUDDIES: friends made inside the library. Tap a character for their card, send a friend request, and chat privately once both accept.
import { doc, getDoc, setDoc, deleteDoc, collection, query, where, orderBy, limit, onSnapshot, addDoc, getDocs } from 'firebase/firestore';
import { db, myUid, onReady } from './firebase.js';
import { getName, allSessions } from './checkin.js';
import { levelInfo, getShirt, getPrivacy, bump } from './stats.js';
import { achievementList, DEFS } from './achievements.js';
import { peekStandings } from './board.js';
import { realLb } from './lb.js';
import { onAvatarTap, presenceOf } from './friends.js';
import { emoteToast } from './emote.js';
import { sfx } from './audio.js';
import { state } from './core.js';

const css = document.createElement('style');
css.textContent = `
#budp{position:fixed;inset:0;display:none;z-index:27;overflow-y:auto;-webkit-overflow-scrolling:touch;background:rgba(32,20,12,.98);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#budp .wrap{max-width:480px;margin:0 auto}
#budp .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:8px}
#budp h2{margin:0;font-size:22px}
#budp h3{margin:18px 0 6px;font-size:16px;color:#f0c48a}
#budp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px;flex:none}
#budp .row{display:flex;align-items:center;gap:10px;background:rgba(255,243,196,.12);border-radius:12px;padding:10px 12px;margin-bottom:8px}
#budp .row .g{flex:1;min-width:0}
#budp .row b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#budp .row small{opacity:.75}
#budp .row i{font-style:normal;background:#d23c3c;color:#fff;border-radius:10px;padding:0 8px;font-size:12px}
#budp button.s{padding:8px 14px;border-radius:16px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 14px Georgia,serif}
#budp button.s.no{background:transparent}
#budp .b{display:block;width:100%;margin-top:10px;padding:13px;border-radius:24px;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 16px Georgia,serif}
#budp .b.no{background:transparent}
#budp .b:disabled,#budp button.s:disabled{opacity:.5}
#budp .note{font-size:14px;opacity:.75;margin:6px 0}
#budp .hero{text-align:center;margin:4px 0 10px}
#budp .av{width:84px;height:84px;border-radius:50%;margin:0 auto 6px;border:4px solid #f0c48a;display:flex;align-items:center;justify-content:center;font:700 40px Georgia,serif;color:#fff;text-shadow:0 2px 4px rgba(0,0,0,.4)}
#budp .ach{display:flex;gap:6px;flex-wrap:wrap;font-size:26px;justify-content:center}
#budp .list{height:calc(100vh - 230px);min-height:160px;overflow-y:auto;background:rgba(255,243,196,.07);border-radius:12px;padding:8px 10px;margin-bottom:8px}
#budp .m{margin:5px 0;max-width:85%;padding:7px 11px;border-radius:14px;background:rgba(255,243,196,.16);word-wrap:break-word;width:fit-content}
#budp .m.me{margin-left:auto;background:#8a5a34}
#budp .m small{display:block;opacity:.6;font-size:11px}
#budp .send{display:flex;gap:8px}
#budp input{flex:1;min-width:0;padding:11px 14px;font-size:16px;border-radius:20px;border:2px solid #c08a52;background:#fff7e8;color:#2a1a10}
#budp .msg{margin-top:12px;padding:10px;border-radius:10px;background:rgba(255,243,196,.14)}`;
document.head.appendChild(css);
const panel = document.createElement('div'); panel.id = 'budp'; document.body.appendChild(panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const hex = n => '#' + (n || 0x3f7fbf).toString(16).padStart(6, '0');
const pairOf = (a, b) => (a < b ? a + '_' + b : b + '_' + a);

// ---- live data about me
let friends = new Map(), incoming = [], outgoing = [], blocked = new Map(), unsubs = [], lastUnsubs = new Map(), unread = new Set(), ready = false;
const names = new Map();
let view = null; // what is open: { t: 'list' } | { t: 'card', id, name } | { t: 'chat', id }
const READ = 'cozylib.dmRead';
const readMap = () => { try { return JSON.parse(localStorage.getItem(READ)) || {}; } catch { return {}; } };
const markRead = id => { const m = readMap(); m[id] = Date.now(); try { localStorage.setItem(READ, JSON.stringify(m)); } catch { /* ignore */ } unread.delete(id); };
export const buddyBadge = () => unread.size + incoming.length;
export const relationOf = id => (friends.has(id) ? 'friend' : blocked.has(id) ? 'blocked' : incoming.some(r => r.from === id) ? 'incoming' : outgoing.some(r => r.to === id) ? 'outgoing' : 'none');
const refresh = () => { if (panel.style.display === 'block' && view && view.t !== 'chat') draw(); };

// ---- my public profile (only what I allow; people in my room and my friends can read it)
let lastProf = '';
export function publishProfile(force) {
  const id = myUid(); if (!id || state.erasing) return;
  const name = (getName() || 'Guest').slice(0, 40);
  let p = { name };
  if (getPrivacy() === 'all') {
    const real = realLb(), lv = levelInfo(real.all), clean = !allSessions().some(r => r.test);
    p = { name, level: lv.level, title: lv.title, shirt: getShirt() || 0, ms: real.all, ach: clean ? achievementList().filter(a => a.unlocked).map(a => a.id) : [],
      champ: clean ? peekStandings().hall.filter(h => h.key === id).length : 0 };
  }
  const json = JSON.stringify(p);
  if (!force && json === lastProf) return;
  lastProf = json;
  setDoc(doc(db, 'profiles', id), { ...p, u: Date.now() }).catch(() => { lastProf = ''; });
}

async function loadProfile(id) {
  try { const s = await getDoc(doc(db, 'profiles', id)); if (s.exists()) { names.set(id, s.data().name || 'Friend'); return s.data(); } } catch { /* not allowed or offline */ }
  return null;
}

// ---- actions
export async function sendRequest(id, name) {
  const me = myUid();
  if (relationOf(id) === 'incoming') return acceptFrom(id);
  await setDoc(doc(db, 'friendRequests', me + '_' + id), { from: me, to: id, name: (getName() || 'Guest').slice(0, 40), createdAt: Date.now() });
  names.set(id, name);
}
async function acceptFrom(id) {
  const me = myUid();
  await setDoc(doc(db, 'friends', pairOf(me, id)), { uids: [me, id].sort(), createdAt: Date.now() });
  await deleteDoc(doc(db, 'friendRequests', id + '_' + me)).catch(() => {});
  await deleteDoc(doc(db, 'friendRequests', me + '_' + id)).catch(() => {});
  sfx.chime();
}
const declineFrom = id => deleteDoc(doc(db, 'friendRequests', id + '_' + myUid()));
const cancelTo = id => deleteDoc(doc(db, 'friendRequests', myUid() + '_' + id));
export async function wipeChat(pair) {
  const snap = await getDocs(collection(db, 'dms', pair, 'messages'));
  await Promise.all(snap.docs.map(d => deleteDoc(d.ref).catch(() => {})));
}
async function unfriend(id) {
  const pair = pairOf(myUid(), id);
  await wipeChat(pair).catch(() => {});
  await deleteDoc(doc(db, 'friends', pair));
}
async function blockUser(id, name) {
  const me = myUid();
  await setDoc(doc(db, 'blocks', me + '_' + id), { by: me, target: id, name, createdAt: Date.now() });
  await Promise.all([friends.has(id) ? unfriend(id) : null, deleteDoc(doc(db, 'friendRequests', id + '_' + me)).catch(() => {}), deleteDoc(doc(db, 'friendRequests', me + '_' + id)).catch(() => {})]);
}
const unblock = id => deleteDoc(doc(db, 'blocks', myUid() + '_' + id));

// ---- screens
const friendlyErr = e => (e && e.code === 'permission-denied' ? 'That is not allowed right now. You can only add people you share a study room with, and the new Firebase rules must be published.' : e && e.code === 'unavailable' ? 'No internet connection.' : 'Something went wrong (' + ((e && (e.code || e.message)) || 'unknown') + ').');
function frame(title, back) {
  const wrap = mk('div', 'wrap'), top = mk('div', 'top');
  const x = mk('button', 'x', back ? '←' : '✕'); x.onclick = back || (() => { panel.style.display = 'none'; view = null; });
  top.append(x, mk('h2', '', title), mk('span')); top.lastChild.style.width = '44px';
  wrap.append(top); return wrap;
}
function show(wrap) { panel.replaceChildren(wrap); panel.style.display = 'block'; }
const withMsg = (wrap, buttons) => {
  const msg = mk('div', 'msg'); msg.style.display = 'none';
  const run = async (fn, after) => {
    buttons.forEach(b => { b.disabled = true; });
    try { await fn(); if (after) after(); } catch (e) { msg.textContent = friendlyErr(e); msg.style.display = 'block'; buttons.forEach(b => { b.disabled = false; }); }
  };
  wrap.append(msg); return run;
};

async function drawCard(id, name) {
  view = { t: 'card', id, name };
  const wrap = frame('Player', () => { panel.style.display = 'none'; view = null; });
  wrap.append(mk('div', 'note', 'Loading...')); show(wrap);
  const p = await loadProfile(id);
  if (!view || view.t !== 'card' || view.id !== id) return;
  const w = frame('Player', () => { panel.style.display = 'none'; view = null; });
  const nm = (p && p.name) || name, hero = mk('div', 'hero'), av = mk('div', 'av', nm.charAt(0).toUpperCase());
  av.style.background = hex(p && p.shirt);
  hero.append(av, mk('h2', '', nm));
  if (p && p.level) hero.append(mk('div', '', `Level ${p.level} · ${p.title}`));
  w.append(hero);
  if (p && p.level) {
    const rank = peekStandings().allTime.findIndex(r => r.key === id);
    const info = mk('div', 'row'), g = mk('div', 'g');
    g.append(mk('b', '', `📚 ${Math.floor((p.ms || 0) / 3600000)} h total study`), mk('small', '', `🏆 ${p.champ || 0} champion week${p.champ === 1 ? '' : 's'}${rank >= 0 ? ` · #${rank + 1} in this room (all time)` : ''}`));
    info.append(g); w.append(info);
    const ids = new Set(p.ach || []);
    w.append(mk('h3', '', `Achievements ${ids.size}/${DEFS.length}`));
    const ach = mk('div', 'ach');
    DEFS.filter(d => ids.has(d.id)).forEach(d => { const s = mk('span', '', d.icon); s.title = d.name; ach.append(s); });
    w.append(ach.childNodes.length ? ach : mk('div', 'note', 'No achievements yet.'));
  } else w.append(mk('div', 'note', 'This player keeps their level and achievements private.'));
  const bs = [], run = withMsg(w, bs), rel = relationOf(id), again = () => drawCard(id, nm);
  const act = (label, fn, cls = 'b') => { const b = mk('button', cls, label); b.onclick = () => run(fn, again); bs.push(b); w.append(b); return b; };
  if (rel === 'none') act('➕ Send friend request', () => sendRequest(id, nm));
  else if (rel === 'outgoing') { w.append(mk('div', 'note', 'Friend request sent. Waiting for them to accept.')); act('Cancel request', () => cancelTo(id), 'b no'); }
  else if (rel === 'incoming') act('✅ Accept friend request', () => acceptFrom(id));
  else if (rel === 'friend') { w.append(mk('div', 'note', '✅ You are friends.')); const b = mk('button', 'b', '💬 Message'); b.onclick = () => drawChat(id); w.append(b); }
  else w.append(mk('div', 'note', 'You blocked this player.'));
  if (rel !== 'blocked') act('🚫 Block', () => blockUser(id, nm), 'b no'); else act('Unblock', () => unblock(id), 'b no');
  show(w);
}

function draw() {
  view = { t: 'list' };
  const w = frame('👥 Friends and messages'), bs = [], run = withMsg(w, bs);
  const go = (fn) => run(fn, draw);
  if (incoming.length) {
    w.append(mk('h3', '', `Friend requests (${incoming.length})`));
    incoming.forEach(r => {
      const row = mk('div', 'row'), g = mk('div', 'g'), ok = mk('button', 's', 'Accept'), no = mk('button', 's no', 'Decline');
      g.append(mk('b', '', r.name || 'Player'), mk('small', '', 'wants to be your friend'));
      ok.onclick = () => go(() => acceptFrom(r.from)); no.onclick = () => go(() => declineFrom(r.from)); bs.push(ok, no);
      row.append(g, ok, no); w.append(row);
    });
  }
  w.append(mk('h3', '', `Friends (${friends.size})`));
  if (!friends.size) w.append(mk('div', 'note', 'No friends yet. Join a study room (☰ > Study room), then tap a friend\'s character in the library to send a request.'));
  friends.forEach((_, id) => {
    const row = mk('div', 'row'), g = mk('div', 'g'), pr = presenceOf(id);
    g.append(mk('b', '', names.get(id) || '...'), mk('small', '', pr && Date.now() - pr.updatedAt < 120000 ? '🟢 in the library' : 'tap to message'));
    row.append(g); if (unread.has(id)) row.append(mk('i', '', 'new'));
    row.onclick = () => drawChat(id); w.append(row);
    if (!names.has(id)) loadProfile(id).then(() => refresh());
  });
  if (outgoing.length) {
    w.append(mk('h3', '', 'Requests you sent'));
    outgoing.forEach(r => {
      const row = mk('div', 'row'), g = mk('div', 'g'), c = mk('button', 's no', 'Cancel');
      g.append(mk('b', '', names.get(r.to) || 'Player'), mk('small', '', 'waiting for them'));
      c.onclick = () => go(() => cancelTo(r.to)); bs.push(c); row.append(g, c); w.append(row);
    });
  }
  if (blocked.size) {
    w.append(mk('h3', '', 'Blocked'));
    blocked.forEach((b, id) => {
      const row = mk('div', 'row'), g = mk('div', 'g'), u = mk('button', 's no', 'Unblock');
      g.append(mk('b', '', b.name || 'Player')); u.onclick = () => go(() => unblock(id)); bs.push(u); row.append(g, u); w.append(row);
    });
  }
  w.append(mk('div', 'note', 'Private messages are only between you and one friend. Nobody else can read them. Removing a friend deletes the conversation.'));
  show(w);
}

// ---- private chat
let chatUnsub = null, lastSend = 0;
function drawChat(id) {
  view = { t: 'chat', id };
  const back = () => { if (chatUnsub) { chatUnsub(); chatUnsub = null; } draw(); };
  const w = frame('💬 ' + (names.get(id) || 'Friend'), back), list = mk('div', 'list'), row = mk('div', 'send'), inp = mk('input'), send = mk('button', 's', 'Send');
  inp.maxLength = 500; inp.placeholder = 'Write a message'; inp.autocomplete = 'off'; row.append(inp, send);
  const note = mk('div', 'note'); w.append(list, row, note);
  const rm = mk('button', 'b no', 'Remove friend'); rm.onclick = async () => { rm.disabled = true; try { if (chatUnsub) { chatUnsub(); chatUnsub = null; } await unfriend(id); } catch (e) { note.textContent = friendlyErr(e); rm.disabled = false; return; } draw(); };
  w.append(rm); show(w); markRead(id);
  const pair = pairOf(myUid(), id);
  if (chatUnsub) chatUnsub();
  chatUnsub = onSnapshot(query(collection(db, 'dms', pair, 'messages'), orderBy('createdAt', 'desc'), limit(60)), snap => {
    const msgs = snap.docs.map(d => d.data()).reverse();
    list.replaceChildren();
    if (!msgs.length) list.append(mk('div', 'note', 'No messages yet. Say hello!'));
    msgs.forEach(m => { const b = mk('div', m.uid === myUid() ? 'm me' : 'm', m.text); b.append(mk('small', '', new Date(m.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }))); list.append(b); });
    list.scrollTop = list.scrollHeight; markRead(id);
  }, () => { note.textContent = 'Cannot load messages. You may not be friends any more.'; });
  const doSend = () => {
    const text = inp.value.trim().slice(0, 500);
    if (!text || Date.now() - lastSend < 700) return;
    lastSend = Date.now(); inp.value = ''; bump('chat');
    addDoc(collection(db, 'dms', pair, 'messages'), { uid: myUid(), text, createdAt: Date.now() }).catch(e => { note.textContent = friendlyErr(e); });
  };
  send.onclick = doSend; inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); doSend(); } });
}

export const openBuddies = () => { draw(); };
export const openCard = (id, name) => drawCard(id, name);
onAvatarTap((id, name) => { if (id !== myUid()) openCard(id, name); });

// ---- listeners
export function stopBuddies() { unsubs.forEach(u => u()); lastUnsubs.forEach(u => u()); unsubs = []; lastUnsubs.clear(); if (chatUnsub) { chatUnsub(); chatUnsub = null; } ready = false; }
function watchLast() {
  for (const [id, u] of lastUnsubs) if (!friends.has(id)) { u(); lastUnsubs.delete(id); unread.delete(id); }
  friends.forEach((_, id) => {
    if (lastUnsubs.has(id)) return;
    let first = true;
    lastUnsubs.set(id, onSnapshot(query(collection(db, 'dms', pairOf(myUid(), id), 'messages'), orderBy('createdAt', 'desc'), limit(1)), snap => {
      const m = snap.docs[0] && snap.docs[0].data();
      const isNew = m && m.uid !== myUid() && m.createdAt > (readMap()[id] || 0) && !(view && view.t === 'chat' && view.id === id);
      if (isNew) { unread.add(id); if (!first) { sfx.ding(); emoteToast(`💬 ${names.get(id) || 'A friend'}: new message`); } } else unread.delete(id);
      first = false; refresh();
    }, () => {}));
  });
}
onReady(me => {
  ready = true;
  unsubs.push(
    onSnapshot(query(collection(db, 'friends'), where('uids', 'array-contains', me)), snap => {
      friends = new Map(snap.docs.map(d => { const u = d.data().uids.find(x => x !== me); return [u, d.id]; }));
      watchLast(); refresh();
    }, () => {}),
    onSnapshot(query(collection(db, 'friendRequests'), where('to', '==', me)), snap => {
      const old = incoming.length; incoming = snap.docs.map(d => d.data());
      incoming.forEach(r => names.set(r.from, r.name));
      if (incoming.length > old && ready && old >= 0) { sfx.chime(); emoteToast('👥 New friend request'); }
      refresh();
    }, () => {}),
    onSnapshot(query(collection(db, 'friendRequests'), where('from', '==', me)), snap => { outgoing = snap.docs.map(d => d.data()); refresh(); }, () => {}),
    onSnapshot(query(collection(db, 'blocks'), where('by', '==', me)), snap => { blocked = new Map(snap.docs.map(d => [d.data().target, d.data()])); refresh(); }, () => {}));
  publishProfile(true); setInterval(() => publishProfile(false), 60000);
});
