// LOUNGE: Step 16 break and social area (sofa, lounge chairs, window seats). Breaks never count as study time.
import * as THREE from 'three';
import { state } from './core.js';
import { player } from './characters.js';
import { breakSpots } from './world.js';
import { tween, ease } from './interactions.js';
import { updateSession } from './checkin.js';
import { bump } from './stats.js';
import { sfx } from './audio.js';

const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
const css = document.createElement('style');
css.textContent = `
#lounge{position:fixed;right:calc(20px + env(safe-area-inset-right,0px));bottom:calc(260px + env(safe-area-inset-bottom,0px));display:none;padding:16px 26px;border-radius:32px;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font:600 19px Georgia,serif;touch-action:manipulation;box-shadow:0 4px 14px rgba(0,0,0,.4)}
#ltoast{position:fixed;left:50%;top:calc(70px + env(safe-area-inset-top,0px));transform:translateX(-50%);display:none;z-index:30;max-width:80%;text-align:center;padding:12px 18px;border-radius:16px;border:2px solid #ffe9c4;background:rgba(42,26,16,.95);color:#ffe9c4;font:17px Georgia,serif}`;
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'lounge'; document.body.appendChild(btn);
const toastEl = document.createElement('div'); toastEl.id = 'ltoast'; document.body.appendChild(toastEl);
let toastTimer = 0;
function toast(text) { toastEl.textContent = text; toastEl.style.display = 'block'; clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.style.display = 'none'; }, 3200); }

let near = null, cur = null, transit = false, since = 0, lastLabel = '';

async function sit(sp) {
  transit = true; state.busy = true; cur = sp;
  const a = new THREE.Vector3(sp.ax, 0, sp.az), s = new THREE.Vector3(sp.x, 0, sp.z);
  const p0 = player.position.clone(), r0 = player.rotation.y, a1 = Math.atan2(s.x - a.x, s.z - a.z);
  state.forceWalk = true;
  await tween(0.5, k => { const e = ease(k); player.position.lerpVectors(p0, a, e); player.rotation.y = r0 + wrap(a1 - r0) * e; });
  state.forceWalk = false;
  const r1 = player.rotation.y;
  sfx.chair();
  await tween(0.7, k => { const e = ease(k); player.position.lerpVectors(a, s, e); player.rotation.y = r1 + wrap(sp.rot - r1) * e; state.sitK = e; });
  state.seated = true; state.spotName = sp.name; state.faceT = sp.rot; since = Date.now(); transit = false;
  toast(`Break time at ${sp.name}. Your study timer is paused, and breaks do not count as study time.`);
}
async function getUp() {
  sfx.chair(); transit = true; state.spotName = null;
  const s = player.position.clone(), a = new THREE.Vector3(cur.ax, 0, cur.az);
  await tween(0.6, k => { const e = ease(k); player.position.lerpVectors(s, a, e); state.sitK = 1 - e; });
  state.seated = false; state.busy = false; transit = false;
  const ms = Date.now() - since;
  updateSession(r => { r.breakMs = (r.breakMs || 0) + ms; }); bump('breaks'); // kept separate from study time
}
btn.addEventListener('pointerdown', e => {
  e.stopPropagation();
  if (transit) return;
  if (state.spotName) getUp();
  else if (near && !state.busy) { const who = state.occupied[near.name]; if (who) toast(`${near.name} is taken by ${who}.`); else sit(near); }
});

// called every frame
export function updateLounge() {
  let best = null, bd = 1.3;
  if (!state.busy && !state.seated) {
    for (const sp of breakSpots) {
      const d = Math.hypot(player.position.x - sp.x, player.position.z - sp.z);
      if (d < bd) { bd = d; best = sp; }
    }
  }
  near = best;
  const who = best && state.occupied[best.name];
  const label = transit ? '' : state.spotName ? '🧍 Get up' : best ? (who ? `🔒 ${best.name} is taken by ${who}` : `☕ Take a break · ${best.name}`) : '';
  if (label !== lastLabel) { lastLabel = label; btn.textContent = label; btn.style.display = label ? 'block' : 'none'; }
}
