// WORLD: the library room, furniture, books, decorations and lights
import * as THREE from 'three';
import { W, L, HX, HZ, WH, scene, mat, glow, solids, WOOD, DARK, CREAM, box } from './core.js';
import { ICONS } from './books.js';

// ---------- room ----------
box(W, 0.2, L, 0, -0.2, 0, 0x9b6b43, false, false);
// walls built as bands (no seams across the openings); wooden trim covers the joins
function wall(x0, x1, zc, openings) {
  const piece = (xa, xb, y, h) => box(xb - xa, h, 0.4, (xa + xb) / 2, y, zc, CREAM, false, false);
  piece(x0, x1, 0, 1.35); piece(x0, x1, 2.85, WH - 2.85);
  let cur = x0; const spans = [];
  [...openings].sort((a, b) => a - b).forEach(c => { spans.push([cur, c - 1]); cur = c + 1; });
  spans.push([cur, x1]);
  spans.forEach(([a, b]) => {
    if (b - a < 0.01) return;
    piece(a, b, 1.35, 1.5);
    [1.3, 2.8].forEach(my => box(b - a, 0.1, 0.45, (a + b) / 2, my, zc, WOOD, false, false));
  });
  solids.push({ x0, x1, z0: zc - 0.2, z1: zc + 0.2 });
}
wall(-HX - 0.4, HX + 0.4, -HZ - 0.2, [-4.5, 0, 4.5]);
wall(-HX - 0.4, -1.5, HZ + 0.2, [-4.5]);
wall(1.5, HX + 0.4, HZ + 0.2, [4.5]);
box(0.4, WH, L, -HX - 0.2, 0, 0, CREAM, true, false);
box(0.4, WH, L, HX + 0.2, 0, 0, CREAM, true, false);
box(3.4, 0.7, 0.55, 0, 3.4, HZ + 0.2, CREAM, false, false);
box(0.22, 3.4, 0.55, -1.56, 0, HZ + 0.2, WOOD, false, false);
box(0.22, 3.4, 0.55, 1.56, 0, HZ + 0.2, WOOD, false, false);

export const windowMats = [], windowSpots = [];
const glassMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, depthWrite: false });
windowMats.push(glassMat);
function windowAt(x, z, rotY) {
  const g = new THREE.Group();
  g.position.set(x, 2.1, z); g.rotation.y = rotY; scene.add(g);
  box(2.5, 0.12, 0.22, 0, -0.87, 0, WOOD, false, false, g); // sill
  box(2.3, 0.14, 0.12, 0, 0.68, 0, WOOD, false, false, g); // top bar
  [-1, 1].forEach(sx => box(0.14, 1.5, 0.14, sx * 1.0, -0.75, 0, WOOD, false, false, g)); // sides
  box(1.9, 0.06, 0.1, 0, -0.03, 0, WOOD, false, false, g); // rail between the two sashes
  const up = new THREE.Mesh(new THREE.PlaneGeometry(2, 0.75), glassMat); up.position.set(0, 0.375, 0.01); g.add(up);
  const sash = new THREE.Group(); sash.position.set(0, -0.375, 0.03); g.add(sash); // the lower sash slides up to open
  sash.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 0.75), glassMat));
  [-0.965, 0.965].forEach(sx => box(0.05, 0.75, 0.04, sx, -0.375, 0, WOOD, false, false, sash));
  box(1.9, 0.05, 0.04, 0, -0.4, 0, WOOD, false, false, sash);
  box(1.9, 0.05, 0.04, 0, 0.35, 0, WOOD, false, false, sash);
  windowSpots.push({ x, z, rotY, sash });
}
[-4.5, 0, 4.5].forEach(x => windowAt(x, -HZ + 0.04, 0));
[-4.5, 4.5].forEach(x => windowAt(x, HZ - 0.04, Math.PI));

// rugs
box(9, 0.02, 8, 0, 0, -4.2, 0x7a5a4a, false, false);
box(3, 0.02, 2, 0, 0, 8.5, 0x8a3b3b, false, false);
box(3, 0.02, 3, 5.6, 0, 7, 0x9a4a3a, false, false);

// ---------- bookshelves (books share one instanced mesh) ----------
export const bookMats = [], shelves = [], bookCat = [];
export let bookIM;
const dummy = new THREE.Object3D();
const bookColors = [0xb23a48, 0x2f6f8f, 0xd9a441, 0x4f7f52, 0x7a4e9c, 0xe2814d, 0x3b4a6b, 0xc9b79c];
const CAT_COLORS = {
  Literature: [0xb23a48, 0x8a3b3b, 0xd9826a, 0x6b2f3a], Science: [0x2f6f8f, 0x3b8fb0, 0x1f4f6b, 0x56a6c9],
  History: [0x8a6a3a, 0xb08a4a, 0x6b4a2a, 0xc9a45a], Language: [0x4f7f52, 0x6aa46a, 0x3b6b45, 0x8fc08a],
  Research: [0x6b4e9c, 0x8a6ac0, 0x4a3a7a, 0xa890d9],
};
const catTex = {};
function catSign(cat) {
  if (catTex[cat]) return catTex[cat];
  const c = document.createElement('canvas'); c.width = 384; c.height = 96;
  const x = c.getContext('2d');
  x.fillStyle = '#f3e3c3'; x.fillRect(0, 0, 384, 96); x.strokeStyle = '#4a2c17'; x.lineWidth = 6; x.strokeRect(3, 3, 378, 90);
  x.fillStyle = '#4a2c17'; x.font = 'bold 44px Georgia'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(`${ICONS[cat] || '📚'} ${cat}`, 192, 50);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return (catTex[cat] = t);
}
function shelf(x, z, rotY, cat) {
  const len = 2.4, dep = 0.6, h = 2.6;
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotY; scene.add(g);
  if (cat) { const sg = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.375), new THREE.MeshBasicMaterial({ map: catSign(cat) })); sg.position.set(0, 2.72, 0.31); g.add(sg); }
  box(len, h, 0.06, 0, 0, -dep / 2 + 0.03, 0x6b4226, false, true, g);
  [-1, 1].forEach(s => box(0.08, h, dep, s * (len / 2 - 0.04), 0, 0, 0x6b4226, false, true, g));
  for (let i = 0; i <= 5; i++) box(len, 0.06, dep, 0, i * 0.5, 0, 0x7a4e2c, false, true, g);
  g.updateMatrixWorld(true);
  const start = bookMats.length;
  for (let lv = 0; lv < 5; lv++) {
    let cx = -len / 2 + 0.14;
    while (cx < len / 2 - 0.2) {
      const bw = 0.08 + Math.random() * 0.07, bh = 0.3 + Math.random() * 0.12;
      dummy.position.set(cx + bw / 2, lv * 0.5 + 0.06 + bh / 2, -0.06);
      dummy.scale.set(bw, bh, 0.34); dummy.updateMatrix();
      bookMats.push(g.matrixWorld.clone().multiply(dummy.matrix)); bookCat.push(cat);
      cx += bw + 0.01;
    }
  }
  const alongZ = Math.abs(Math.sin(rotY)) > 0.5;
  const hx = alongZ ? dep / 2 : len / 2, hz = alongZ ? len / 2 : dep / 2;
  const bb = { x0: x - hx, x1: x + hx, z0: z - hz, z1: z + hz, h: 2.6 };
  solids.push(bb);
  shelves.push({ x, z, cat, bb, start, end: bookMats.length, face: new THREE.Vector3(Math.sin(rotY), 0, Math.cos(rotY)) });
}
const PI2 = Math.PI / 2;
[['Literature', -7], ['Science', -4.2], ['History', -1.4], ['Language', 1.4]].forEach(([cat, z]) => shelf(-7.2, z, PI2, cat));
shelf(7.2, -7.2, -PI2, 'Research');
shelf(5.8, -4.2, -PI2, 'Science');
shelf(5.8, -1.4, -PI2, 'Literature');
{
  const im = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ roughness: 0.8 }), bookMats.length);
  const c = new THREE.Color();
  bookMats.forEach((m, i) => { im.setMatrixAt(i, m); im.setColorAt(i, c.set(CAT_COLORS[bookCat[i]][(Math.random() * 4) | 0])); });
  im.castShadow = true; scene.add(im); bookIM = im;
}

// ---------- desks, chairs, lamps ----------
export const lampMat = glow(0xffd48a, 0xffa94d);
export const desks = [];
function desk(x, z) {
  desks.push({ x, z });
  box(1.4, 0.08, 0.8, x, 0.72, z, WOOD);
  [[-0.65, -0.35], [0.65, -0.35], [-0.65, 0.35], [0.65, 0.35]].forEach(([dx, dz]) => box(0.06, 0.72, 0.06, x + dx, 0, z + dz, DARK, false));
  box(0.5, 0.08, 0.5, x, 0.45, z + 0.9, 0x3d6b5a);
  box(0.5, 0.5, 0.06, x, 0.53, z + 1.14, 0x3d6b5a, false);
  box(0.08, 0.45, 0.08, x, 0, z + 0.9, DARK, false);
  box(0.12, 0.03, 0.12, x + 0.5, 0.8, z - 0.2, DARK, false);
  const sh = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.2, 12, 1, true), lampMat);
  sh.position.set(x + 0.5, 1.05, z - 0.2); scene.add(sh);
  box(0.3, 0.05, 0.22, x - 0.2, 0.8, z, 0xc9b79c, false);
}
[-3.6, -1.2, 1.2, 3.6].forEach(x => { desk(x, -6); desk(x, -2.5); });

// ---------- counter + librarian ----------
box(4, 1.05, 0.9, -4, 0, 5, 0x7a4a2a);
box(4.2, 0.08, 1.0, -4, 1.05, 5, DARK, false);
box(0.3, 0.05, 0.22, -3, 1.13, 5, 0xd9a441, false);

// ---------- bulletin board ----------
{
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 320;
  const c = cv.getContext('2d');
  c.fillStyle = '#c08a52'; c.fillRect(0, 0, 512, 320);
  c.fillStyle = '#4a2c17'; c.font = 'bold 40px Georgia'; c.textAlign = 'center';
  c.fillText('LIBRARY BOARD', 256, 62);
  [['#fff3c4', 40, 100], ['#cfe8ff', 190, 120], ['#ffd1dc', 340, 100], ['#e3ffd1', 100, 200], ['#fff3c4', 260, 210]].forEach(([col, x, y]) => {
    c.fillStyle = col; c.fillRect(x, y, 130, 90);
    c.fillStyle = '#b23a48'; c.beginPath(); c.arc(x + 65, y + 10, 7, 0, 7); c.fill();
  });
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  box(0.1, 1.6, 2.4, HX - 0.05, 1.0, 3, WOOD, false, false);
  const b = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.4), new THREE.MeshBasicMaterial({ map: tex }));
  b.position.set(HX - 0.11, 1.8, 3); b.rotation.y = -PI2; scene.add(b);
}

// ---------- lounge + plants ----------
box(1.0, 0.45, 2.2, 6.7, 0, 7, 0x7d4e57);
box(0.25, 0.9, 2.2, 7.25, 0, 7, 0x6a3f48, false);
box(0.9, 0.4, 0.9, 5.2, 0, 7, 0x5c3b22);

// ---------- break area (Step 16): sofa seats, lounge chairs, window seats ----------
// x, z = where the person sits, rot = which way they face, ax/az = where they walk to before sitting
export const breakSpots = [
  { name: 'Sofa 1', x: 6.65, z: 6.45, rot: -Math.PI / 2, ax: 5.9, az: 6.45 },
  { name: 'Sofa 2', x: 6.65, z: 7.55, rot: -Math.PI / 2, ax: 5.9, az: 7.55 },
  { name: 'Lounge chair 1', x: 5.2, z: 5.5, rot: 0, ax: 5.2, az: 6.25 },
  { name: 'Lounge chair 2', x: 5.2, z: 8.5, rot: Math.PI, ax: 5.2, az: 7.75 },
  { name: 'Window seat 1', x: -4.95, z: 9.5, rot: 0, ax: -4.95, az: 8.6 },
  { name: 'Window seat 2', x: -4.05, z: 9.5, rot: 0, ax: -4.05, az: 8.6 },
  { name: 'Window seat 3', x: 4.05, z: 9.5, rot: 0, ax: 4.05, az: 8.6 },
  { name: 'Window seat 4', x: 4.95, z: 9.5, rot: 0, ax: 4.95, az: 8.6 },
];
function armchair(x, z, rotY) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotY; scene.add(g);
  box(0.8, 0.4, 0.8, 0, 0, 0, 0xb5733c, false, true, g);
  box(0.8, 0.8, 0.15, 0, 0, -0.33, 0x9c5f2e, false, true, g);
  [-0.4, 0.4].forEach(sx => box(0.12, 0.3, 0.8, sx, 0.4, 0, 0x9c5f2e, false, true, g));
  solids.push({ x0: x - 0.4, x1: x + 0.4, z0: z - 0.4, z1: z + 0.4, h: 0.8 });
}
armchair(5.2, 5.5, 0);
armchair(5.2, 8.5, Math.PI);
[-4.5, 4.5].forEach(x => {
  box(2, 0.45, 0.55, x, 0, 9.5, 0x7d4e57);
  box(1.9, 0.08, 0.5, x, 0.45, 9.5, 0xd8b98a, false, false);
});
export const plantLeaves = [];
function plant(x, z) {
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.2, 0.4, 12), mat(0xb5653c));
  pot.position.set(x, 0.2, z); pot.castShadow = true; scene.add(pot);
  [[0, 0.85, 0, 0.42], [0.18, 1.1, 0.05, 0.3], [-0.15, 1.05, -0.1, 0.3]].forEach(([dx, y, dz, r]) => {
    const f = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 10), mat(0x4f8a4a));
    f.position.set(x + dx, y, z + dz); f.castShadow = true; scene.add(f); f.userData.bx = f.position.x; plantLeaves.push(f);
  });
  solids.push({ x0: x - 0.25, x1: x + 0.25, z0: z - 0.25, z1: z + 0.25, h: 1.4 });
}
[[-6.8, 9.2], [6.8, 9.2], [-6.8, -9.3], [6.8, -9.3], [-2.2, -9.3], [2.2, -9.3]].forEach(([x, z]) => plant(x, z));

// ---------- lighting ----------
export const hemi = new THREE.HemisphereLight(0xffe6c0, 0x6b4a2f, 1.3);
scene.add(hemi);
export const sun = new THREE.DirectionalLight(0xffd9a0, 2.0);
sun.position.set(6, 9, -14); sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 1, far: 40 });
scene.add(sun);
export const lampLights = [];
[[-4, 3, 3], [0, 3, -4], [5, 3, 5]].forEach(([x, y, z]) => {
  const l = new THREE.PointLight(0xffc27a, 22, 10, 2); l.position.set(x, y, z); scene.add(l); lampLights.push(l);
});
