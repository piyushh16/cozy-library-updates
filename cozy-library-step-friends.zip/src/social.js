// SOCIAL: Step 17 reaction list (action + short written message) that friends see above your head
import { EMOTES, DUR, mine, triggerMine } from './emote.js';
import { bump } from './stats.js';

const css = document.createElement('style');
css.textContent = `
#emotes{display:none;position:fixed;left:50%;transform:translateX(-50%);top:calc(70px + env(safe-area-inset-top,0px));width:min(340px,calc(100vw - 24px));z-index:25;background:rgba(32,20,12,.97);border:2px solid #ffe9c4;border-radius:18px;padding:10px;grid-template-columns:1fr 1fr;gap:8px;box-shadow:0 8px 24px rgba(0,0,0,.5)}
#emotes button{padding:12px 8px;border-radius:12px;border:1px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font:600 14px Georgia,serif;text-align:left;touch-action:manipulation}
#emotes button.x{grid-column:1 / -1;background:transparent;text-align:center}`;
document.head.appendChild(css);
const menu = document.createElement('div'); menu.id = 'emotes';
document.body.appendChild(menu);
Object.entries(EMOTES).forEach(([k, e]) => {
  const b = document.createElement('button'); b.textContent = `${e.icon} ${e.text}`;
  b.onclick = () => {
    menu.style.display = 'none';
    if (performance.now() - mine.t0 < DUR * 1000) return;
    triggerMine(k); bump('emotes');
  };
  menu.append(b);
});
const x = document.createElement('button'); x.className = 'x'; x.textContent = 'Close'; x.onclick = () => { menu.style.display = 'none'; };
menu.append(x);
export const openReactions = () => { menu.style.display = 'grid'; };
