// CORE: scene, camera, renderer, helpers and shared state
import * as THREE from 'three';

export const W = 15, L = 20, HX = W / 2, HZ = L / 2, WH = 4;
export const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf0c48a);
scene.fog = new THREE.Fog(0xf0c48a, 30, 120);

// Step 24: lighter settings on weaker phones
export const lowEnd = (navigator.deviceMemory && navigator.deviceMemory <= 4) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
export const renderer = new THREE.WebGLRenderer({ antialias: !lowEnd, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, lowEnd ? 1.25 : 1.75));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.prepend(renderer.domElement);
export const cam = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 160);
addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight);
  cam.aspect = innerWidth / innerHeight;
  cam.updateProjectionMatrix();
});

// ---------- helpers ----------
const mats = {};
export const mat = c => mats[c] || (mats[c] = new THREE.MeshStandardMaterial({ color: c, roughness: 0.85 }));
export const glow = (c, e) => new THREE.MeshStandardMaterial({ color: c, emissive: e, emissiveIntensity: 1.2 });
export const solids = [];
export const WOOD = 0x8a5a34, DARK = 0x4a2c17, CREAM = 0xe8d5b5;

export function box(w, h, d, x, y, z, c, solid = true, shadow = true, parent = scene) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), typeof c === 'object' ? c : mat(c));
  m.position.set(x, y + h / 2, z);
  m.castShadow = shadow; m.receiveShadow = true;
  parent.add(m);
  if (solid) solids.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2, h: y + h });
  return m;
}


const smats = {};
export const sm = (c, r = 0.6) => smats[c + '_' + r] || (smats[c + '_' + r] = new THREE.MeshStandardMaterial({ color: c, roughness: r }));

// shared game state (modules read and change these)
export const state = { busy: false, forceWalk: false, held: null, faceT: Math.PI, seated: false, sitK: 0, deskName: null, spotName: null, occupied: {}, screen: 'library', heldTitle: '', windowOpen: 0, moodKey: 'evening', erasing: false, liveCount: 0 };
