// FRIENDS: Step 14 see friends in the library (walking, sitting, names above heads, taken desks)
import * as THREE from 'three';
import { scene, state, cam, renderer } from './core.js';
import { player, person, recolorPerson } from './characters.js';
import { getShirt } from './stats.js';
import { sfx } from './audio.js';
import { desks, breakSpots } from './world.js';
import { db, myUid } from './firebase.js';
import { onRoomChange, setStatusProvider } from './rooms.js';
import { mine, EMOTES, applyEmote, showEmoji, emoteToast } from './emote.js';
import { getName, activeSession } from './checkin.js';
import { getChampion } from './board.js';
import { doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';

const deskNames = [...desks].sort((a, b) => a.z - b.z || a.x - b.x).map((d, i) => ({ ...d, name: 'Desk ' + String(i + 1).padStart(2, '0') }));
const seatOf = name => { const d = deskNames.find(x => x.name === name); return d ? { x: d.x, z: d.z + 0.95, rot: Math.PI } : null; };
const spotOf = name => { const s = breakSpots.find(x => x.name === name); return s ? { x: s.x, z: s.z, rot: s.rot } : null; };
const seatFor = d => (d.desk ? seatOf(d.desk) : d.spot ? spotOf(d.spot) : null);
const PALETTE = [[0xc0504d, 0x3a2418], [0x4f8a4a, 0x2b1d12], [0xe0a030, 0x1a1a1a], [0x7a4e9c, 0x5a3a1e], [0x2f8f9d, 0x2b1d12], [0xd96a8a, 0x3a2418]];
const hash = s => { let h = 0; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); };
const round = n => Math.round(n * 100) / 100;
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

// ---- my own presence: where I am, shared a little more than once a second while I move
let room = '', members = null, last = { x: 0, z: 0, ry: 0, desk: null, spot: null, studying: false, emoteT: 0, shirt: 0, t: 0 };
function publish() {
  const id = myUid(), now = Date.now();
  if (!room || !id || state.erasing || state.screen !== 'library' || now - last.t < 1000) return;
  const p = player.position, ry = player.rotation.y, desk = state.deskName || null, spot = state.spotName || null, shirt = getShirt();
  const a = activeSession(), studying = !!(a && a.runningSince);
  const changed = Math.hypot(p.x - last.x, p.z - last.z) > 0.15 || Math.abs(ry - last.ry) > 0.3 || desk !== last.desk || spot !== last.spot || mine.t !== last.emoteT || shirt !== last.shirt || studying !== last.studying;
  if (!changed && now - last.t < 25000) return;
  last = { x: p.x, z: p.z, ry, desk, spot, studying, emoteT: mine.t, shirt, t: now };
  setDoc(doc(db, 'presence', id), { uid: id, roomId: room, name: getName() || 'Guest', x: round(p.x), z: round(p.z), ry: round(ry), desk, spot, shirt, studying, emote: mine.k ? { k: mine.k, t: mine.t } : null, updatedAt: now }).catch(() => {});
}

export function clearPresence() {
  const id = myUid(); last.t = 0;
  if (id) deleteDoc(doc(db, 'presence', id)).catch(() => {});
}

// ---- friends' presence
const data = new Map(), avatars = new Map(), subs = new Map();
let champ = null, champAt = -1e9;
// one listener per room member, so nobody outside my room can ever be read
function syncSubs() {
  const want = new Set(room && members ? members.filter(id => id !== myUid()) : []);
  for (const [id, u] of subs) if (!want.has(id)) { u(); subs.delete(id); data.delete(id); }
  for (const id of want) if (!subs.has(id)) subs.set(id, onSnapshot(doc(db, 'presence', id), s => { if (s.exists()) data.set(id, s.data()); else data.delete(id); }, () => {}));
}
onRoomChange((roomId, r) => {
  members = r ? r.memberUids : null;
  if (roomId !== room) { room = roomId; last.t = 0; data.clear(); }
  syncSubs();
});

// what each friend is doing right now (shown in the room screen)
function statusOf(id) {
  if (id === myUid()) return state.spotName ? `☕ on a break (${state.spotName})` : state.deskName ? `📖 at ${state.deskName}` : 'in the library';
  const d = data.get(id);
  if (!d || Date.now() - d.updatedAt > (d.desk ? 12 * 3600 * 1000 : 120000)) return 'away';
  return d.spot ? `☕ on a break (${d.spot})` : d.desk ? (d.studying ? `📖 studying at ${d.desk}` : `🪑 sitting at ${d.desk}`) : 'in the library';
}
setStatusProvider(statusOf);

function makeLabel(text) {
  const c = document.createElement('canvas'); c.width = 512; c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(42,26,16,0.82)';
  if (g.roundRect) { g.beginPath(); g.roundRect(4, 20, 504, 88, 40); g.fill(); } else g.fillRect(4, 20, 504, 88);
  g.fillStyle = '#ffe9c4'; g.textAlign = 'center'; g.textBaseline = 'middle';
  let s = 54; g.font = `bold ${s}px Georgia`;
  while (g.measureText(text).width > 470 && s > 20) { s -= 2; g.font = `bold ${s}px Georgia`; }
  g.fillText(text, 256, 66);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  sp.position.y = 2.15; sp.renderOrder = 9;
  return sp;
}
function spawn(id, d) {
  const [body, hair] = PALETTE[hash(id) % PALETTE.length];
  const g = person(d.shirt || body, hair), seat = seatFor(d);
  g.position.set(seat ? seat.x : d.x, 0, seat ? seat.z : d.z); g.rotation.y = d.ry || 0;
  const a = { g, label: null, text: '', walkT: 0, amp: 0, sitK: 0, shirt: d.shirt || 0 };
  avatars.set(id, a); return a;
}
function drop(id) {
  const a = avatars.get(id); if (!a) return;
  scene.remove(a.g);
  if (a.label) { a.label.material.map.dispose(); a.label.material.dispose(); }
  avatars.delete(id);
}
function animate(a, id, d, dt) {
  const seat = seatFor(d), g = a.g;
  if (d.shirt && d.shirt !== a.shirt) { recolorPerson(g, d.shirt); a.shirt = d.shirt; }
  const tx = seat ? seat.x : d.x, tz = seat ? seat.z : d.z;
  const dx = tx - g.position.x, dz = tz - g.position.z, dist = Math.hypot(dx, dz);
  if (dist > 6) g.position.set(tx, 0, tz); else { const k = 1 - Math.exp(-dt * 5); g.position.x += dx * k; g.position.z += dz * k; }
  const moving = !seat && dist > 0.12, speed = moving ? Math.min(3.2, dist * 5) : 0;
  const ta = seat ? seat.rot : moving ? Math.atan2(dx, dz) : d.ry || 0;
  g.rotation.y += wrap(ta - g.rotation.y) * (1 - Math.exp(-dt * 10));
  a.amp += ((moving ? 1 : 0) - a.amp) * (1 - Math.exp(-dt * 10));
  a.walkT += dt * speed * 3.2;
  a.sitK += ((seat ? 1 : 0) - a.sitK) * (1 - Math.exp(-dt * 8));
  const u = g.userData, sw = Math.sin(a.walkT) * 0.7 * a.amp, sk = a.sitK;
  u.legs[0].rotation.x = sw + (-1.5 - sw) * sk; u.legs[1].rotation.x = -sw + (-1.5 + sw) * sk;
  u.arms[0].rotation.x = -sw * 0.8 + (-0.5 + sw * 0.8) * sk; u.arms[1].rotation.x = sw * 0.8 + (-0.5 - sw * 0.8) * sk;
  u.arms[0].userData.fore.rotation.x = u.arms[1].userData.fore.rotation.x = -0.3 - 0.6 * sk;
  u.body.position.y = Math.abs(Math.sin(a.walkT)) * 0.05 * a.amp;
  if (d.emote && d.emote.t > (a.emoteSeen || 0)) {
    a.emoteSeen = d.emote.t;
    const def = EMOTES[d.emote.k];
    if (def && Date.now() - d.emote.t < 6000) { a.emote = { k: d.emote.k, t0: performance.now() }; showEmoji(g, def.icon, def.text); emoteToast(`${def.icon} ${d.name}: ${def.text}`); sfx.pop(); }
  }
  applyEmote(g, a.emote ? a.emote.k : null, a.emote ? (performance.now() - a.emote.t0) / 1000 : -1);
  // name (with the champion badge when they are last week's champion)
  const isChamp = champ && champ.key === id;
  const status = d.desk && d.studying ? ' 📖' : d.spot ? ' ☕' : '';
  const text = `${isChamp ? '🏆 ' : ''}${d.name}${isChamp ? '  🔥' + champ.streak : ''}${status}`;
  if (text !== a.text) {
    if (a.label) { g.remove(a.label); a.label.material.map.dispose(); a.label.material.dispose(); }
    a.label = makeLabel(text); g.add(a.label); a.text = text;
  }
  const near = Math.hypot(g.position.x - player.position.x, g.position.z - player.position.z);
  const f = 1.15 - 0.55 * Math.min(1, Math.max(0, (near - 3) / 9)); // bigger when close, smaller far away
  a.label.scale.set(1.5 * f, 0.375 * f, 1);
}

// called every frame
export function updateFriends(dt) {
  publish();
  const t = performance.now(), now = Date.now();
  if (t - champAt > 3000) { champAt = t; champ = getChampion(); }
  const live = new Set(), occ = {}, me = myUid();
  for (const [id, d] of data) {
    if (id === me || !members || !members.includes(id) || d.roomId !== room) continue;
    if (now - d.updatedAt > (d.desk ? 12 * 3600 * 1000 : 120000)) continue; // gone, unless sitting and studying
    live.add(id);
    if (d.desk) occ[d.desk] = d.name;
    if (d.spot) occ[d.spot] = d.name;
    animate(avatars.get(id) || spawn(id, d), id, d, dt);
  }
  for (const id of [...avatars.keys()]) if (!live.has(id)) drop(id);
  state.occupied = occ; state.liveCount = live.size;
}

// ---- tap a character to open their card
let tapCb = null;
export const onAvatarTap = cb => { tapCb = cb; };
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
let down = null;
renderer.domElement.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY, t: performance.now() }; });
renderer.domElement.addEventListener('pointerup', e => {
  if (!down || !tapCb || state.screen !== 'library') return;
  const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), dt = performance.now() - down.t; down = null;
  if (moved > 12 || dt > 450 || !avatars.size) return;
  ndc.set((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
  ray.setFromCamera(ndc, cam);
  let best = null, bd = 1e9;
  for (const [id, a] of avatars) {
    const hit = ray.intersectObject(a.g, true)[0];
    if (hit && hit.distance < bd) { bd = hit.distance; best = id; }
  }
  if (best) tapCb(best, (data.get(best) || {}).name || 'Friend');
});
export const presenceOf = id => data.get(id) || null;
