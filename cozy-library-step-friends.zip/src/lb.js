// LB: my study-time summary (day, week, all time, weekly history). It is shared only with the people in my study room.
import { doc, setDoc, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { db, myUid, onReady, weekKeys, weekStartKey, HISTORY_WEEKS } from './firebase.js';
import { allSessions, studiedMs, getName } from './checkin.js';
import { onRoomChange, setNameLookup } from './rooms.js';
import { state } from './core.js';

// numbers from my sessions. "real" leaves out practice (test) data, so it never goes online
function compute(real) {
  const keys = weekKeys(), starts = Array.from({ length: HISTORY_WEEKS + 1 }, (_, i) => weekStartKey(i));
  const out = { name: (getName() || 'Guest').slice(0, 40), d: keys.today, wk: keys.thisWeek, day: 0, week: 0, all: 0, hist: {} };
  for (const r of allSessions()) {
    if (real && r.test) continue;
    const ms = Math.max(0, Math.round(studiedMs(r)));
    out.all += ms;
    if (r.date === keys.today) out.day += ms;
    const i = starts.findIndex(st => r.date >= st);
    if (i === 0) out.week += ms;
    if (i >= 1) out.hist[starts[i]] = (out.hist[starts[i]] || 0) + ms;
  }
  out.day = Math.min(out.day, 86400000); out.week = Math.min(out.week, 604800000);
  return out;
}
export const localLb = () => compute(false);
export const realLb = () => compute(true);

// ---- the people in my room (one listener per person, so nobody else's data can be read)
const docs = new Map(), subs = new Map();
let members = [];
export const lbDocs = () => [...docs.entries()].filter(([id]) => id !== myUid() && members.includes(id)).map(([id, d]) => ({ id, ...d }));
setNameLookup(id => (docs.get(id) || {}).name || '');
function sync() {
  const want = new Set(members.filter(id => id !== myUid()));
  for (const [id, u] of subs) if (!want.has(id)) { u(); subs.delete(id); docs.delete(id); }
  for (const id of want) if (!subs.has(id)) subs.set(id, onSnapshot(doc(db, 'lb', id), s => { if (s.exists()) docs.set(id, s.data()); else docs.delete(id); }, () => {}));
}
onRoomChange((roomId, r) => { members = r ? r.memberUids : []; sync(); });

// ---- publish mine (at most every 15 seconds, and only when something changed)
let lastJson = '', lastAt = 0;
export function publishLb(force) {
  const id = myUid(), now = Date.now();
  if (!id || state.erasing || (!force && now - lastAt < 15000)) return;
  const v = realLb(), json = JSON.stringify(v);
  if (json === lastJson && now - lastAt < 10 * 60000) return;
  lastAt = now; lastJson = json;
  setDoc(doc(db, 'lb', id), { ...v, u: serverTimestamp() }).catch(() => { lastJson = ''; });
}
onReady(() => { publishLb(true); setInterval(publishLb, 15000); });
