// BOARD: Step 9 bulletin board + Step 10 daily and weekly leaderboards
import * as THREE from 'three';
import { scene, state, HX } from './core.js';
import { player } from './characters.js';
import { dur, activeSession } from './checkin.js';
import { myUid, syncStatus, weekKeys, weekStartKey, HISTORY_WEEKS } from './firebase.js';
import { localLb, lbDocs } from './lb.js';
import { getRoomId } from './rooms.js';

const MEDALS = ['🥇', '🥈', '🥉'];
const MIN_CHAMPION_MS = 60 * 1000; // a champion must have studied at least 1 minute that week

// one entry per person: me (from this phone, instant) and the people in my room (their shared summary)
function entries() {
  const keys = weekKeys(), me = localLb(), list = [{ key: myUid() || 'me', name: me.name, day: me.day, week: me.week, all: me.all, hist: me.hist }];
  for (const d of lbDocs()) list.push({ key: d.id, name: d.name || 'Friend', day: d.d === keys.today ? d.day : 0, week: d.wk === keys.thisWeek ? d.week : 0, all: d.all || 0, hist: d.hist || {} });
  return list;
}
const rows = (list, f) => list.map(e => ({ key: e.key, name: e.name, ms: f(e) })).filter(e => e.ms > 0).sort((a, b) => b.ms - a.ms || (a.key < b.key ? -1 : 1));
function computeStandings() {
  const list = entries(), starts = Array.from({ length: HISTORY_WEEKS + 1 }, (_, i) => weekStartKey(i));
  // champion of every finished week (index 1 = last week), who must have studied the minimum
  const tops = starts.map((st, i) => { const t = i ? rows(list, e => e.hist[st] || 0)[0] : null; return t && t.ms >= MIN_CHAMPION_MS ? t : null; });
  let champion = null;
  if (tops[1]) {
    champion = { ...tops[1], streak: 1 };
    for (let k = 2; k <= HISTORY_WEEKS && tops[k] && tops[k].key === champion.key; k++) champion.streak++;
  }
  const daily = rows(list, e => e.day);
  return {
    daily, weekly: rows(list, e => e.week), allTime: rows(list, e => e.all), champion,
    hall: tops.map((t, i) => (t ? { week: starts[i], key: t.key, name: t.name, ms: t.ms } : null)).filter(Boolean),
    total: daily.reduce((x, r) => x + r.ms, 0), active: (activeSession() ? 1 : 0) + (state.liveCount || 0),
  };
}

let stCache = null, stAt = 0;
function standings(force) {
  const t = performance.now();
  if (!force && stCache && t - stAt < 1500) return stCache;
  stCache = computeStandings(); stAt = t;
  return stCache;
}
export const getChampion = () => standings().champion;
export const readStandings = () => standings(true);
export const peekStandings = () => standings();
export function openBoard(t) { if (t) tab = t; openPanel(); }

// ---- the board on the wall
const cv = document.createElement('canvas'); cv.width = 768; cv.height = 480;
const ctx = cv.getContext('2d');
const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
const plane = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.4), new THREE.MeshBasicMaterial({ map: tex }));
plane.position.set(HX - 0.13, 1.8, 3); plane.rotation.y = -Math.PI / 2; scene.add(plane);

function fit(text, x, y, size, bold = false, maxW = 700) {
  let s = size;
  const set = () => { ctx.font = `${bold ? 'bold ' : ''}${s}px Georgia`; };
  set();
  while (ctx.measureText(text).width > maxW && s > 14) { s -= 1; set(); }
  ctx.fillText(text, x, y);
}
function draw() {
  const { daily, weekly, champion, total, active } = standings();
  ctx.fillStyle = '#c08a52'; ctx.fillRect(0, 0, 768, 480);
  ctx.fillStyle = '#4a2c17'; ctx.textAlign = 'center';
  fit("TODAY'S STUDY BOARD", 384, 66, 44, true);
  fit(new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' }), 384, 100, 24);
  if (!daily.length) fit('No one has studied yet today.', 384, 220, 30);
  daily.slice(0, 3).forEach((r, i) => {
    const y = 122 + i * 62;
    ctx.fillStyle = '#fff3c4'; ctx.fillRect(60, y, 648, 52);
    ctx.fillStyle = '#4a2c17'; ctx.textAlign = 'left'; fit(`${MEDALS[i]} ${r.name}`, 80, y + 37, 32, true, 420);
    ctx.textAlign = 'right'; fit(dur(r.ms), 690, y + 37, 32, true, 220);
  });
  ctx.fillStyle = '#4a2c17'; ctx.textAlign = 'center';
  fit(`Total today: ${dur(total)}  ·  In the library now: ${active}`, 384, 340, 24);
  fit(`This week's leader: ${weekly[0] ? weekly[0].name + ' (' + dur(weekly[0].ms) + ')' : 'none yet'}`, 384, 385, 26);
  ctx.fillStyle = '#fff3c4'; ctx.fillRect(60, 410, 648, 52);
  ctx.fillStyle = '#4a2c17';
  fit(`🏆 Last week's champion: ${champion ? champion.name + ' (' + dur(champion.ms) + ')  🔥' + champion.streak : 'none yet'}`, 384, 445, 26, true, 620);
  tex.needsUpdate = true;
}
draw();

// ---- bigger readable version
const css = document.createElement('style');
css.textContent = `
#boardbtn{position:fixed;right:calc(20px + env(safe-area-inset-right,0px));bottom:calc(110px + env(safe-area-inset-bottom,0px));display:none;padding:16px 26px;border-radius:32px;border:2px solid #ffe9c4;background:rgba(74,44,23,.92);color:#ffe9c4;font:600 19px Georgia,serif;touch-action:manipulation;box-shadow:0 4px 14px rgba(0,0,0,.4)}
#boardp{position:fixed;inset:0;display:none;z-index:25;overflow-y:auto;background:rgba(32,20,12,.97);color:#ffe9c4;font:17px/1.4 Georgia,serif;padding:calc(16px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px))}
#boardp .wrap{max-width:520px;margin:0 auto}
#boardp .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
#boardp h2{margin:0;font-size:22px}
#boardp h3{margin:18px 0 4px;font-size:18px;color:#f0c48a}
#boardp .x{width:44px;height:44px;border-radius:50%;border:2px solid #ffe9c4;background:#8a5a34;color:#ffe9c4;font-size:20px}
#boardp .r{display:flex;justify-content:space-between;background:rgba(255,243,196,.14);border-radius:12px;padding:12px;margin-bottom:8px;font-weight:700}
#boardp .st{margin-top:8px;opacity:.9}
#boardp .tabs{display:flex;gap:8px;margin-bottom:10px}
#boardp .tab{flex:1;padding:10px 4px;border-radius:20px;border:2px solid #ffe9c4;background:transparent;color:#ffe9c4;font:600 15px Georgia,serif}
#boardp .tab.on{background:#8a5a34}
#boardp .note{font-size:14px;opacity:.7;margin-bottom:8px}
#boardp .champ{white-space:pre-line;background:rgba(240,196,138,.25);border:1px solid #f0c48a;border-radius:12px;padding:12px;font-weight:700}`;
document.head.appendChild(css);
const btn = document.createElement('button'); btn.id = 'boardbtn'; btn.textContent = '📌 Read the board';
const panel = document.createElement('div'); panel.id = 'boardp';
document.body.append(btn, panel);
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

function section(wrap, title, note, rows, empty) {
  wrap.append(mk('h3', '', title), mk('div', 'note', note));
  if (!rows.length) wrap.append(mk('div', 'st', empty));
  rows.slice(0, 10).forEach((r, i) => {
    const row = mk('div', 'r'); row.append(mk('span', '', `${MEDALS[i] || (i + 1) + '.'} ${r.name}`), mk('span', '', dur(r.ms))); wrap.append(row);
  });
}
let tab = 'today';
function openPanel() {
  const s = standings(true), room = getRoomId();
  const wrap = mk('div', 'wrap'), top = mk('div', 'top');
  const x = mk('button', 'x', '✕'); x.onclick = () => { panel.style.display = 'none'; };
  top.append(mk('h2', '', '📌 Study board'), x); wrap.append(top);
  const tabs = mk('div', 'tabs');
  [['today', 'Today'], ['week', 'This week'], ['all', 'All time']].forEach(([k, l]) => {
    const t = mk('button', tab === k ? 'tab on' : 'tab', l); t.onclick = () => { tab = k; openPanel(); }; tabs.append(t);
  });
  wrap.append(tabs, mk('div', 'note', room ? `Showing the people in room ${room}.` : 'Showing only you. Create or join a room (🏠) to compare with friends.'));
  if (tab === 'today') {
    section(wrap, "Today's ranking", 'Resets every day. Being first today does not give a badge.', s.daily, 'No one has studied yet today.');
    wrap.append(mk('div', 'st', `Total study time today: ${dur(s.total)}`), mk('div', 'st', `In the library now: ${s.active}`));
  } else if (tab === 'week') {
    section(wrap, 'This week so far', 'Resets every Monday. The weekly champion is decided when the week ends on Sunday.', s.weekly, 'No one has studied this week yet.');
    wrap.append(mk('h3', '', "🏆 Last week's champion"),
      mk('div', 'champ', s.champion ? `${s.champion.name} · ${dur(s.champion.ms)}\n🔥 ${s.champion.streak} week${s.champion.streak > 1 ? 's' : ''} in a row as champion` : 'No champion yet. The first one is decided after this week ends.'),
      mk('div', 'note', '🔥 counts consecutive weeks as Weekly Library Champion. It is not a daily study streak.'));
  } else {
    section(wrap, 'All time', 'Total study time since the start. Never resets.', s.allTime, 'No study time yet.');
    wrap.append(mk('h3', '', '🏆 Hall of Fame'), mk('div', 'note', 'Past weekly champions'));
    if (!s.hall.length) wrap.append(mk('div', 'st', 'No champions yet.'));
    s.hall.forEach(h => {
      const [y, m, d] = h.week.split('-').map(Number), row = mk('div', 'r');
      row.append(mk('span', '', `Week of ${new Date(y, m - 1, d).toLocaleDateString([], { day: 'numeric', month: 'short' })}: ${h.name}`), mk('span', '', dur(h.ms)));
      wrap.append(row);
    });
  }
  wrap.append(mk('div', 'st', `☁ Online sync: ${syncStatus()}`));
  panel.replaceChildren(wrap); panel.scrollTop = 0; panel.style.display = 'block';
}
btn.addEventListener('pointerdown', e => { e.stopPropagation(); openPanel(); });

// called every frame
let lastDraw = performance.now(), shown = false;
export function updateBoard() {
  const now = performance.now();
  if (now - lastDraw > 5000) { lastDraw = now; draw(); }
  const near = !state.busy && player.position.x > 5.6 && Math.abs(player.position.z - 3) < 1.6;
  if (near !== shown) { shown = near; btn.style.display = near ? 'block' : 'none'; }
}
